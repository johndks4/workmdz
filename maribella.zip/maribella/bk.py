import os
import pyzipper
import urllib.request
import time
from datetime import datetime

def enviar_para_telegram(token_bot, chat_id, caminho_arquivo):
    """Envia o arquivo ZIP gerado diretamente para o chat do Telegram."""
    print("📤 Enviando backup para o Telegram...")
    url = f"https://api.telegram.org/bot{token_bot}/sendDocument"
    
    try:
        with open(caminho_arquivo, 'rb') as f:
            arquivo_dados = f.read()
            
        nome_arquivo = os.path.basename(caminho_arquivo)
        boundary = '----TelegramBotBoundary'
        corpo = []
        
        corpo.append(f'--{boundary}'.encode('utf-8'))
        corpo.append(f'Content-Disposition: form-data; name="chat_id"'.encode('utf-8'))
        corpo.append(''.encode('utf-8'))
        corpo.append(str(chat_id).encode('utf-8'))
        
        corpo.append(f'--{boundary}'.encode('utf-8'))
        corpo.append(f'Content-Disposition: form-data; name="document"; filename="{nome_arquivo}"'.encode('utf-8'))
        corpo.append('Content-Type: application/zip'.encode('utf-8'))
        corpo.append(''.encode('utf-8'))
        corpo.append(arquivo_dados)
        corpo.append(f'--{boundary}--'.encode('utf-8'))
        
        corpo_final = b'\r\n'.join(corpo)
        
        requisicao = urllib.request.Request(url, data=corpo_final)
        requisicao.add_header('Content-Type', f'multipart/form-data; boundary={boundary}')
        requisicao.add_header('Content-Length', str(len(corpo_final)))
        
        with urllib.request.urlopen(requisicao) as resposta:
            resultado = resposta.read().decode('utf-8')
            if '"ok":true' in resultado:
                print("📲 Arquivo enviado com sucesso ao Telegram!")
            else:
                print(f"⚠️ Resposta inesperada do Telegram: {resultado}")
                
    except Exception as e:
        print(f"❌ Erro ao enviar para o Telegram: {e}")

def criar_backup_protegido(diretorio_origem, arquivo_zip_destino, senha, extensoes):
    """Varre as pastas e usa o pyzipper para criar um ZIP plano com senha na raiz."""
    print(f"🔍 [{datetime.now().strftime('%H:%M:%S')}] Escaneando arquivos...")
    
    diretorio_absoluto_origem = os.path.abspath(diretorio_origem)
    caminho_zip_absoluto = os.path.abspath(os.path.join(diretorio_origem, arquivo_zip_destino))
    
    # Remove o ZIP antigo se ele já existir para não acumular lixo
    if os.path.exists(caminho_zip_absoluto):
        try:
            os.remove(caminho_zip_absoluto)
        except Exception:
            pass

    arquivos_adicionados = 0

    try:
        # Cria o arquivo ZIP usando criptografia AES (padrão seguro e amplamente aceito)
        with pyzipper.AESZipFile(caminho_zip_absoluto, 'w', compression=pyzipper.ZIP_DEFLATED, encryption=pyzipper.WZ_AES) as zip_file:
            # Define a senha do ZIP
            zip_file.setpassword(senha.encode('utf-8'))
            
            for raiz, pastas, arquivos in os.walk(diretorio_absoluto_origem):
                # Ignora estritamente as pastas node_modules e .git do escaneamento
                pastas[:] = [p for p in pastas if p not in ('node_modules', '.git')]
                
                for arquivo in arquivos:
                    if any(arquivo.lower().endswith(ext) for ext in extensoes):
                        # Evita colocar os arquivos do próprio script ou o zip gerado dentro dele mesmo
                        if arquivo in (arquivo_zip_destino, "backup_telegram.py", "backup.py"):
                            continue
                            
                        caminho_completo = os.path.join(raiz, arquivo)
                        
                        # O segredo absoluto aqui: arcname=arquivo diz para o ZIP ignorar toda a estrutura
                        # de pastas e salvar o arquivo seco, direto e misturado na raiz do arquivo comprimido.
                        zip_file.write(caminho_completo, arcname=arquivo)
                        arquivos_adicionados += 1

        if arquivos_adicionados == 0:
            print("⚠️ Nenhum arquivo correspondente encontrado para o backup.")
            if os.path.exists(caminho_zip_absolute):
                os.remove(caminho_zip_absolute)
            return False

        print(f"✅ ZIP plano gerado com sucesso! {arquivos_adicionados} arquivos adicionados na raiz.")
        return True
        
    except Exception as e:
        print(f"❌ Ocorreu um erro ao criar o ZIP: {e}")
        if os.path.exists(caminho_zip_absoluto):
            os.remove(caminho_zip_absoluto)
        return False

if __name__ == "__main__":
    # --- CONFIGURAÇÕES FIXAS ---
    PASTA_ORIGEM = "." 
    NOME_DO_ZIP = "backup_seguro.zip"
    SENHA_ZIP = "maribella"
    EXTENSOES_ALVO = (".js", ".txt", ".py", ".json", ".db")
    
    TELEGRAM_TOKEN = "8832110028:AAHcCVOiH7qtspKps8fx8yqxbsqV7c-sAkI"
    TELEGRAM_CHAT_ID = "8523690887"
    INTERVALO_SEGUNDOS = 120  # 2 minutos
    # ---------------------------

    print(f"🚀 Monitoramento ativo com pyzipper. Executando a cada 2 minutos...")
    
    while True:
        sucesso = criar_backup_protegido(PASTA_ORIGEM, NOME_DO_ZIP, SENHA_ZIP, EXTENSOES_ALVO)
        if sucesso:
            enviar_para_telegram(TELEGRAM_TOKEN, TELEGRAM_CHAT_ID, NOME_DO_ZIP)
        
        print(f"💤 Aguardando {INTERVALO_SEGUNDOS} segundos para o próximo envio...\n")
        time.sleep(INTERVALO_SEGUNDOS)
