class DurationManager {
    static parseToMs(duration) {
        if (typeof duration === 'number') return duration;
        const unitMap = { 's': 1000, 'm': 60000, 'h': 3600000, 'd': 86400000 };
        const match = duration.match(/^(\d+)([smhd])$/);
        if (match) return parseInt(match[1]) * (unitMap[match[2]] || 1000);
        return parseInt(duration) * 1000 || 30000;
    }
    static getProgress(startTime, duration) {
        const elapsed = Date.now() - startTime;
        return Math.min(100, Math.round((elapsed / duration) * 100));
    }
    static isExpired(startTime, duration) {
        return Date.now() - startTime >= duration;
    }
    static getRemaining(startTime, duration) {
        const remaining = duration - (Date.now() - startTime);
        return Math.max(0, remaining);
    }
    static formatTime(ms) {
        const seconds = Math.floor(ms / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
        if (days > 0) return `${days}d ${hours % 24}h`;
        if (hours > 0) return `${hours}h ${minutes % 60}m`;
        if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
        return `${seconds}s`;
    }
}
module.exports = DurationManager;
