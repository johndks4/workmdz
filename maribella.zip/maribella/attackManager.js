class AttackManager {
    constructor() { this.attacks = new Map(); }
    static add(target, instance) { if (!this.attacks) this.attacks = new Map(); this.attacks.set(target, instance); }
    static remove(target) { if (this.attacks) this.attacks.delete(target); }
    static get(target) { return this.attacks ? this.attacks.get(target) : null; }
    static getAll() { return this.attacks ? Array.from(this.attacks.entries()) : []; }
    static updateStats(target, stats) { const attack = this.get(target); if (attack) attack.stats = stats; }
    static stopAll() { if (!this.attacks) return; for (const [target, attack] of this.attacks) { try { attack.stop(); } catch(e) {} } this.attacks.clear(); }
}
module.exports = AttackManager;
