#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import json

# ================= CONFIGURAÇÃO =================
BASE_URL = "https://ydpwxdjusiubjdwmimlz.supabase.co"
TABLE = "user_roles"
USER_ID = "eq.d31fedeb-d963-48e9-a1b7-bdb0a0ca4715"  # seu user_id

# Token JWT fornecido (expira em 1783113168)
BEARER_TOKEN = (
    "eyJhbGciOiJFUzI1NiIsImtpZCI6IjEzODJmMjRlLTM3MzctNDUwZi1hNzJkLTM4MTNhZTRlMDNmYiIsInR5cCI6IkpXVCJ9."
    "eyJpc3MiOiJodHRwczovL3lkcHd4ZGp1c2l1Ympkd21pbWx6LnN1cGFiYXNlLmNvL2F1dGgvdjEiLCJzdWIiOiJkMzFmZWRlYi1kOTYzLTQ4ZTktYTFiNy1iZGIwYTBjYTQ3MTUiLCJhdWQiOiJhdXRoZW50aWNhdGVkIiwiZXhwIjoxNzgzMTEzMTY4LCJpYXQiOjE3ODMxMDk1NjgsImVtYWlsIjoiam9obm1kekByaXR6eWJ1c2Nhcy5jb20iLCJwaG9uZSI6IiIsImFwcF9tZXRhZGF0YSI6eyJwcm92aWRlciI6ImVtYWlsIiwicHJvdmlkZXJzIjpbImVtYWlsIl19LCJ1c2VyX21ldGFkYXRhIjp7ImVtYWlsX3ZlcmlmaWVkIjp0cnVlfSwicm9sZSI6ImF1dGhlbnRpY2F0ZWQiLCJhYWwiOiJhYWwxIiwiYW1yIjpbeyJtZXRob2QiOiJwYXNzd29yZCIsInRpbWVzdGFtcCI6MTc4MzEwOTU2OH1dLCJzZXNzaW9uX2lkIjoiMjBkOWFkZDYtZDEyMS00MDE0LTg3M2EtYmMzM2EwNGEyNTc2IiwiaXNfYW5vbnltb3VzIjpmYWxzZX0."
    "gFngV_hhmRCfAfckZxl0V7Ax2ZjU1En8gesKZohySYoirSytzawxrvtlmiX_DJvJXvwqouwweyk4oKxHsSecJQ"
)

API_KEY = "sb_publishable_30SF8l8D4MPEjrRKh2wmqw_VwX059BA"

# ================= REQUISIÇÃO PATCH =================

url = f"{BASE_URL}/rest/v1/{TABLE}"
headers = {
    'Authorization': f"Bearer {BEARER_TOKEN}",
    'apikey': API_KEY,
    'Content-Type': 'application/json',
    'Prefer': 'return=representation',  # retorna o registro atualizado
    'User-Agent': "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
    'Accept': "application/json"
}

# Filtro: alterar apenas a linha com este user_id
params = {'user_id': f"eq.{USER_ID}"}

# Novo role (teste)
payload = {'role': 'admin'}

try:
    response = requests.patch(url, params=params, json=payload, headers=headers, timeout=10)
    print(f"Status Code: {response.status_code}")
    print("Resposta:")
    print(response.text)

    if response.status_code == 200:
        print("\n✅ SUCESSO: O role foi alterado para 'admin'.")
        print("❗ Isso indica que as políticas RLS NÃO estão protegendo atualizações.")
    elif response.status_code == 403:
        print("\n⛔ BLOQUEADO: Você não tem permissão para alterar o role.")
        print("✅ As políticas RLS estão funcionando corretamente.")
    elif response.status_code == 404:
        print("\n⚠️ Nenhum registro encontrado com esse user_id. Verifique o ID ou a tabela.")
    else:
        print(f"\n⚠️ Resposta inesperada: {response.status_code}")
except Exception as e:
    print(f"Erro na requisição: {e}")
