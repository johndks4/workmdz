#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import json
import random
import time
import threading
import sys
from datetime import datetime

# ----------------- CONFIGURAÇÕES -----------------
BASE_EMAIL = "gringomdz"
EMAIL_DOMAIN = "@gmail.com"
PASSWORD = "johnmdz99"
NOME = "John"
SOBRENOME = "Doe"
NOME_COMPLETO = "John Doe"

URL = "https://mkstqjtsujvcaobdksxs.supabase.co/auth/v1/signup"
PARAMS = {'redirect_to': "https://uncensored.ai/"}

HEADERS = {
    'User-Agent': "Mozilla/5.0 (Linux; Android 15; SM-A057M Build/AP3A.240905.015.A2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.7827.91 Mobile Safari/537.36",
    'Accept-Encoding': "gzip, deflate, br, zstd",
    'sec-ch-ua-platform': "\"Android\"",
    'authorization': "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1rc3RxanRzdWp2Y2FvYmRrc3hzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTI3NzQyNjksImV4cCI6MjA2ODM1MDI2OX0.suu2A2fAcdJfAG0dOjOjWLfU6BXxNSn5GrbiSSmUiw0",
    'x-supabase-api-version': "2024-01-01",
    'sec-ch-ua': "\"Android WebView\";v=\"149\", \"Chromium\";v=\"149\", \"Not)A;Brand\";v=\"24\"",
    'sec-ch-ua-mobile': "?1",
    'x-client-info': "supabase-js-web/2.52.0",
    'content-type': "application/json;charset=UTF-8",
    'apikey': "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1rc3RxanRzdWp2Y2FvYmRrc3hzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTI3NzQyNjksImV4cCI6MjA2ODM1MDI2OX0.suu2A2fAcdJfAG0dOjOjWLfU6BXxNSn5GrbiSSmUiw0",
    'origin': "https://uncensored.ai",
    'x-requested-with': "mark.via.gp",
    'sec-fetch-site': "cross-site",
    'sec-fetch-mode': "cors",
    'sec-fetch-dest': "empty",
    'referer': "https://uncensored.ai/",
    'accept-language': "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
    'priority': "u=1, i",
    'Cookie': "__cf_bm=tuhABwweCBeXmzQlRpdzNmr5SSxWk.JYPIksqvfw_ic-1782837474.4062693-1.0.1.1-rjCsioLnLamFeMaf.9AlMiRmLaCF3V.p94GKjj73LFxsQSnaAb_RV5MHzls.frZYG2i2XqslJTvazEzZ8tJcpsae1DHu.7YPzPTTDjAYKt6c3IGX6Wy8benz2uI2RhOA"
}

# ---------------- CONFIGURAÇÕES DE RATE LIMIT -----
MAX_RETRIES = 3                # número máximo de tentativas por conta
BASE_BACKOFF = 2               # segundos iniciais de espera (dobra a cada retry)
# -------------------------------------------------

NUM_THREADS = 5                # número de threads paralelas
OUTPUT_FILE = "contas.txt"     # arquivo com email:senha
# -------------------------------------------------

file_lock = threading.Lock()
stats_lock = threading.Lock()

total_tentativas = 0
total_sucessos = 0
total_falhas = 0

def gerar_email():
    """Gera email único com timestamp + aleatório + thread id."""
    timestamp = int(time.time() * 1000)
    rand = random.randint(1000, 9999)
    tid = threading.get_ident() % 1000
    return f"{BASE_EMAIL}_{timestamp}_{rand}_{tid}{EMAIL_DOMAIN}"

def salvar_credenciais(email, senha):
    """Salva email:senha no arquivo de saída (uma linha por conta)."""
    with file_lock:
        with open(OUTPUT_FILE, 'a', encoding='utf-8') as f:
            f.write(f"{email}:{senha}\n")

def criar_conta_com_retry(email):
    """
    Tenta criar a conta com retry em caso de rate limit (429).
    Retorna (sucesso, dados_ou_mensagem, tentativas_usadas)
    """
    payload = {
        "email": email,
        "password": PASSWORD,
        "data": {
            "first_name": NOME,
            "last_name": SOBRENOME,
            "full_name": NOME_COMPLETO
        },
        "gotrue_meta_security": {},
        "code_challenge": None,
        "code_challenge_method": None
    }

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = requests.post(
                URL,
                params=PARAMS,
                data=json.dumps(payload),
                headers=HEADERS,
                timeout=15
            )

            if response.status_code == 200:
                data = response.json()
                if "id" in data or ("user" in data and "id" in data["user"]):
                    return True, data, attempt
                else:
                    return False, f"Resposta sem ID: {data}", attempt
            elif response.status_code == 429:
                # Rate limit – espera com backoff exponencial
                wait_time = BASE_BACKOFF ** attempt  # 2, 4, 8...
                print(f"   ⏳ Rate limit! Aguardando {wait_time}s (tentativa {attempt}/{MAX_RETRIES})...")
                time.sleep(wait_time)
                continue  # tenta novamente
            else:
                # Outros erros – não tenta de novo
                return False, f"Erro HTTP {response.status_code}: {response.text[:300]}", attempt
        except Exception as e:
            # Erro de rede – também pode tentar novamente
            if attempt < MAX_RETRIES:
                wait_time = BASE_BACKOFF ** attempt
                print(f"   ⏳ Erro de rede, aguardando {wait_time}s (tentativa {attempt}/{MAX_RETRIES})...")
                time.sleep(wait_time)
                continue
            else:
                return False, f"Erro na requisição (excedeu retries): {str(e)}", attempt

    # Se chegou aqui, todas as tentativas falharam
    return False, "Falha após todas as tentativas (rate limit persistente)", MAX_RETRIES

def worker(thread_id):
    """Loop infinito: gera email, tenta criar com retry, salva se sucesso."""
    global total_tentativas, total_sucessos, total_falhas
    while True:
        email = gerar_email()
        with stats_lock:
            total_tentativas += 1
            tentativa_num = total_tentativas

        print(f"[Thread-{thread_id}] [{tentativa_num}] Tentando {email}...")

        sucesso, resultado, tentativas_usadas = criar_conta_com_retry(email)
        if sucesso:
            with stats_lock:
                total_sucessos += 1
            print(f"✅ Thread-{thread_id} criou {email} (após {tentativas_usadas} tentativa(s))")
            # Salva apenas email e senha
            salvar_credenciais(email, PASSWORD)
            # Opcional: mostrar ID para debug
            if "user" in resultado:
                user = resultado["user"]
                print(f"   ID: {user.get('id')}")
        else:
            with stats_lock:
                total_falhas += 1
            print(f"❌ Thread-{thread_id} falhou: {resultado}")

        # Nenhum delay fixo entre contas – o backoff só atua em rate limit

def main():
    if len(sys.argv) > 1:
        try:
            num_threads = int(sys.argv[1])
        except:
            num_threads = NUM_THREADS
    else:
        num_threads = NUM_THREADS

    print(f"[*] Iniciando criação INFINITA de contas com {num_threads} threads.")
    print(f"[*] Rate limit tratado com retry e backoff exponencial (máx {MAX_RETRIES} tentativas).")
    print(f"[*] Credenciais salvas em: {OUTPUT_FILE}")
    print("[*] Pressione Ctrl+C para parar.")

    threads = []
    for i in range(num_threads):
        t = threading.Thread(target=worker, args=(i+1,))
        t.daemon = True
        t.start()
        threads.append(t)

    try:
        for t in threads:
            t.join()
    except KeyboardInterrupt:
        print("\n\n[*] Interrompido pelo usuário.")
        with stats_lock:
            print(f"[*] Total de tentativas: {total_tentativas} | Sucessos: {total_sucessos} | Falhas: {total_falhas}")

if __name__ == "__main__":
    main()
