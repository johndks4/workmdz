class TargetMonitor {
    constructor(io) { this.io = io; this.targets = new Map(); this.emaAlpha = 0.3; }
    recordMovement(target, data) {
        if (!this.targets.has(target)) {
            this.targets.set(target, { status: data.status, latency: data.latency, emaLatency: data.latency, firstSeen: Date.now(), lastSeen: Date.now(), health: 100 });
        }
        const record = this.targets.get(target);
        record.lastSeen = Date.now();
        record.emaLatency = (this.emaAlpha * data.latency) + ((1 - this.emaAlpha) * record.emaLatency);
        record.status = data.status;
        if (record.emaLatency > 3000) record.health -= 5;
        else if (record.emaLatency > 1000) record.health -= 2;
        else if (record.health < 100) record.health += 1;
        record.health = Math.max(0, Math.min(100, record.health));
        if (this.io) this.io.emit('target_update', { target, status: record.status, latency: Math.round(record.emaLatency), health: record.health });
    }
    getStatus(target) { return this.targets.get(target) || null; }
    isDown(target) { const record = this.targets.get(target); return record ? record.health < 20 : false; }
}
module.exports = TargetMonitor;
