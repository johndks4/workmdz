import requests
import json
import time
import os
from datetime import datetime, timedelta
from email_gen import create_temp_email
import threading
from queue import Queue

class BananasAI:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'accept': '*/*',
            'accept-language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',
            'origin': 'https://bananasai.ai',
            'referer': 'https://bananasai.ai/pt/ai-image-generator',
            'content-type': 'application/json'
        })
        self.email = None
        self.temp_email_obj = None
        self.csrf_token = None
        self.verification_token = None
        self.cookies = None
        self.lock = threading.Lock()
        
    def create_account(self, timeout=120):
        email, temp_obj = create_temp_email()
        self.email = email
        self.temp_email_obj = temp_obj
        
        print(f"📧 Email: {self.email}")
        
        if not self._send_verification():
            return None
        
        code = self._wait_for_code(timeout)
        if not code:
            return None
        
        if not self._get_csrf_token():
            return None
        
        if not self._verify_code(code):
            return None
        
        return self._save_account_info()
    
    def _send_verification(self):
        url = 'https://bananasai.ai/api/auth/send-verification'
        payload = {
            'email': self.email,
            'locale': 'pt'
        }
        
        try:
            response = self.session.post(url, json=payload)
            if response.status_code == 200:
                data = response.json()
                if data.get('success'):
                    self.verification_token = data.get('token')
                    return True
            return False
        except:
            return False
    
    def _wait_for_code(self, timeout=120):
        print("Aguardando código de verificação...")
        code, email = self.temp_email_obj.get_code(timeout)
        if code:
            print(f"codigo: {code}")
            return code
        return None
    
    def _get_csrf_token(self):
        url = 'https://bananasai.ai/api/auth/csrf'
        
        try:
            response = self.session.get(url)
            if response.status_code == 200:
                data = response.json()
                self.csrf_token = data.get('csrfToken')
                return True
            return False
        except:
            return False
    
    def _verify_code(self, code):
        url = 'https://bananasai.ai/api/auth/callback/email-code?'
        
        self.session.headers.update({
            'content-type': 'application/x-www-form-urlencoded',
            'x-auth-return-redirect': '1'
        })
        
        data = {
            'token': self.verification_token,
            'code': code,
            'redirect': 'false',
            'csrfToken': self.csrf_token,
            'callbackUrl': 'https://bananasai.ai/pt/ai-image-generator'
        }
        
        try:
            response = self.session.post(url, data=data)
            if response.status_code == 200:
                result = response.json()
                if result.get('url'):
                    self.cookies = self.session.cookies.get_dict()
                    return True
            return False
        except:
            return False
    
    def _save_account_info(self):
        account_data = {
            'email': self.email,
            'uso': 0,
            'cookie': json.dumps(self.cookies),
            'tempo': (datetime.now() + timedelta(hours=5)).isoformat()
        }
        
        filename = 'accounts.json'
        
        with self.lock:
            accounts = []
            
            if os.path.exists(filename):
                with open(filename, 'r', encoding='utf-8') as f:
                    try:
                        accounts = json.load(f)
                    except:
                        accounts = []
            
            accounts.append(account_data)
            
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(accounts, f, indent=2, ensure_ascii=False)
        
        print(f"conta: {self.email}")
        return account_data

def create_account_worker(thread_id, num_accounts, results):
    print(f"Thread {thread_id} iniciada")
    
    for i in range(num_accounts):
        print(f"\n[Thread {thread_id}] --- Criando conta {i+1}/{num_accounts} ---")
        bananas = BananasAI()
        result = bananas.create_account()
        if result:
            print(f"[Thread {thread_id}] Conta criada com sucesso")
            results.append(result)
        else:
            print(f"[Thread {thread_id}] Falha ao criar conta")
        time.sleep(3)

def create_accounts_threaded():
    try:
        num = int(input("Quantas contas deseja criar? "))
        num_threads = int(input("Quantas threads? "))
    except:
        print("Número inválido")
        return
    
    if num_threads > num:
        num_threads = num
    
    accounts_per_thread = num // num_threads
    remainder = num % num_threads
    
    threads = []
    results = []
    
    print(f"\nIniciando criação - {num} - com {num_threads} threads")
    
    for i in range(num_threads):
        accounts_to_create = accounts_per_thread
        if i < remainder:
            accounts_to_create += 1
        
        thread = threading.Thread(
            target=create_account_worker,
            args=(i+1, accounts_to_create, results)
        )
        threads.append(thread)
        thread.start()
    
    for thread in threads:
        thread.join()
    
    print(f"\nProcesso finalizado!")
    print(f"Contas criadas com sucesso: {len(results)}")

def create_accounts_single():
    try:
        num = int(input("Quantas contas? "))
    except:
        print("Número inválido")
        return
    
    for i in range(num):
        print(f"\n--- Criando conta {i+1}/{num} ---")
        bananas = BananasAI()
        result = bananas.create_account()
        if result:
            print(f"Conta {i+1} criada com sucesso")
        else:
            print(f"Falha ao criar conta {i+1}")
        time.sleep(5)

if __name__ == "__main__":
    print("Escolha o modo:")
    print("1 - Criar contas em série")
    print("2 - Criar contas em paralelo (threads)")
    
    choice = input("Opção: ")
    
    if choice == "2":
        create_accounts_threaded()
    else:
        create_accounts_single()
