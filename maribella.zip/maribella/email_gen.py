import requests
import re
import json
import time
import random
import string

class TempEmail:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36'
        })
        self.email = None
        self.token = None
        
    def generate_email(self):
        prefix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
        self.email = f"{prefix}@uorak.com"
        return self.email
    
    def create_session(self):
        if not self.email:
            self.generate_email()
        
        response = self.session.get(f'https://www.invertexto.com/gerador-email-temporario?email={self.email}')
        
        match = re.search(r'source = new EventSource\("(https://uorak\.com/sse\?token=[^"]+)"\)', response.text)
        if match:
            self.token = match.group(1)
            return True
        return False
    
    def wait_for_email(self, timeout=120):
        if not self.token:
            return None
        
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                response = self.session.get(self.token, stream=True, timeout=30)
                
                for line in response.iter_lines(decode_unicode=True):
                    if time.time() - start_time > timeout:
                        break
                    
                    if line and line.startswith('data: '):
                        data_str = line[6:]
                        if data_str and data_str != '[]':
                            try:
                                data = json.loads(data_str)
                                if data and len(data) > 0:
                                    mail_data = data[0]
                                    body = mail_data.get('body', '')
                                    
                                    code_match = re.search(r'(\d{6})', body)
                                    if code_match:
                                        code = code_match.group(1)
                                        return {
                                            'email': self.email,
                                            'code': code,
                                            'full_data': mail_data
                                    }
                            except json.JSONDecodeError:
                                pass
                    
                    if line and line.startswith('event: mail'):
                        continue
                        
            except requests.exceptions.RequestException:
                time.sleep(2)
                continue
        
        return None
    
    def get_email(self):
        if not self.email:
            self.generate_email()
        return self.email
    
    def get_code(self, timeout=120):
        if self.create_session():
            result = self.wait_for_email(timeout)
            if result:
                return result['code'], result['email']
        return None, None

def get_temp_email_code(timeout=120):
    temp = TempEmail()
    code, email = temp.get_code(timeout)
    return code, email

def create_temp_email():
    temp = TempEmail()
    email = temp.get_email()
    return email, temp
