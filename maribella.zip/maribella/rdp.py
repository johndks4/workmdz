#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import subprocess
import sys
import os
import socket
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

# ========== CONFIGURAÇÃO ==========
TIMEOUT = 10
MAX_WORKERS = 10
PASSWORD = ""   # senha vazia
# ==================================

def ensure_x_display():
    if 'DISPLAY' in os.environ and os.environ['DISPLAY']:
        return True
    try:
        subprocess.run(['Xvfb', ':0', '-screen', '0', '1024x768x24'], check=False, timeout=2)
        os.environ['DISPLAY'] = ':0'
        return True
    except:
        print("[!] Xvfb não encontrado. Instale: sudo apt install xvfb")
        return False

def parse_entry(entry):
    r"""Extrai IP, porta, domínio e usuário de uma linha no formato:
       IP:PORT@DOMAIN\username;
    """
    entry = entry.strip().rstrip(';')
    if '@' not in entry:
        raise ValueError(f"Formato inválido (falta '@'): {entry}")
    ip_port, domain_user = entry.split('@', 1)
    if ':' not in ip_port:
        raise ValueError(f"Formato inválido (falta ':' no IP:porta): {ip_port}")
    ip, port = ip_port.split(':', 1)
    if '\\' not in domain_user:
        raise ValueError(f"Formato inválido (falta '\\' em domínio\\usuário): {domain_user}")
    domain, username = domain_user.split('\\', 1)
    return ip, port, domain, username

def test_tcp_connect(ip, port, timeout=3):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((ip, int(port)))
        sock.close()
        return result == 0
    except:
        return False

def test_rdp(ip, port, domain, username, password=PASSWORD):
    # 1. Teste de conectividade
    if not test_tcp_connect(ip, port):
        return False, "Porta 3389 fechada ou host inalcançável"

    # 2. Garantir display
    if not ensure_x_display():
        return False, "Sem display X disponível"

    # 3. Tentar xfreerdp
    cmd_xfreerdp = [
        'xfreerdp',
        f'/v:{ip}:{port}',
        f'/u:{username}',
        f'/d:{domain}',
        f'/p:{password}',
        '/cert-ignore',
        '/timeout:5',
        '/audio-mode:0',
        '+auto-reconnect',
        '+fonts'
    ]
    try:
        result = subprocess.run(
            cmd_xfreerdp,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=TIMEOUT,
            text=True
        )
        output = result.stdout + result.stderr
        if "Authentication failure" in output:
            return False, "Authentication failure"
        if "Login failed" in output:
            return False, "Login failed"
        if "Connection established" in output or "Successfully connected" in output:
            return True, "Connected (xfreerdp)"
        if result.returncode == 0:
            return True, "Connected (xfreerdp exit 0)"
        # Se falhou com DNS error, tentar rdesktop
        if "DNS_NAME_NOT_FOUND" in output or "ERRCONNECT_DNS_NAME_NOT_FOUND" in output:
            return test_rdp_rdesktop(ip, port, domain, username, password)
        return False, f"xfreerdp erro {result.returncode}: {result.stderr[:200]}"
    except subprocess.TimeoutExpired:
        return False, "Timeout"
    except FileNotFoundError:
        # Se xfreerdp não existe, tentar rdesktop
        return test_rdp_rdesktop(ip, port, domain, username, password)
    except Exception as e:
        return False, f"Erro inesperado: {e}"

def test_rdp_rdesktop(ip, port, domain, username, password=PASSWORD):
    """Alternativa com rdesktop."""
    # rdesktop usa formato: -u usuário -d domínio -p senha ip:porta
    cmd = [
        'rdesktop',
        f'-u{username}',
        f'-d{domain}',
        f'-p{password}',
        f'{ip}:{port}',
        '-a16',              # 16-bit color
        '-z',                # compressão
        '-x0b'               # desabilita cache bitmap (mais leve)
    ]
    try:
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=TIMEOUT,
            text=True
        )
        output = result.stdout + result.stderr
        if "Authentication failure" in output or "Login failed" in output:
            return False, "Authentication failure"
        if "Connection established" in output:
            return True, "Connected (rdesktop)"
        if result.returncode == 0:
            return True, "Connected (rdesktop exit 0)"
        return False, f"rdesktop erro {result.returncode}: {result.stderr[:200]}"
    except subprocess.TimeoutExpired:
        return False, "Timeout"
    except FileNotFoundError:
        return False, "rdesktop não encontrado. Instale com: sudo apt install rdesktop"
    except Exception as e:
        return False, f"Erro inesperado: {e}"

def check_entry(entry):
    try:
        ip, port, domain, username = parse_entry(entry)
        print(f"[*] Testando {ip}:{port}@{domain}\\{username}...", end=' ', flush=True)
        success, msg = test_rdp(ip, port, domain, username)
        if success:
            print(f"✅ {msg}")
            return (ip, port, domain, username, "SUCCESS", msg)
        else:
            print(f"❌ {msg}")
            return (ip, port, domain, username, "FAIL", msg)
    except ValueError as e:
        print(f"[!] Entrada ignorada: {entry} ({e})")
        return None

def main():
    if len(sys.argv) < 2:
        print(f"Uso: {sys.argv[0]} <arquivo_de_credenciais>")
        sys.exit(1)

    file_path = sys.argv[1]
    try:
        with open(file_path, 'r') as f:
            entries = [line.strip() for line in f if line.strip() and not line.startswith('#')]
    except FileNotFoundError:
        print(f"Erro: Arquivo '{file_path}' não encontrado.")
        sys.exit(1)

    if not entries:
        print("Nenhuma entrada válida encontrada.")
        sys.exit(0)

    if not ensure_x_display():
        print("[!] Abortando. Instale xvfb com: sudo apt install xvfb")
        sys.exit(1)

    print(f"[*] Carregadas {len(entries)} entradas. Testando com {MAX_WORKERS} threads...\n")

    results = []
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_to_entry = {executor.submit(check_entry, entry): entry for entry in entries}
        for future in as_completed(future_to_entry):
            result = future.result()
            if result:
                results.append(result)

    working = [r for r in results if r[4] == "SUCCESS"]
    print(f"\n{'='*60}")
    print(f"RESUMO: {len(working)} funcionam de {len(results)} testadas.")
    if working:
        print("\n✅ Funcionam:")
        for r in working:
            print(f"  {r[0]}:{r[1]}@{r[2]}\\{r[3]}   ({r[5]})")
    else:
        print("\n❌ Nenhuma conta funcionou. Verifique se os IPs estão ativos e a porta 3389 está aberta.")

if __name__ == "__main__":
    main()
