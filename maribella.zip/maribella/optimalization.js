const os = require('os');
class Optimizer {
    constructor() {
        this.cpuCores = os.cpus().length;
        this.memoryTotal = os.totalmem();
        this.isCritical = false;
        this.loadHistory = [];
    }
    getAdaptiveConcurrency(baseConcurrency) {
        const load = os.loadavg()[0];
        this.loadHistory.push(load);
        if (this.loadHistory.length > 10) this.loadHistory.shift();
        const avgLoad = this.loadHistory.reduce((a, b) => a + b, 0) / this.loadHistory.length;
        const maxLoad = this.cpuCores * 0.75;
        if (avgLoad > maxLoad) { this.isCritical = true; return Math.max(1, Math.floor(baseConcurrency * (maxLoad / avgLoad))); }
        this.isCritical = false;
        return baseConcurrency;
    }
    getMemoryMultiplier() {
        const freeMem = os.freemem();
        const ratio = freeMem / this.memoryTotal;
        if (ratio < 0.2) return 0.5;
        if (ratio < 0.4) return 0.75;
        return 1.0;
    }
    getOptimalConcurrency(base) {
        const memFactor = this.getMemoryMultiplier();
        const cpuFactor = 1 - (os.loadavg()[0] / (this.cpuCores * 2));
        return Math.max(1, Math.floor(base * Math.min(memFactor, cpuFactor)));
    }
}
module.exports = new Optimizer();
