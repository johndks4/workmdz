#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
from bs4 import BeautifulSoup
import sys
import re

# ===========================
# CONFIGURAÇÃO
# ===========================
BASE_URL = "https://borafama02.com"
LOGIN_URL = f"{BASE_URL}/en"

HEADERS = {
    'User-Agent': "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
    'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    'Accept-Encoding': "gzip, deflate, br, zstd",
    'Cache-Control': "max-age=0",
    'sec-ch-ua': '"Chromium";v="149", "Not)A;Brand";v="24"',
    'sec-ch-ua-mobile': "?0",
    'sec-ch-ua-platform': '"macOS"',
    'Upgrade-Insecure-Requests': "1",
    'X-Requested-With': "mark.via.gp",
    'Sec-Fetch-Site': "none",
    'Sec-Fetch-Mode': "navigate",
    'Sec-Fetch-User': "?1",
    'Sec-Fetch-Dest': "document",
    'Accept-Language': "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7"
}

# ===========================
# FUNÇÕES
# ===========================

def get_csrf_token(session):
    """
    Obtém o token CSRF da página de login.
    """
    try:
        response = session.get(LOGIN_URL, headers=HEADERS, timeout=10)
        soup = BeautifulSoup(response.text, 'html.parser')
        csrf_input = soup.find('input', {'name': '_csrf'})
        if csrf_input:
            return csrf_input.get('value')
        # Fallback via regex
        match = re.search(r'<input[^>]*name="_csrf"[^>]*value="([^"]+)"', response.text)
        if match:
            return match.group(1)
        return None
    except Exception as e:
        return None

def check_login(username, password):
    session = requests.Session()
    session.max_redirects = 5

    # 1. Obter CSRF e cookies iniciais
    csrf_token = get_csrf_token(session)
    if not csrf_token:
        return False, "Falha ao obter token CSRF."

    # 2. Preparar payload de login
    payload = {
        'LoginForm[username]': username,
        'LoginForm[password]': password,
        '_csrf': csrf_token
    }

    post_headers = HEADERS.copy()
    post_headers['Origin'] = BASE_URL
    post_headers['Referer'] = LOGIN_URL
    post_headers['Content-Type'] = 'application/x-www-form-urlencoded'

    try:
        # 3. Enviar credenciais
        login_response = session.post(LOGIN_URL, data=payload, headers=post_headers, timeout=10)

        # 4. Verificar se há mensagem de erro explícita
        if "Incorrect username or password" in login_response.text:
            return False, "Credenciais inválidas"

        # 5. Se não houver mensagem de erro, assumimos login bem-sucedido
        # Acessa a home para extrair o saldo (já autenticado)
        home_response = session.get(BASE_URL, headers=HEADERS, timeout=10)
        if home_response.status_code != 200:
            return True, "Logado, mas não foi possível acessar a home"

        soup = BeautifulSoup(home_response.text, 'html.parser')
        # Buscar o elemento do saldo
        balance_elem = soup.find('a', class_='component-navbar-balance-item__navbar-private')
        if not balance_elem:
            balance_elem = soup.find('span', class_='component-navbar-balance-item__navbar-private')

        if balance_elem:
            balance_text = balance_elem.get_text(strip=True)
            match = re.search(r'R\$\s*([\d,.]+)', balance_text)
            if match:
                balance = match.group(1)
            else:
                balance = balance_text
            return True, balance
        else:
            return True, "Logado, mas saldo não encontrado"

    except Exception as e:
        return False, f"Erro na requisição: {e}"

# ===========================
# EXECUÇÃO PRINCIPAL
# ===========================
def main():
    if len(sys.argv) != 3:
        print("Uso: python borafama_checker.py <username> <password>")
        sys.exit(1)

    username = sys.argv[1]
    password = sys.argv[2]
    success, result = check_login(username, password)
    
    if success:
        print(f"✅ {username} | Saldo: R$ {result}")
    else:
        print(f"❌ {username} | {result}")

if __name__ == "__main__":
    main()
