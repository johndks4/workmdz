#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import threading
import queue
import time
import re
import sys
import argparse
from urllib.parse import urlparse

# ----------------- CONFIGURAÇÕES -----------------
TEST_URL = "http://azenv.net/"
TIMEOUT_CONNECT = 5
TIMEOUT_READ = 10
RPS_SAMPLE = 5
MIN_RPS = 3
MAX_LATENCY = 1500
FILTER_LEVEL = "elite"      # "elite", "anonymous", "transparent", "all"
OUTPUT_FILE = "proxies_aprovados.txt"
WORKERS = 15
DELAY_BETWEEN_REQUESTS = 0.2
# ------------------------------------------------

# Fontes públicas (apenas HTTP, IP:PORT)
PROXY_SOURCES = [
    "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
    "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
    "https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all"
]

def fetch_proxies_from_url(url):
    try:
        resp = requests.get(url, timeout=10)
        if resp.status_code == 200:
            lines = resp.text.strip().split('\n')
            proxies = []
            for line in lines:
                line = line.strip()
                # Aceita apenas IP:PORT (sem protocolo)
                if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+$', line):
                    proxies.append(line)
            return proxies
        return []
    except Exception:
        return []

def gather_all_proxies(file_path=None):
    """
    Se file_path for fornecido, lê proxies do arquivo (um por linha).
    Caso contrário, baixa das fontes públicas.
    Retorna lista de strings no formato:
      - ip:port (será tratado como http://)
      - protocolo://ip:port (ex: socks5://ip:port)
    """
    all_proxies = []
    if file_path:
        try:
            with open(file_path, 'r') as f:
                lines = f.read().strip().split('\n')
                for line in lines:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        # Se não tiver protocolo, adiciona http:// como padrão
                        if not re.match(r'^(https?|socks[45])://', line):
                            line = f"http://{line}"
                        all_proxies.append(line)
            print(f"[*] Carregados {len(all_proxies)} proxies do arquivo '{file_path}'")
        except Exception as e:
            print(f"[!] Erro ao ler arquivo: {e}")
            sys.exit(1)
    else:
        for src in PROXY_SOURCES:
            print(f"[*] Baixando de: {src}")
            prox = fetch_proxies_from_url(src)
            print(f"   -> {len(prox)} proxies encontrados")
            # Adiciona http:// a cada um
            all_proxies.extend([f"http://{p}" for p in prox])
        all_proxies = list(set(all_proxies))
        print(f"[*] Total de proxies únicos: {len(all_proxies)}")
    return all_proxies

def parse_azenv(html):
    """Extrai REMOTE_ADDR e HTTP_X_FORWARDED_FOR do HTML."""
    remote = None
    forwarded = None
    match = re.search(r'<td>REMOTE_ADDR</td><td>([^<]+)</td>', html)
    if match:
        remote = match.group(1).strip()
    match = re.search(r'<td>HTTP_X_FORWARDED_FOR</td><td>([^<]+)</td>', html)
    if match:
        forwarded = match.group(1).strip()
    return remote, forwarded

def classify_proxy(remote_addr, forwarded_for, proxy_ip):
    """
    Classifica com base nos cabeçalhos.
    - Elite: REMOTE_ADDR = IP do proxy, e sem X-Forwarded-For.
    - Anonymous: REMOTE_ADDR = IP do proxy, mas X-Forwarded-For existe (pode ser fake).
    - Transparent: REMOTE_ADDR é o IP real do cliente (ou X-Forwarded-For revela o IP real).
    """
    if not remote_addr:
        return "unknown"
    if remote_addr == proxy_ip:
        if not forwarded_for:
            return "elite"
        else:
            if forwarded_for == proxy_ip:
                return "elite"
            return "anonymous"
    else:
        return "transparent"

def test_proxy(proxy_str):
    """
    Testa um proxy com o protocolo especificado na string.
    proxy_str: ex: "http://ip:port", "socks5://ip:port", "https://ip:port", etc.
    Retorna dict com resultados ou None se falhar.
    """
    # Extrai o IP (sem porta) para classificação
    parsed = urlparse(proxy_str)
    proxy_ip = parsed.hostname
    if not proxy_ip:
        return None
    # Constrói o dicionário de proxies para requests
    # Para HTTP/HTTPS, usamos 'http' e 'https' com o mesmo proxy
    # Para SOCKS, também usamos ambos
    proxy_dict = {
        "http": proxy_str,
        "https": proxy_str
    }
    try:
        # 1. Requisição principal
        start = time.time()
        resp = requests.get(TEST_URL, proxies=proxy_dict, timeout=TIMEOUT_CONNECT)
        latency_ms = (time.time() - start) * 1000
        if resp.status_code != 200 or latency_ms > MAX_LATENCY:
            return None

        html = resp.text
        remote, forwarded = parse_azenv(html)
        if not remote:
            return None

        # 2. Medir RPS
        times = []
        for _ in range(RPS_SAMPLE):
            time.sleep(DELAY_BETWEEN_REQUESTS)
            t0 = time.time()
            r = requests.get(TEST_URL, proxies=proxy_dict, timeout=TIMEOUT_READ)
            if r.status_code != 200:
                return None
            times.append(time.time() - t0)
        avg_time = sum(times) / len(times)
        rps = 1.0 / avg_time if avg_time > 0 else 0

        if rps < MIN_RPS:
            return None

        # Classificação
        level = classify_proxy(remote, forwarded, proxy_ip)

        # Filtro
        if FILTER_LEVEL != "all" and level != FILTER_LEVEL:
            return None

        return {
            "proxy": proxy_str,
            "latency_ms": round(latency_ms, 1),
            "rps": round(rps, 2),
            "level": level,
            "remote_addr": remote,
            "forwarded_for": forwarded if forwarded else "none"
        }
    except Exception:
        return None

def worker(q, results):
    while True:
        try:
            proxy = q.get_nowait()
        except queue.Empty:
            break
        result = test_proxy(proxy)
        if result:
            results.append(result)
            print(f"[+] Aprovado: {proxy} | {result['level']} | Lat: {result['latency_ms']}ms | RPS: {result['rps']}")
        else:
            print(f"[-] Reprovado: {proxy}")
        q.task_done()

def main():
    parser = argparse.ArgumentParser(description="Proxy scraper and tester with azenv.net")
    parser.add_argument("--file", help="Arquivo com proxies (um por linha, com ou sem protocolo)")
    args = parser.parse_args()

    print("[*] Iniciando coleta e teste com azenv.net...")
    proxies = gather_all_proxies(args.file)
    if not proxies:
        print("[!] Nenhum proxy encontrado.")
        return

    q = queue.Queue()
    for p in proxies:
        q.put(p)

    results = []
    threads = []
    for _ in range(WORKERS):
        t = threading.Thread(target=worker, args=(q, results))
        t.daemon = True
        t.start()
        threads.append(t)

    q.join()
    for t in threads:
        t.join()

    results.sort(key=lambda x: x['rps'], reverse=True)

    print(f"\n[*] Total de proxies aprovados (nível '{FILTER_LEVEL}'): {len(results)}")
    if results:
        with open(OUTPUT_FILE, 'w') as f:
            f.write("proxy | nivel | latency_ms | rps | remote_addr | forwarded_for\n")
            for r in results:
                f.write(f"{r['proxy']} | {r['level']} | {r['latency_ms']} | {r['rps']} | {r['remote_addr']} | {r['forwarded_for']}\n")
        print(f"[*] Resultados salvos em: {OUTPUT_FILE}")
        print("\nTop 5 por RPS:")
        for i, r in enumerate(results[:5]):
            print(f"  {i+1}. {r['proxy']} - {r['level']} - RPS: {r['rps']} - Lat: {r['latency_ms']}ms")
    else:
        print("[!] Nenhum proxy passou nos critérios. Ajuste os limites.")

if __name__ == "__main__":
    main()
