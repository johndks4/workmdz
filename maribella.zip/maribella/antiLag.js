const os = require('os');
class AntiLag {
    constructor() { this.throttleMultiplier = 1.0; this.efficiencyFactor = 1.0; this.lastCheck = Date.now(); this.checkInterval = 1000; }
    getThrottleMultiplier() { const now = Date.now(); if (now - this.lastCheck > this.checkInterval) { this.updateFactors(); this.lastCheck = now; } return this.throttleMultiplier; }
    getEfficiencyFactor() { const now = Date.now(); if (now - this.lastCheck > this.checkInterval) { this.updateFactors(); this.lastCheck = now; } return this.efficiencyFactor; }
    updateFactors() {
        const load = os.loadavg()[0];
        const cpuCores = os.cpus().length;
        const memFree = os.freemem();
        const memTotal = os.totalmem();
        if (load > cpuCores) this.throttleMultiplier = 1.0 + (load / cpuCores);
        else this.throttleMultiplier = 1.0;
        const memRatio = memFree / memTotal;
        if (memRatio < 0.15) this.efficiencyFactor = 0.3;
        else if (memRatio < 0.30) this.efficiencyFactor = 0.6;
        else if (memRatio < 0.50) this.efficiencyFactor = 0.8;
        else this.efficiencyFactor = 1.0;
        this.throttleMultiplier = Math.max(1.0, Math.min(5.0, this.throttleMultiplier));
        this.efficiencyFactor = Math.max(0.1, Math.min(1.0, this.efficiencyFactor));
    }
}
module.exports = new AntiLag();
