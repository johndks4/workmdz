#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import threading
import queue
import time
import sys
import os
from collections import defaultdict

PROXY_FILE = "proxy.txt"
AZENV_TEST_URL = "http://azenv.net/"
COUNTRY_API_URL = "https://check-host.net/ip-info?host={}"
TIMEOUT = 5
MAX_THREADS = 20

# ===========================
# ESTADO GLOBAL PARA LIVE
# ===========================
total_proxies = 0
checked = 0
alive = 0
country_counts = defaultdict(int)
active_proxies = []
lock = threading.Lock()
start_time = time.time()

def test_proxy(proxy):
    try:
        proxies = {"http": f"http://{proxy}", "https": f"http://{proxy}"}
        response = requests.get(AZENV_TEST_URL, proxies=proxies, timeout=TIMEOUT)
        if response.status_code == 200:
            return True
    except:
        pass
    return False

def get_country(ip):
    try:
        url = COUNTRY_API_URL.format(ip)
        response = requests.get(url, timeout=TIMEOUT)
        if response.status_code == 200:
            data = response.json()
            if 'country' in data:
                return data['country']
    except:
        pass
    return "Unknown"

def worker(proxy_queue):
    global checked, alive, country_counts, active_proxies
    while True:
        try:
            proxy = proxy_queue.get_nowait()
        except queue.Empty:
            break
        alive_flag = test_proxy(proxy)
        with lock:
            checked += 1
            if alive_flag:
                alive += 1
                ip = proxy.split(':')[0]
                country = get_country(ip)
                country_counts[country] += 1
                active_proxies.append(proxy)
        proxy_queue.task_done()

def display_live():
    """Atualiza a tela com informações em tempo real."""
    while True:
        with lock:
            elapsed = time.time() - start_time
            rate = (checked / elapsed) if elapsed > 0 else 0
            alive_rate = (alive / total_proxies * 100) if total_proxies > 0 else 0
            # Top 5 países
            sorted_countries = sorted(country_counts.items(), key=lambda x: x[1], reverse=True)[:5]
            country_str = ", ".join([f"{c}:{n}" for c, n in sorted_countries]) if sorted_countries else "Nenhum"
        sys.stdout.write(f"\r[{int(elapsed)}s] Verificados: {checked}/{total_proxies} | Vivos: {alive} ({alive_rate:.1f}%) | Países: {country_str}")
        sys.stdout.flush()
        time.sleep(1)

def main():
    global total_proxies
    if not os.path.exists(PROXY_FILE):
        print(f"Arquivo {PROXY_FILE} não encontrado.")
        sys.exit(1)

    with open(PROXY_FILE, 'r') as f:
        proxies = [line.strip() for line in f if line.strip()]
    total_proxies = len(proxies)
    print(f"Carregados {total_proxies} proxies. Iniciando verificação...")

    proxy_queue = queue.Queue()
    for p in proxies:
        proxy_queue.put(p)

    # Inicia thread de display
    display_thread = threading.Thread(target=display_live, daemon=True)
    display_thread.start()

    # Inicia workers
    threads = []
    for _ in range(min(MAX_THREADS, total_proxies)):
        t = threading.Thread(target=worker, args=(proxy_queue,))
        t.start()
        threads.append(t)

    for t in threads:
        t.join()

    # Aguarda display finalizar (não vai, mas esperamos a última atualização)
    time.sleep(1)

    # Resumo final
    print("\n\n" + "═"*60)
    print("🔰 MDZ DDO - PROXY CHECKER (LIVE) – RESUMO FINAL")
    print("═"*60)
    print(f"│ Total de proxies: {total_proxies}")
    print(f"│ Proxies ativas: {alive}")
    print(f"│ Taxa de sobrevivência: {(alive/total_proxies*100):.2f}%")
    print("│ ┠ ──────────────────────────────────────")
    print("│ 🌍 Distribuição por país:")
    sorted_countries = sorted(country_counts.items(), key=lambda x: x[1], reverse=True)
    for country, count in sorted_countries:
        print(f"│ │ {country}: {count}")
    print("═"*60)

    # Salvar ativas
    if alive > 0:
        with open("alive_proxies.txt", "w") as f:
            for proxy in active_proxies:
                f.write(proxy + "\n")
        print(f"\n✅ Proxies ativas salvas em 'alive_proxies.txt'")

if __name__ == "__main__":
    main()
