#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
from bs4 import BeautifulSoup
import sys
import re

# ===========================
# CONFIGURAÇÃO
# ===========================
BASE_URL = "https://borafama02.com"
LOGIN_URL = f"{BASE_URL}/en"
ACCOUNT_URL = f"{BASE_URL}/account"

HEADERS = {
    'User-Agent': "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
    'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    'Accept-Encoding': "gzip, deflate, br, zstd",
    'Cache-Control': "max-age=0",
    'sec-ch-ua': '"Chromium";v="149", "Not)A;Brand";v="24"',
    'sec-ch-ua-mobile': "?0",
    'sec-ch-ua-platform': '"macOS"',
    'Upgrade-Insecure-Requests': "1",
    'X-Requested-With': "mark.via.gp",
    'Sec-Fetch-Site': "none",
    'Sec-Fetch-Mode': "navigate",
    'Sec-Fetch-User': "?1",
    'Sec-Fetch-Dest': "document",
    'Accept-Language': "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7"
}

# ===========================
# FUNÇÕES
# ===========================

def get_csrf_token(session):
    """
    Acessa a página de login e extrai o token CSRF do input hidden.
    """
    try:
        response = session.get(LOGIN_URL, headers=HEADERS, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        csrf_input = soup.find('input', {'name': '_csrf'})
        if csrf_input:
            return csrf_input.get('value')
        # Fallback via regex
        match = re.search(r'<input[^>]*name="_csrf"[^>]*value="([^"]+)"', response.text)
        if match:
            return match.group(1)
        return None
    except Exception as e:
        print(f"[!] Erro ao obter CSRF: {e}")
        return None

def check_login(username, password):
    """
    Tenta login e retorna (sucesso, saldo_ou_mensagem).
    """
    session = requests.Session()
    
    # 1. Obter CSRF
    csrf_token = get_csrf_token(session)
    if not csrf_token:
        return False, "Falha ao obter token CSRF."

    # 2. Preparar payload
    payload = {
        'LoginForm[username]': username,
        'LoginForm[password]': password,
        '_csrf': csrf_token
    }

    post_headers = HEADERS.copy()
    post_headers['Origin'] = BASE_URL
    post_headers['Referer'] = LOGIN_URL
    post_headers['Content-Type'] = 'application/x-www-form-urlencoded'

    try:
        # 3. Enviar login
        response = session.post(LOGIN_URL, data=payload, headers=post_headers, timeout=10)
        
        # 4. Verificar se houve erro de credenciais
        if "Incorrect username or password" in response.text:
            return False, "Credenciais inválidas"
        if "alert-danger" in response.text:
            return False, "Credenciais inválidas"

        # 5. Verificar se o login foi bem-sucedido (presença de cookie _identity_user)
        if '_identity_user' not in session.cookies.get_dict():
            return False, "Login não confirmado (cookie de identidade ausente)"

        # 6. Acessar página da conta para extrair saldo
        account_resp = session.get(ACCOUNT_URL, headers=HEADERS, timeout=10)
        account_resp.raise_for_status()

        soup = BeautifulSoup(account_resp.text, 'html.parser')
        # Buscar elemento com a classe do saldo
        balance_elem = soup.find('a', class_='component-navbar-balance-item__navbar-private')
        if not balance_elem:
            # Tenta buscar por um elemento com classe similar
            balance_elem = soup.find('span', class_='component-navbar-balance-item__navbar-private')
        
        if balance_elem:
            balance_text = balance_elem.get_text(strip=True)
            # Extrair apenas o número (ex: "R$ 0" -> "0")
            match = re.search(r'R\$\s*([\d,.]+)', balance_text)
            if match:
                balance = match.group(1)
            else:
                balance = balance_text
            return True, balance
        else:
            return True, "Logado, mas não foi possível extrair o saldo."

    except Exception as e:
        return False, f"Erro na requisição: {e}"

# ===========================
# EXEMPLO DE USO
# ===========================
def main():
    if len(sys.argv) != 3:
        print("Uso: python borafama02_checker.py <username> <password>")
        sys.exit(1)

    username = sys.argv[1]
    password = sys.argv[2]
    success, result = check_login(username, password)
    
    if success:
        print(f"✅ {username} | Saldo: R$ {result}")
    else:
        print(f"❌ {username} | {result}")

if __name__ == "__main__":
    main()
