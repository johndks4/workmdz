// telegram_report_bot.js - Configurado com seu token e ID

const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const https = require('https');
const dns = require('dns');
const crypto = require('crypto');
const { URL } = require('url');

// ============ SUAS CONFIGURAÇÕES ============
const TOKEN = '8775997363:AAEBRm25Jf_GZgUiYd64Bh_iZG8UPJ0dp4s';
const ADMIN_IDS = [6105321948];

const CONFIG = {
    channels: {
        safernet: true,
        ncmec: true,
        cloudflare: true
    },
    cacheFile: 'reported_urls.json'
};

// ============ INICIALIZAÇÃO ============
let reportedUrls = {};

function loadCache() {
    try {
        if (fs.existsSync(CONFIG.cacheFile)) {
            reportedUrls = JSON.parse(fs.readFileSync(CONFIG.cacheFile, 'utf-8'));
        }
    } catch(e) {}
}

function saveCache() {
    fs.writeFileSync(CONFIG.cacheFile, JSON.stringify(reportedUrls, null, 2));
}

// ============ FUNÇÕES DE REPORT ============
function reportToSaferNet(url, description) {
    return new Promise((resolve) => {
        const payload = JSON.stringify({
            url: url,
            tipo: 'csam',
            descricao: description || 'Conteúdo ilícito detectado por usuário',
            denunciante_anonimo: true
        });
        
        const req = https.request('https://denuncia.safernet.org.br/api/v1/report', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, (res) => {
            resolve({ success: res.statusCode === 200, status: res.statusCode });
        });
        
        req.on('error', () => resolve({ success: false, error: 'network_error' }));
        req.write(payload);
        req.end();
    });
}

function reportToNCMEC(url) {
    return Promise.resolve({
        success: true,
        url: `https://report.cybertip.org/iscr/webform/index?url=${encodeURIComponent(url)}`
    });
}

function detectHosting(url) {
    return new Promise((resolve) => {
        let hostname;
        try {
            hostname = new URL(url).hostname;
        } catch(e) {
            return resolve({ ip: null, provider: 'invalid_url' });
        }
        
        dns.lookup(hostname, (err, ip) => {
            if (err) return resolve({ ip: null, provider: 'unknown' });
            
            const req = https.get(`https://ipinfo.io/${ip}/json`, (res) => {
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => {
                    try {
                        const json = JSON.parse(data);
                        resolve({ ip: ip, provider: json.org || 'unknown' });
                    } catch(e) {
                        resolve({ ip: ip, provider: 'unknown' });
                    }
                });
            });
            req.on('error', () => resolve({ ip: ip, provider: 'unknown' }));
            req.setTimeout(5000, () => resolve({ ip: ip, provider: 'unknown' }));
            req.end();
        });
    });
}

// ============ BOT ============
let bot;

async function startBot() {
    bot = new TelegramBot(TOKEN, { polling: true });
    
    const mainMenu = {
        reply_markup: {
            inline_keyboard: [
                [{ text: "🚨 Reportar site", callback_data: "report" }],
                [{ text: "📊 Estatísticas", callback_data: "stats" }],
                [{ text: "ℹ️ Ajuda", callback_data: "help" }]
            ]
        }
    };
    
    bot.onText(/\/start/, (msg) => {
        bot.sendMessage(msg.chat.id, 
            `🛡️ *Bot de Denúncia - Sites Ilícitos*\n\n` +
            `Este bot reporta sites com conteúdo de abuso infantil, terrorismo e outros crimes.\n\n` +
            `Use /report https://site.com para denunciar.`,
            { parse_mode: 'Markdown', ...mainMenu }
        );
    });
    
    bot.onText(/\/report(?:\s+(.+))?/, async (msg, match) => {
        const chatId = msg.chat.id;
        const url = match ? match[1] : null;
        
        if (!url) {
            bot.sendMessage(chatId, `🔗 Envie: /report https://site.com`);
            return;
        }
        
        try { new URL(url); } catch(e) {
            bot.sendMessage(chatId, `❌ URL inválida.`);
            return;
        }
        
        await bot.sendMessage(chatId, `🔍 Reportando: ${url}...`);
        
        const hosting = await detectHosting(url);
        const safernetResult = await reportToSaferNet(url);
        const ncmecResult = await reportToNCMEC(url);
        
        const response = `✅ *Report concluído*\n\n` +
            `📍 URL: ${url}\n` +
            `📡 IP: ${hosting.ip || 'N/A'}\n` +
            `🏢 Provedor: ${hosting.provider || 'N/A'}\n\n` +
            `📋 Resultados:\n` +
            `SaferNet: ${safernetResult.success ? '✅' : '❌'}\n` +
            `NCMEC: ${ncmecResult.success ? '✅' : '❌'}\n\n` +
            `🔗 Reporte manual NCMEC: ${ncmecResult.url}`;
        
        bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });
        
        const hash = crypto.createHash('sha256').update(url).digest('hex');
        reportedUrls[hash] = { url, timestamp: Date.now(), hosting };
        saveCache();
        
        // Notifica admin (você)
        bot.sendMessage(6105321948, `🔔 Report de @${msg.from.username || msg.from.id}\nURL: ${url}\nIP: ${hosting.ip || 'N/A'}`);
    });
    
    bot.onText(/\/stats/, (msg) => {
        const total = Object.keys(reportedUrls).length;
        bot.sendMessage(msg.chat.id, `📊 Total de URLs reportadas: ${total}`);
    });
    
    bot.onText(/\/help/, (msg) => {
        bot.sendMessage(msg.chat.id,
            `📖 *Comandos*\n` +
            `/start - Iniciar\n` +
            `/report <url> - Denunciar site\n` +
            `/stats - Estatísticas\n` +
            `/help - Ajuda\n\n` +
            `*Canais:* SaferNet Brasil + NCMEC`,
            { parse_mode: 'Markdown' }
        );
    });
    
    bot.on('callback_query', (query) => {
        const data = query.data;
        if (data === 'report') bot.sendMessage(query.message.chat.id, `Use /report https://site.com`);
        if (data === 'stats') bot.sendMessage(query.message.chat.id, `📊 Total: ${Object.keys(reportedUrls).length}`);
        if (data === 'help') bot.sendMessage(query.message.chat.id, `Use /help`);
        bot.answerCallbackQuery(query.id);
    });
    
    const botInfo = await bot.getMe();
    console.log(`✅ Bot rodando: @${botInfo.username}`);
    console.log(`👑 Admin ID: 6105321948`);
}

loadCache();
startBot().catch(console.error);
